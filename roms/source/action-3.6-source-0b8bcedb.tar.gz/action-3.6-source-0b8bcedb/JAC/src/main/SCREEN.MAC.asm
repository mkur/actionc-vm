;
;	SCREEN.MAC
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified October 18, 1982.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc screen

scrinit	.proc	
	lda	#cio_channel.zero
	jsr	mainio.close		; close #0, sets X to 0
	lda	#cio_mode.read_write
	sta	arg3
	lda	#cio_channel.zero
	ldx	#<scred
	ldy	#>scred
	jmp	mainio.open

scred	m_string 'E:'			; Action! string sytax with leading length
	.byte character.eol		; CIO termintion character

	.endp


;	 ScrCh(char)
;	------------
; outputs char to screen.  Char passed in A reg.
; Control characters are ignored.

scrch	.proc	
	tay	
	lda	#0
scrchar	ldx	#1
	bne	putch.putch1
	.endp


;	PutCh(char)
;	-----------
; outputs char to screen.  Char passed in A reg.
; Processes control characters.

putch	.proc	
	tay	
	lda	#0
	tax	
putch1	stx	dspflg
	asl
	asl
	asl
	asl
	tax	
	lda	#cio_command.putchr
putch2	sta	iccom,x		; ICCOM
	lda	#0
	sta	icblen,x	; ICBLL
	sta	icblen+1,x	; ICBLH
	tya	
	jmp	ciov		; CIOV
	.endp

;	ScrUp() - Move cursor up one
;	----------------------------
scrup	.proc
	lda	#character.up
	bne	putch
	.endp


;	ScrDwn() - Move cursor down one
;	-------------------------------
scrdwn	.proc
	lda	#character.down
	bne	putch
	.endp


;	ScrBell() - Bell Char
;	---------------------
scrbell	.proc
	lda	#character.bell
	bne	putch
	.endp


;	ScrLft() - Move cursor left one
;	-------------------------------
scrlft	.proc
	lda	#character.left
	bne	putch
	.endp


;	ScrRt() - Move cursor right one
;	-------------------------------
scrrt	.proc
	lda	#character.right
	bne	putch
	.endp

	.endp		; End of screen