;
;	MAIN.MSC
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified October 18, 1982.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc mainmsc

	.if	.def rom	;Ony import ROM, if it's defined at all
	.use 	rom		;This module heavily depends on the ROM
	.endif

lsh1	.proc			;LShift(val, cnt)
;??a	equ	aflast+1
;??b	equ	aflast
??c	equ	afcur+1
??d	equ	afcur
;??rl	equ	afsize
;??rh	equ	afsize+1
;??t1	equ	addr
;??t2	equ	addr+1
;??sign	equ	token

	sty	??d
lshift	ldy	??d
	beq	??lshret
	stx	??c
??lsh1	asl
	rol	??c
	dey	
	bne	??lsh1
	ldx	??c
??lshret rts	
	.endp

	.proc editor

nextup	.proc			; NextUp()
	ldy	#1
	bne	next		; unconditional branch
	.endp

nextdwn	.proc			; NextDwn()
	ldy	#5
	m_assert_next next	; falls through to next
	.endp


next	.proc			; Next(,,dir)
	jsr	mainio.chkcur
	beq	next1
	lda	(cur),y
	beq	next1
	tax	
	dey	
	lda	(cur),y
	sta	cur
	txa	
	sta	cur+1
next1	rts	
	.endp

curstr	.proc			; CurStr(), does not change Y
	lda	cur
	ldx	cur+1
	.endp


strptr	.proc			; StrPtr(), does not change Y
	clc	
	adc	#6
	sta	arg0
	bcc	??sp1
	inx	
??sp1	stx	arg1
	rts	
	.endp

	.endp

mnum	.proc			; MNum()
	.use compiler
	lda	#0
	sta	afsize
	sta	afsize+1

??mn1	lda	nxttoken
	cmp	#tokens.timesid
	beq	??mn4		; qcode reference
	cmp	#tokens.lbrack
	beq	??mn5
	cmp	#tokens.recordid
	beq	mnvar
	cmp	#tokens.typet
	beq	mnvar
	cmp	#tokens.typet+8
	beq	mnvar
	cmp	#tokens.quote
	beq	??mnstr
	cmp	#undec
	beq	??mnundec
	bcs	mnvar
	jsr	getconst
	bcc	??mn2

mnvar	lda	#1
	jsr	prop.nxtprop
??mnv1	jsr	prop.rstp

??mn2	clc	
	adc	afsize
	sta	afsize
	txa	
	adc	afsize+1
??mn2a	sta	afsize+1
	jsr	lexicon.nextchar
	cmp	#'+'
	bne	??mn2b
	jsr	getnext
	bne	??mn1		; unconditional branch

??mn2b	ldy	#0
	cmp	#'^'
	bne	??mn3
	lda	(afsize),y
	tax	
	iny	
	lda	(afsize),y
	stx	afsize
	jmp	??mn2a

??mn3	dec	choff		; put back character
	lda	afsize
	ldx	afsize+1
;	LDY #0
	rts	

??mn4	jsr	getcdoff	; qcode reference
	jmp	??mn2

??mn5	jsr	getcdoff	; table reference
	pha	
	txa	
	pha	
	bne	??mn8		; unconditional branch

??mnstr	jsr	copystr		; string ref
	jmp	??mn2

??mn6	lda	nxttoken	; body of table
	cmp	#tokens.rbrack
	beq	??mn9
	jsr	getconst
	ldy	#0
	jsr	storevar
	lda	op
	beq	??mn7		; byte?
	iny			; no, word
??mn7	tya	
	jsr	codeincr
??mn8	jsr	getnext
	bne	??mn6		; unconditional branch

??mnundec
	lda	#1
	jsr	prop.nxtprop
	tax	
	iny	
	lda	(props),y
	beq	varerr
	tay
	.if	.def bank
	sta	bank+lbank
	.endif
	lda	#1
	jsr	prop.gprop
	jsr	mainbnk.rstbank
	jmp	??mnv1

varerr	ldy	#errors.varer
adrerr	jmp	mainbnk.splerr

??mn9	pla			; end of table
	tax	
	pla	
	jmp	??mn2
	.endp


getconst .proc			; GetConst(token)
	.use compiler
	ldy	#errors.conster
	cmp	#$81
	bcc	mnum.adrerr
	cmp	#tokens.constt+types.strt
	bcs	mnum.adrerr
	lda	nxtaddr
	ldx	nxtaddr+1
	rts	
	.endp


copystr	.proc			; CopyStr()
	jsr	getcdoff
	pha	
	txa	
	pha	

	ldy	#0
	lda	(nxtaddr),y	; size
	sta	(qcode),y
	tax	
	tay	
??cs1	lda	(nxtaddr),y
	sta	(qcode),y
	dey	
	bne	??cs1

	inx	
	txa	
	bne	??cs2
	inc	qcode+1
??cs2	jsr	codeincr
	inc	choff		; get rid of end quote
	pla	
	tax	
	pla	
	rts	
	.endp




getcdoff .proc			; GetCdOff()
	clc	
	lda	qcode
	adc	codeoff
	pha	
	lda	qcode+1
	adc	codeoff+1
	tax	
	pla	
	rts	
	.endp

storevar .proc			; StoreVar(low, high, index)
	sta	(qcode),y
	iny	
	txa	
	sta	(qcode),y
	rts	
	.endp


;	Command lists have the following structure.
;	.local commands
; 	.word	<unkown command handler>
;	.byte	<table size>
;	.word	<command 1 handler>
;	.byte	<command 1 character>
;	...
;	.endl

lookup	.proc			; Lookup command in command list, IN: <A>=command, <X/Y>=lo/hi byte of command list pointer
	sty	arg1+1		; High byte of pointer

	.if	.def ramzap
	.if	ramzap
	 sta	(arg1),y	; zap RAM if any
	.else	
	 nop	
	 nop	
	.endif
	.endif

	stx	arg1		; Low byte of pointer
	tax			; Save command from A in X
	ldy	#2
	lda	(arg1),y
	tay	
	txa	
??fml1	cmp	(arg1),y
	beq	??fmjmp
	dey	
	dey	
	dey	
	cpy	#2
	bne	??fml1

??fmjmp	dey	
	lda	(arg1),y
	sta	arg4
	dey	
	lda	(arg1),y
	sta	arg3
	jmp	(arg3)
	.endp

alphanum .proc			; AlphaNum(char)
	jsr	alpha
	bne	??anum2

num	cmp	#'0'
	bmi	??anum1
	cmp	#':'
	bmi	??anum2
??anum1	ldx	#0
??anum2	rts	
	.endp

alpha	.proc			; Alpha(char)
	pha	
	ora	#$20
	tax	
	pla	
	cpx	#'a'
	bmi	??alpha1
	cpx	#['z'+1]
	bmi	alpha2
??alpha1 ldx	#0
alpha2	rts	
	.endp


stincr	.proc		; STIncr(size)
	clc	
	adc	symtab
	sta	symtab
	bcc	??s1
	inc	symtab+1
??s1	lda	stmax
	cmp	symtab+1
	bcs	alpha.alpha2	; return

	ldy	#compiler.errors.stspcer		; out of s.t. space
	jmp	mainbnk.splerr
	.endp


codeincr .proc			; CodeIncr(size)
	.use compiler
	clc	
	adc	qcode
	sta	qcode
	bcc	??c1
	inc	qcode+1
??c1	lda	stbase
	cmp	qcode+1
	bcs	alpha.alpha2	; return

cderr	.if	.def bank
	sta	bank+ebank
	.endif
	jsr	splsetup	; reset compiler
	ldy	#errors.cder	; out of qcode space
	jmp	mainbnk.splerr
	.endp

	.proc prop

nxtprop	.proc			; NxtProp(offset)
	ldx	props
	stx	aflast
	ldx	props+1
	stx	aflast+1
	ldx	nxtaddr
	ldy	nxtaddr+1
	bne	gprop
	.endp


cprop	.proc			; CProp(offset)
	ldx	curproc
	ldy	curproc+1
	bne	gprop
	.endp


getprop	.proc			; GetProp(offset)
	ldx	addr
	ldy	addr+1
	.endp


gprop	.proc			; GProp(offset, addr)
	stx	props
	sty	props+1
	ldx	props+1
	clc	
	adc	props
	bcc	??gp1
	inx	
??gp1	sec	
	ldy	#0
	adc	(props),y
	sta	props
	bcc	??gp2
	inx	
??gp2	stx	props+1
	iny	
	lda	(props),y
	tax	
	dey	
	lda	(props),y
	rts	
	.endp


rstp	.proc	
	ldy	aflast
	sty	props
	ldy	aflast+1
	sty	props+1
	rts	
	.endp

	.endp

;	JSRInd(addr)
;	------------
jsrind	.proc
	sta	adress
	stx	adress+1
	jmp	(adress)
	.endp

	.endp			; End of mainmsc
