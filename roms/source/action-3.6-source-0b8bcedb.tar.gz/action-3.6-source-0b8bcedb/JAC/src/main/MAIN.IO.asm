;
;	MAIN.IO
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified September 9, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc mainio

;	Open(device, name, mode, opt)
;	-----------------------------
; returns status

open	.proc	
	stx	arg5
	sty	arg6
	ldy	#cio_command.open
	bne	xiostr
	.endp


;	Print(device, str)
;	------------------
print	.proc
	stx	arg5
	sty	arg6
	ldx	#0
	stx	arg3		;Set AUX1=0
	ldy	#cio_command.putrec
	jsr	xiostr
	bne	print1

	lda	#cio_command.putchr
	sta	$0342,x
	lda	#eol
	jmp	ciov

print1	rts
	.endp


;	Close(device)
;	-------------
close	.proc
	.if	.def ramzap

	ldx	#>rom.ml	; note: address must be non-zero to
	stx	arg6		; fake out zero check in XIOstr

	.if	ramzap
	 sta	(arg5),y
	.else	
	 nop	
	 nop	
	.endif	

	.endif

	ldy	#cio_command.close
	bne	input.input1	; unconditional branch
	.endp

input	.proc			; Input(device, str)
	sty	arg6		; Store pointer in <X,Y> in <adr5;adr>
	ldy	#cio_command.getrec
input1	stx	arg5
	ldx	#0
	stx	arg3		;Set AUX1=0
	m_assert_next xiostr	; falls through to xiostr
	.endp


xiostr	.proc			; XIOstr(device,,cmd,aux1,aux2,str)
	asl
	asl
	asl
	asl
	tax	
	tya	
	sta	iccom,x		; command
	lda	arg3
	beq	??xs1
	sta	icax1,x		; aux1
	lda	arg4
	sta	icax2,x		; aux2
	lda	#0
??xs1	tay
	sta	icblen+1,x

	.if	.not .def ramzap
	lda	iccom,x
	cmp	#cio_command.close ; close does not require a file spec
	beq	no_file_spec
	.endif
	
	lda	(arg5),y
	sta	icblen,x	; size
	beq	print.print1	; return

	clc			; Set icbadr to <arg5/agr>+1 to skip length byte
	lda	arg5
	adc	#1
	sta	icbadr,x	; buf
	lda	arg6
	adc	#0
	sta	icbadr+1,x
no_file_spec
	jmp	ciov
	.endp


output	.proc			; Output(device, str)
	sty	arg6
	ldy	#cio_command.putchr
	bne	input.input1	; unconditional branch
	.endp


dspstr	.proc			; DspStr(prompt, str, invert)
	sty	arg12
	ldy	arg3
	sty	arg13
	ldy	#0
	sty	arg3
	ldy	arg4		; Normal or inverse
	jsr	putstr

	lda	arg6		; PutStr size
	clc	
	adc	lmargin
	sta	colcrs
	jsr	screen.scrrt

	ldy	#0
	lda	(arg12),y
	beq	??ds2
 	sta	arg3
	sty	arg4

??ds1	inc	arg4
	ldy	arg4
	lda	(arg12),y
	eor	arg2
	jsr	screen.scrch
	dec	arg3
	bne	??ds1
??ds2	rts	
	.endp

rdbuf	.proc			; RdBuf(device)
; INC COLOR4			;TODO Remove NOPs
	nop	
	nop	
	nop	
	ldy	#0
	tax	
	lda	#240		; Maximum line size
	sta	(buf),y
	txa	
	ldx	buf
	ldy	buf+1
inputs	jsr	input
	sty	arg0
	lda	icblen,x	; Actual line size
	beq	??rb1
	sec	
	sbc	#1
??rb1	ldy	#0		; Store actual line size-1
	sta	(arg5),y
	ldy	arg0
	rts	
	.endp


wrtbuf	.proc			; WrtBuf(device)
	ldx	buf
	ldy	buf+1
	jmp	print
	.endp



rstcur	.proc			; RstCur() - Restore cursor for current window
	ldy	vars.curwdw
	lda	vars.w1+wcur,y
	sta	cur
	lda	vars.w1+wcur+1,y
	sta	cur+1
	jmp	ldbuf
	.endp

syserr	.proc			; SysErr(,,errnum)
	jsr	dspon
	tya

	.if	feature_error_texts = 1	;TODO
	pha
;	brk
;	brk
	jsr	compiler.error_texts.get_error_text

	lda	#screen_definition.normal
	sta	arg4

	ldy	arg0		; String
	lda	arg1
	sta	arg3

	lda	#<sermsg	; Prompt
	ldx	#>sermsg
	jsr	dspstr
	pla
	.endif
	
	ldx	#0
	jsr	ctostr
	jsr	cmdcol
	lda	#screen_definition.inverse
	sta	arg4
	lda	#>numbuf	; String
	sta	arg3
	ldy	#<numbuf
	lda	#<sermsg	; Prompt
	ldx	#>sermsg
	jsr	dspstr



	jsr	rstcsr
	jsr	rstcol
	jmp	screen.scrbell
	.endp

sermsg	m_string 'Error: '


ctostr	.proc			; CToStr(num) - Cardinal to string
	sta	fr0
	stx	fr0+1
	jsr	ifp		; Cardinal to real
	m_assert_next rtostr	; falls though to rtostr
	.endp

rtostr	.proc			; RToStr() - Real to string, real in FR0
	jsr	fasc
	ldy	#$ff
	ldx	#0
??rts1	iny	
	inx	
	lda	(inbuff),y
	sta	numbuf,x
	bpl	??rts1
	eor	#$80
	sta	numbuf,x
	stx	numbuf
	rts	
	.endp


dspoff	.proc			;DspOff()
	lda	tvdisp
	sta	sdmctl
	sta	dmactl
	rts	
	.endp


dspon	.proc			;DspOn()
	lda	#screen_definition.screen_on
	sta	sdmctl
	sta	dmactl
	lda	vars.bckgrnd	; background color
	sta	color4		; restore background
	rts	
	.endp

printc	.proc			;PrintC(num)
	jsr	ctostr
pnum	lda	device
	ldx	#<numbuf
	ldy	#>numbuf
	jmp	output
	.endp

openchan .proc		;	OpenChan(mode)
	pha	
	lda	chan
	jsr	close
	pla	
	sta	arg3
			; check for default device
	lda	#':'
	ldy	#2
	cmp	(nxtaddr),y
	beq	??oc2
	iny	
	cmp	(nxtaddr),y
	beq	??oc2
			; stuff in D: for device
	clc	
	lda	nxtaddr
	adc	#2
	sta	fr0
	lda	nxtaddr+1
	adc	#0
	sta	fr0+1

	ldy	#0
	lda	(nxtaddr),y	; add 2 to length of string
	adc	#2		;  so we can insert 'D:'
	sta	(nxtaddr),y
	tay	
??oc1	lda	(nxtaddr),y	; move string up...
	sta	(fr0),y
	dey	
	bne	??oc1
	iny	
	lda	#'D'
	sta	(nxtaddr),y
	iny	
	lda	#':'
	sta	(nxtaddr),y

??oc2	lda	chan
	ldx	nxtaddr
	ldy	nxtaddr+1
	jsr	open
	bpl	printbuf
	jmp	mainbnk.splerr	; oopps error in open
	.endp


printbuf .proc			;PrintBuf()
	lda	vars.list
	bne	rtocar.htcr1	; return
	jmp	wrtbuf
	.endp

htocar	.proc			;HToCar(buf,index)
	sty	cix
	sta	arg1
	stx	arg2
	lda	#0
	sta	fr0
	sta	fr0+1

??htc1	ldy	cix
	lda	(arg1),y
	sec	
	sbc	#'0'
	bmi	rtocar.htcrtn
	cmp	#10
	bmi	??htcok
	cmp	#17
	bmi	rtocar.htcrtn
	sbc	#7
	cmp	#16
	bpl	rtocar.htcrtn

??htcok	sta	arg5
	lda	fr0
	ldx	fr0+1
	ldy	#4
	jsr	mainmsc.lsh1
	clc	
	adc	arg5
	sta	fr0
	stx	fr0+1
	inc	cix
	bne	??htc1		; unconditional branch
	.endp

rtocar	.proc			;RToCar() - Real to cardinal
	jsr	fpi
	bcs	??rcerr

htcrtn	lda	fr0
	ldx	fr0+1
	ldy	cix
htcr1	rts	

??rcerr	ldy	#compiler.errors.conster
	jmp	mainbnk.splerr
	.endp

storeal	.proc			;SToReal(str, index) - String to real
	sty	cix
	sta	inbuff
	stx	inbuff+1
	jmp	afp
	.endp

putsp	.proc			;PutSp()
	ldy	#space
	bne	putchar
	.endp

puteol	.proc			;PutEOL()
	ldy	#eol
	.endp

putchar	.proc			;PutChar(,,char)
	lda	device
	jmp	screen.scrch.scrchar
	.endp


;	PutStr(str, invert, offset)
;	---------------------------
putstr	.proc			; Bypasses E: handler

	str_ptr = arg6
	sm_ptr = arg0

	sta	str_ptr
	stx	str_ptr+1
	sty	arg2		;screen_definition.normal/inverse

	sec	
	adc	arg3
	sta	arg4
	bcc	??ps1
	inx	
??ps1	stx	arg5

	jsr	dsploc
	jsr	zapcsr

	ldy	#screen_definition.line_width-1
	lda	arg2
??ps2	sta	(sm_ptr),y	; clear line
	dey	
	bpl	??ps2

	clc			; handle left margin
	lda	sm_ptr
	adc	lmargin
	sta	sm_ptr
	bcc	??ps3
	inc	sm_ptr+1

??ps3	iny			; sets Y to 0
	clc	
	lda	(str_ptr),y
	sbc	arg3
	bcc	??ps10		; no chars

	sta	str_ptr
	tay	
	lda	#0
	sta	str_ptr+1

	sec	
	lda	rmargin
	sbc	lmargin
	cmp	str_ptr
	beq	??ps3a		; handle EOL char
	bcs	??ps4		; length ok

	sta	str_ptr
	ldy	str_ptr		; length too long
??ps3a	lda	#$80
	sta	str_ptr+1

??ps4	lda	arg2
	eor	(arg4),y
	pha	
	and	#$60
	tax	
	pla	
	and	#$9f
	ora	vars.chcvt,x
	sta	(sm_ptr),y
	dey	
	bpl	??ps4

	ldy	str_ptr
	lda	str_ptr+1
	bne	??ps6
	lda	arg2
	bne	??ps7		; no EOL char if inverted
	iny	
??ps5	lda	eolch
	sta	(sm_ptr),y
	jmp	??ps7

??ps6	eor	(sm_ptr),y
	sta	(sm_ptr),y

??ps7	lda	arg3
	beq	??ps9
??ps8	ldy	#0
	lda	(sm_ptr),y
	eor	#screen_definition.inverse
	sta	(sm_ptr),y
??ps9	rts	

??ps10	lda	arg3
	bne	??ps8
	tay	
	beq	??ps5		; unconditional branch
	.endp


;	CmdCol()
;	--------
cmdcol	.proc
	jsr	savecol
	jsr	rstcsr
	ldy	vars.cmdln
	sty	rowcrs
	rts	
	.endp


;	SaveCol()
;	---------
savecol	.proc
	lda	rowcrs
	sta	y
	lda	colcrs
	sta	x
	rts	
	.endp


;	RstCol()
;	--------
rstcol	.proc
	lda	y
	sta	rowcrs
	lda	x
	sta	colcrs
	jsr	zapcsr
lftrt	jsr	screen.scrlft
	jmp	screen.scrrt
	.endp


;	ChkCur()
;	--------
chkcur	.proc
	lda	cur+1
	bne	??ccret
ldtop	lda	top
	sta	cur
	lda	top+1
	sta	cur+1
??ccret	rts	
	.endp


;	LdBuf() load buf
;	----------------
ldbuf	.proc
	jsr	chkcur
	bne	??ldb0
	tay	
	sta	(buf),y
	rts	

??ldb0	jsr	mainmsc.editor.curstr

ldbuf1	ldy	#0
	lda	(arg0),y
	sta	(buf),y
	tay	

??ldb1	lda	(arg0),y
	sta	(buf),y
	dey	
	bne	??ldb1
	rts	
	.endp


;	DspBuf() - display buffer
;	-------------------------
dspbuf	.proc	; IN: <bug,buf+1>=buffer address
	clc	
	lda	indent
	adc	choff
	sta	arg3
	ldy	#screen_definition.normal
	lda	buf
	ldx	buf+1
	jmp	putstr
	.endp



;	DspLoc() get address of display
;	-------------------------------
dsploc	.proc	; OUT: <arg0/arg1>=address of display row in rowcrs
	lda	savmsc
	ldx	savmsc+1
	ldy	rowcrs
	beq	??dlocrt
??dloc1	clc	
	adc	#screen_definition.line_width
	bcc	??dloc2
	inx	
??dloc2	dey	
	bne	??dloc1

??dlocrt
	sta	arg0
	stx	arg1
	rts	
	.endp


;	ZapCsr() get rid of old cursor
;	------------------------------
zapcsr	.proc
	lda	#<csrch
	sta	oldadr
	lda	#>csrch
	sta	oldadr+1
	rts	
	.endp


;	RstCsr() restore char under Csr
;	-------------------------------
rstcsr	.proc	
	ldy	#0
	lda	oldchr
	sta	(oldadr),y
	rts	
	.endp

	.endp		; end of mainio