;
;	MAIN.BNK
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified October 18, 1982.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc mainbnk		; Proxy routines that branch into the correct bank

	.if	.def rom	; Only import ROM, if it's defined at all
	.use 	rom		; This module heavily depends on the ROM
	.endif

	.local statement_definitions

en0	m_statement 'Error',$c0, error
	.byte	3,138,138,138
en1	m_statement 'EOF',$9a, eof
en2	m_statement 'color',$8a, fildat
en3	m_statement 'LIST',$8a, vars.list
en4	m_statement 'device',$8a, device
en5	m_statement 'TRACE',$8a, vars.trace

	.endl

cstart	.proc				; CStart()
	.if	.def bank
	ldy	#rom.ebank
	sty	curbank
	sty	bank+ebank
	.endif
	jmp	editor.start
	.endp


getname	.proc				; GetName(char)
	.if	.def bank
	sta	bank+lbank
	.endif
	jsr	lgetname
	m_assert_next rstbank		; falls into rstbank
	.endp


rstbank	.proc				; RstBank()
	.if	.def bank
	php	
	pha	
	tya	
	ldy	curbank
rbank1	sta	bank,y
	tay	
	pla	
	plp
	.endif
init	rts	
	.endp



;	------------
run_	.proc			; Run(address)
	ldy	#<splerr	; Reset Error routine to default handler
	sty	error+1
	ldy	#>splerr
	sty	error+2
	jsr	lproceed
	jsr	mainmsc.jsrind
	jmp	editbank
	.endp


compile	.proc			; Compile()
	.if	.def bank
	ldy	#cbank
	sty	curbank
	sty	bank+cbank
	.endif
	jsr	compiler.ccompile
	.endp


editbank .proc			; EditBank()
	.if	.def bank
	php	
	pha	
	tya
	ldy	#ebank
	sty	curbank
	jmp	rstbank.rbank1
	.else
	rts
	.endif
	.endp


getalias .proc			; GetAlias()
	lda	#1
	jsr	mainmsc.prop.getprop
	cpx	#0
	beq	??gal1
	sta	addr
	stx	addr+1
	.if	.def bank
	sta	bank+lbank
	.endif
	lda	#0
	jsr	mainmsc.prop.getprop
	sta	token
	jmp	rstbank

??gal1	jmp	mainmsc.mnum.varerr
	.endp


gnlocal	.proc			; GNlocal()
	.if	.def bank
	sta	bank+lbank
	.endif
	jsr	lgetname.lgnlocal
	jmp	rstbank
	.endp


cstmtlst .proc			; CStmtList()
	.if	.def bank
	ldy	#cbank
	sty	curbank
	sta	bank+cbank
	.endif
	jsr	compiler.ccompile.stmtlist
	jmp	editbank
	.endp


mgett1	.proc	
	jsr	editbank
	jsr	editor.window.gettemp.gett1
	.endp



lproceed .proc			; LProceed()
	.if	.def bank
	ldy	#lbank
	sty	curbank
	sty	bank+lbank
	.endif
	rts	
	.endp


options	.proc	
	jsr	lproceed
	jsr	lib.libopt.setopts
	jmp	editbank
	.endp


getkey	.proc
	.if	.def bank
	sta	bank+lbank
	.endif
	jsr	lib.libkey.lgetkey
	jmp	rstbank
	.endp


splerr	.proc
	.if	.def bank
	sta	bank+lbank
	.endif
	jmp	lib.lsplerr
	.endp


emloop	.proc	
	jsr	editbank
	jmp	editor.monitor.mloop
	.endp


getargs	.proc	
	pha			; save arg type load flag
	.if	.def bank
	sty	bank+lbank
	.endif
	lda	#1
	jsr	mainmsc.prop.getprop
	sta	addr
	stx	addr+1

	pla	
	bne	??ga2		; don't load arg types

	sta	abt		; A=0
	sta	abt+1		; flag as temp args
	sta	abt+2		; (default)

	ldy	#2
	lda	(props),y
	sta	vars.numargs
	beq	??ga2
	tax	
	cpx	#9
	bcs	??ga2
??ga1	 iny	
	 lda	(props),y
	 dex	
	 sta	argtypes,x	; args inverted
	 bne	??ga1
??ga2	jmp	rstbank
	.endp


prth	.proc			; call only from LBANK!
	.if	.def bank
	sty	bank+ebank
	.endif
	jsr	editor.monitor.printh
	.if	.def bank
	sty	bank+lbank
	.endif
	jmp	lib.libio.chkerr
	.endp


; go directly to DOS, do NOT pass GO,
; do NOT collect $200, but setup LIB
;------------------------------------
dret	.proc			; Dret()
	jsr	lproceed
	jmp	(dosvec)
	.endp

	.endp			; End of mainbnk