;	@com.wudsn.ide.asm.mainsourcefile=ACTION-Editor.asm

	.proc EXTCLI		;Check for External Command Line Interface

	jsr once
	lda #$60		;Disable procedure
	sta extcli
	rts

	icl "libsrc\asminc\atari.inc"

ptr1	= $a0
ptr2	= $a2

	icl "libsrc\libsrc\atari\dosdetect.s"
	icl "libsrc\libsrc\atari\getargs.s"

__argc	.byte 0
__argv	.word 0

	.proc once
	jsr detect
	jsr initmainargs

	lda __argc
	cmp #2			;1st parameter for command itself, 2nd parameter for file name
	bne no_file

	mwa __argv ptr1
	ldy #1*2		;Pointer to 2nd parameter
	mva (ptr1),y ptr2
	iny
	mva (ptr1),y ptr2+1
	
	ldy #0
loop	lda (ptr2),y
	cmp #EOL
	beq last
	iny
	sta inbuf,y
	jmp loop

last	sty inbuf		;First byte in the buffer is the buffer length
	cpy #4			;Less than 4 characters?
	bcc no_file
	inc iscli		;Set ISCLI flag

no_file	rts

	.endp

	.endp

