;
;	ACTION.ASM - Plain 16k ROM Version, cartridge type 2
;
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=ACTION-ROM-Plain-16k.asm

	icl	"ACTION.DEF.asm"
	icl	"EDIT.DEF.asm"

	icl	"main/MAIN.IO.asm"
	icl	"main/SCREEN.MAC.asm"
	icl	"main/MAIN.MSC.asm"
	icl	"main/MAIN.BNK.asm"

	.local editor
	icl	"editor/EDIT.asm"
	icl	"editor/EDIT.FND.asm"
	icl	"editor/EDIT.SUB.asm"
	icl	"editor/EDIT.TAB.asm"
	icl	"ampl/AMPL.MON.asm"
	.endl
	m_info	editor

	icl	"ampl/AMPL.INI.asm"
	icl	"ampl/AMPL.SEG.asm"
	icl	"ampl/AMPL.PF.asm"
	icl	"ampl/AMPL.ARR.asm"
	icl	"ampl/AMPL.CGU.asm"
	icl	"ampl/AMPL.MTH.asm"
	icl	"ampl/AMPL.SYM.asm"

	.local lib
	icl	"lib/SPL.ERR.asm"
	icl	"lib/LIB.KEY.asm"
	icl	"lib/LIB.IO.asm"
	icl	"lib/LIB.GR.asm"
	icl	"lib/LIB.MSC.asm"
	icl	"lib/LIB.STR.asm"
	icl	"lib/LIB.STM.asm"
	icl	"lib/LIB.OPT.asm"
	.endl
	m_info	lib

	.local	compiler
	icl	"compiler/COMPILER-DEF.asm"
	icl	"compiler/LEXICON.asm"
	icl	"compiler/COMPILER.asm"
	.endl
	m_info compiler
