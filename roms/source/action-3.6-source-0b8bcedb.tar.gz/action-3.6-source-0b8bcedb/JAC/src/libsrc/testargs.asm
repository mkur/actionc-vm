;
;	Test program to test command line parameter passing.
;

	icl "asminc\atari.inc"

ptr1	= $80


	org $2000

__argc	.byte 0
__argv	.word 0

	icl "libsrc\atari\dosdetect.s"
	icl "libsrc\atari\getargs.s"

	
	.proc main
	jsr detect
	jsr initmainargs
	.byte 2
	.endp
	
	run main
