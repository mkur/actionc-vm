;
;	EDIT.MAN
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified September 8, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

subst	.proc			; Subst()
	jsr	cmd.setsp
	jsr	dsp.savewd
	lda	vars.lastch
	cmp	#$7d
	beq	??s2
	pha	
	lda	#<submsg
	ldx	#>submsg
	ldy	#>subbuf
	sty	arg3
	ldy	#<subbuf
	jsr	window.cmdstr
	pla	
; check for ESC key
	ldx	subbuf
	bne	??s0
	ldx	subbuf+1
	cpx	#character.escape
	beq	??s1
??s0	cmp	#$f8
	beq	??s3		; string already found
	lda	#<formsg
	ldx	#>formsg
	jsr	find.find1
	bne	??s3

??s1	rts	

??s2	jsr	find.find2
	beq	??s1
??s3	lda	#$7d
	sta	vars.curch
	sta	dirtyf		; flag line as dirty
	sec	
	lda	subbuf
	sbc	findbuf		; get delta size
	sta	arg3
	php			; save status for test below
	bcs	??s4
	lda	#1
	sbc	arg3		; negate delta size
??s4	clc	
	adc	buf
	sta	arg0
	lda	#0
	tay	
	adc	buf+1
	sta	arg1
	lda	(buf),y
	plp	
	bcc	??s6		; need to remove space
	beq	??s8		; same size
; need to add space
	tay	
??s5	lda	(buf),y
	sta	(arg0),y
	dey	
	cpy	sp
	bcs	??s5
	bcc	??s8

??s6	sta	arg2
	ldy	sp
	dey	
??s7	iny	
	lda	(arg0),y
	sta	(buf),y
	cpy	arg2
	bcc	??s7

??s8	ldy	sp
	ldx	#0
	beq	??s10
??s9	inx	
	lda	subbuf,x
	sta	(buf),y
	iny	
??s10	cpx	subbuf
	bne	??s9
	clc	
	ldy	#0
	lda	(buf),y
	adc	arg3
	sta	(buf),y
	jmp	chr.rfrshbuf


submsg	m_string 'Substitute? '
formsg	m_string 'for? '

	.endp
