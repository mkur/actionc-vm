;
;	EDIT.CAR
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified June 29, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.if fix_stsp_pages = 0
stsp_pages	= $08		; 2K id space
	.else
stsp_pages	= $10		; 4K id space
	.endif

emjmps	.local			; Initiaalization values for jump tabls jmps 
	rts			; Seg catch all
	.word	0

	.if	.def rom.ebank
	.byte	rom.ebank	; curBank
	.else
	.byte	0
	.endif

	.byte	$df		; stMask
	jmp	mainbnk.splerr	; Error
	.byte	18		; wSize
	.byte	120		; line input max
	.byte	$20		; ChCvt2
	rts			; Exp catch all
	.word	0
	rts			; Dcl catch all
	.word	0
	rts			; CodeGen catch all
	.word	0
	rts			; ArrRef Catch all
zero	.word	0
	rts			; SPLEnd
	.word	0
	jmp	screen.scrbell	; Alarm
	.byte	0		; EOLch (default = space)
	.word	mainmsc.lsh1.lshift	; LSH
	.word	libmath.rshift
	.word	libmath.multi
	.word	libmath.divi
	.word	libmath.remi
	.word	libmath.sargs
	.byte	$60		; ChCvt3
	.byte	$22		; tvDisp
	jmp	chr.insrtch	; normal char
	rts			; ctrl-shift char

	.if	.def rom
serial	.word	rom.serial	; serial number of ROM
				; to be filled in before blowing ROM
	.else
	.word	$0000		; Filler to keep the addresses stable
	.endif

	jmp	compiler.lexicon.getnext.ismt	; STM catch all
	rts			; illegal monitor cmd
	.byte	$86
	.byte	$9d
	.word	istmres		; STMrAdr in EDIT.DEF
	.endl

	m_info emjmps

;Init RTS

start	.proc
	jsr	editio.initkeys	; get keyboard
	lda	warmst
	beq	cold
	lda	chcvt3
	cmp	#$60		; make sure RAM initialized
	bne	cold

;??warm
	lda	vars.mpc	; see where we were
	beq	??w1
	jmp	monitor.mon1	; monitor
??w1	jmp	mem.punt	; editor
	.endp

cold	.proc
	lda	#0
	tay	
??c0	sta	$0480,y		; zero 1 page of RAM
	dey	
	bne	??c0

	ldy	#.len emjmps
??cold1	lda	emjmps-1,y	; init RAM
	dey	
	sta	jmps,y
	bne	??cold1
; STY ChCvt1 ; Y=0

	jsr	einit		; init editor

SPLInit .proc ; init compiler RAM	;TODO This should be a subroutine

	.if	.def ramzap
	.if	ramzap
	jsr	editmain.fmcmd.zap4
	.else	
	nop	
	nop	
	nop	
	.endif
	.endif

	ldx	#stsp_pages	; 2K id space
	stx	vars.stsp

	lda	#0
	ldx	#4
	ldy	vars.bigst	; big s.t. ?
	beq	??si1		; no
	ldx	#6
??si1	jsr	mem.getmem	; get hash table
	sta	stglobal	; qglobal hash table
	stx	stglobal+1
	ldy	vars.bigst	; big s.t. ?
	beq	??si2		; no
	inx	
	inx	
	sta	stg2		; big s.t. hash table
	stx	stg2+1
??si2	inx	
	inx	
	sta	stlocal		; local hash table
	stx	stlocal+1
	m_assert_next editmain.floop
; RTS
	.endp

	.endp