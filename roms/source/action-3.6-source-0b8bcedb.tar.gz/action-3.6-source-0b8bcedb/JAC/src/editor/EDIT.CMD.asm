;
;	EDIT.CMD
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified March 10, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc cmd

front	.proc			; Front()
	sec	
	lda	#0
	sbc	indent
	sta	choff
	jsr	mainio.dspbuf
	lda	lmargin
	jmp	mainio.rstcol+6
	.endp

back	.proc			; Back()
	ldy	#0
	lda	(buf),y
back0	pha	
	clc	
	adc	lmargin
	sec	
	sbc	rmargin
	bcs	??back1
	lda	#1
??back1	sbc	indent
	sta	choff
	jsr	mainio.dspbuf
	sec	
	pla	
	sbc	indent
	sec	
	sbc	choff
	clc	
	adc	lmargin
	jmp	mainio.rstcol+6
	.endp

pgup	.proc			; PgUp()
	sec	
	lda	lnum
	sbc	#2
	ldy	#1
	bne	page		; Uncoditional branch
	.endp

pgdwn	.proc			; PgDwn()
	ldy	#5
	sec	
	lda	#2
	sbc	lnum
	m_assert_next page	; falls into page
	.endp

page	.proc			; Private, IN: <A>=number of lines, <Y>=???
	clc	
	adc	nlines
	sta	arg14
	dec	arg14
	beq	return
	sty	arg13
	jsr	dsp.clnln
loop	ldy	arg13
	jsr	mainmsc.editor.next
	dec	arg14
	bne	loop
return	jmp	dsp.ctrln
	.endp

paste	.proc			; Paste()
	jsr	chr.deltop
	beq	??pret
	stx	dirty
	jsr	dsp.clnln
	jsr	mainmsc.editor.nextup
	sta	cur+1		; tricky, fake out top
	jsr	dsp.savewd.savwd1

	jsr	chr.deltop
??p1	jsr	mainmsc.editor.strptr
	jsr	mainio.ldbuf.ldbuf1
	jsr	mem.instb
	lda	vars.allocerr
	bne	??p2		; check for out of memory
	jsr	chr.delnext
	bne	??p1

??p2	jsr	mainio.rstcur
	ldy	vars.curwdw
	lda	vars.w1+wcur+1,y
	beq	??p3
	jsr	mainmsc.editor.nextdwn
??p3	lda	#0
	jmp	dsp.newpage.npage1

??pret	rts	
	.endp

indntl	.proc			; old IndentL()
	lda	indent
	beq	scrlinit.putrtn	; return
	dec	indent
	jmp	dsp.ctrln
	.endp

indntr	.proc			; old IndentR()
	lda	indent
	bmi	scrlinit.putrtn	; return
	inc	indent
	jmp	dsp.ctrln
	.endp

insrtt	.proc			; was InsertT
; InsrtT() insert/replace toggle
	lda	#<??rmsg
	ldx	#>??rmsg
	inc	insert
	beq	??it1
	lda	#$ff
	sta	insert
	lda	#<??imsg
	ldx	#>??imsg
??it1	jmp	dsp.cmdmsg

??imsg	m_string 'INSERT'
??rmsg	m_string 'REPLACE'
	.endp

scrlinit	.proc	
	sty	arg13
	jsr	dsp.clnln
	beq	??siret

	ldy	arg13
	jsr	mainmsc.editor.next
	beq	??siret		; EOF

	lda	colcrs
	sta	x
; LDA choff
; BEQ ??SI1
	lda	#0
	sta	choff
	jsr	mainio.dspbuf
;??si1
	jmp	mainio.ldbuf

??siret	pla	
	pla	
putrtn	rts	
	.endp

scrlup	.proc			; ScrlUp()
	ldy	#1
	jsr	scrlinit
	dec	lnum
	bmi	??su2
	jmp	screen.scrup

??su2	inc	lnum
	lda	ytop
	sta	y
	jsr	botln
	lda	nlines
	jsr	move.movedwn
	jsr	mainio.rstcol
	jmp	chr.rfrshbuf
	.endp

scrldwn	.proc			; ScrlDwn()
	ldy	#5
	jsr	scrlinit
	ldx	lnum
	inx	
	cpx	nlines
	beq	??sd2
	stx	lnum
	jmp	screen.scrdwn

??sd2	jsr	botln
	stx	y

	lda	nlines
	ldx	ytop
	jsr	move.moveup

	jsr	mainio.rstcol
	jsr	mainio.dspbuf
	jmp	mainio.rstcol
	.endp

botln	.proc			; BotLn()
	clc	
	lda	ytop
	adc	nlines
	tax	
	dex	
escape	rts	
	.endp

chkcol	.proc			; ChkCol()
	jsr	setsp
	ldy	#0
	lda	(buf),y
	cmp	sp
	bcs	chkc1
	jsr	back
	jsr	setsp
	clc	
chkc1	rts	
	.endp

scrllft	.proc			; ScrlLft()
	jsr	chkcol
	lda	lmargin
	cmp	colcrs
	bcc	??sl1

	clc	
	lda	choff
	adc	indent
	beq	chkcol.chkc1

	dec	choff
	jsr	mainio.dspbuf
	jsr	screen.scrrt
??sl1	jmp	screen.scrlft
	.endp

scrlrt	.proc			; ScrlRt()
	jsr	chkcol
	bcc	chkcol.chkc1

	lda	colcrs
	cmp	rmargin
	bcc	??sr2

	inc	choff
	jsr	mainio.dspbuf
	jsr	screen.scrlft
??sr2	jmp	screen.scrrt
	.endp

setsp	.proc			; SetSp()
	sec	
	lda	indent
	adc	choff
	clc	
	adc	colcrs
	sec	
	sbc	lmargin
	sta	sp
	rts	
	.endp

	.proc move		;Private

movedwn	.proc			; MoveDwn(cnt, row)
	ldy	#<[-screen_definition.line_width]
	sty	arg5
	ldy	#>[-screen_definition.line_width]
	bne	move_lines	; Uncoditional branch
	.endp

moveup	.proc			; MoveUp(cnt, row)
	ldy	#<[+screen_definition.line_width]
	sty	arg5
	ldy	#>[+screen_definition.line_width]
	m_assert_next move_lines ; falls into move_lines
	.endp

	.proc	move_lines	; Private, IN: <A>=cnt <X>=row, <arg5>=<line_width, <Y>=>line_width 
	sty	arg6
	sta	arg4
	stx	rowcrs
	jsr	mainio.rstcsr
	jsr	mainio.dsploc	; get display address

	ldx	arg4
	dex	
??mu1	lda	arg0
	sta	arg2
	clc	
	adc	arg5
	sta	arg0
	lda	arg1
	sta	arg3
	adc	arg6
	sta	arg1

	ldy	#screen_definition.line_width-1
??mu2	lda	(arg0),y
	sta	(arg2),y
	dey	
	bpl	??mu2

	dex	
	bne	??mu1
	rts	
	.endp

	.endp

	.endp
