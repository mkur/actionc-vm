;
;	EDIT.MEM
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified March 9, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc mem

getmem	.proc			; GetMem(size)
	clc	
	adc	#4
	sta	afsize
	bcc	??gm0
	inx	
??gm0	stx	afsize+1
??gm1	jsr	allocate+4

	ldx	afcur+1
	beq	gmerr		; no memory allocated !
	clc	
	lda	afcur
	adc	#4
	bcc	??gm2
	inx	

??gm2	rts	

gmerr	ldy	#0
	jsr	mainio.syserr

	lda	vars.sparem
	ldx	vars.sparem+1
	ldy	vars.allocerr
	bne	punt		; really out of memory
	inc	vars.allocerr
	jsr	free
	jmp	??gm1		; retry
	.endp

punt	.proc
	jsr	dsp.savewd		; we're in big trouble
	jmp	monitor.rstwnd
	.endp

freemem	.proc			; FreeMem(addr)
	sec	
	sbc	#4
	bcs	freem1
	dex	
freem1	jmp	free
	.endp

instb	.proc			; InstB()
	lda	cur
	sta	arg3
	lda	cur+1
	sta	arg4
	jsr	instbuf
	sta	cur
	stx	cur+1
	rts	
	.endp

instbuf	.proc			; InstBuf(,,up)
	ldy	#0
	lda	(buf),y
	ldx	buf
	ldy	buf+1
	m_assert_next instln	; falls into instln
	.endp

instln	.proc			; InstLn(sze,sloc,up)
	sta	arg0		; save sze
	stx	arg1		; save sloc
	sty	arg2
	clc	
	adc	#3
	ldx	#0
	jsr	getmem

	clc	
	adc	#2
	sta	arg5
	txa	
	adc	#0
	sta	arg6
	ldy	arg0
	beq	??il1a
??il1	lda	(arg1),y
	sta	(arg5),y
	dey	
	bne	??il1
??il1a	lda	arg0
	sta	(arg5),y

	lda	arg4
	bne	??il4		; up # 0

	lda	top		; down ??= top
	sta	arg5
	ldy	#4		; AFcur(2) ??= down
	sta	(afcur),y
	lda	top+1
	sta	arg6
	iny	
	sta	(afcur),y

	lda	afcur		; top ??= AFcur
	sta	top
	lda	afcur+1
	sta	top+1

	ldy	#0		; AFcur(0) ??= 0
	tya	
	sta	(afcur),y
	iny	
	sta	(afcur),y

??il2	lda	arg6
	bne	??il3		; down # 0
	lda	afcur		; bot ??= AFcur
	sta	bot
	ldx	afcur+1
	stx	bot+1
	rts	

??il3	ldy	#1
	lda	afcur+1		; @down ??= AFcur
	sta	(arg5),y
	dey	
	lda	afcur
	sta	(arg5),y
	ldx	afcur+1
	rts	

??il4	ldy	#4
	lda	(arg3),y
	sta	arg5		; down ??= Next(up)
	sta	(afcur),y	; AFcur(2) ??= down
	lda	afcur
	sta	(arg3),y	; up(2) ??= AFcur
	iny	
	lda	(arg3),y
	sta	arg6
	sta	(afcur),y
	lda	afcur+1
	sta	(arg3),y

	ldy	#0
	lda	arg3
	sta	(afcur),y
	iny	
	lda	arg4
	sta	(afcur),y

	jmp	??il2
	.endp

delcur	.proc			; DelCur()
	lda	cur
	ldx	cur+1
	jsr	delln
	sta	cur
	stx	cur+1
dln1	rts	
	.endp

delln	.proc			; DelLn(lineptr)
	cpx	#0
	beq	delcur.dln1
	sta	arg0
	stx	arg1
	ldy	#4
	lda	(arg0),y
	sta	arg4		; down ??= Next(ptr)
	iny	
	lda	(arg0),y
	sta	arg5

	ldy	#0
	lda	(arg0),y
	sta	arg2		; up ??= Prev(ptr)
	iny	
	lda	(arg0),y
	sta	arg3

	bne	??dln2		; up # 0
	lda	arg4
	sta	top		; top ??= down
	lda	arg5
	sta	top+1
	jmp	??dln3

??dln2	ldy	#4
	lda	arg4
	sta	(arg2),y	; up(2) ??= down
	iny	
	lda	arg5
	sta	(arg2),y

??dln3	lda	arg5
	bne	??dln4		; down # 0
	lda	arg2
	sta	bot		; bot ??= up
	lda	arg3
	sta	bot+1
	jmp	??dln5

??dln4	ldy	#0
	lda	arg2
	sta	(arg4),y	; down(0) ??= up
	iny	
	lda	arg3
	sta	(arg4),y

??dln5	lda	arg0
	ldx	arg1
	jsr	free

	lda	arg2
	ldx	arg3
	rts	
	.endp

	.endp			; End of mem