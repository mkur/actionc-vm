;
;	EDIT.TAB
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified March 9, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

tab	.proc			; Tab()
	jsr	cmd.setsp
	jsr	tabloc.tabpos

??t1	lda	tabmap,x
	beq	??t3
	and	??onbit,y
	beq	??t2
; found tab setting
	sty	arg0
	txa	
	asl
	asl
	asl
	ora	arg0
	jmp	cmd.back.back0	; do the tab

??t2	iny	
	cpy	#8
	bmi	??t1
??t3	ldy	#0
	inx	
	cpx	#15
	bmi	??t1
	rts	

??onbit	.byte	$80,$40,$20,$10,8,4,2,1,0
??offbit	.byte	$7f,$bf,$df,$ef,$f7,$fb,$fd,$fe,$ff


settab	.proc
	jsr	tabloc
	lda	tabmap,x
	ora	??onbit,y
	sta	tabmap,x
	rts	
	.endp

clrtab	.proc
	jsr	tabloc
	lda	tabmap,x
	and	??offbit,y
	sta	tabmap,x
	rts	
	.endp

	.proc tabloc			; Private
	jsr	cmd.setsp
	sec	
	sbc	#1
tabpos
	tay	
	lsr
	lsr
	lsr
	tax	
	tya	
	and	#7
	tay	
	cpx	#15
	bmi	??tp1
	ldy	#8
??tp1	rts
	.endp

	.endp	
