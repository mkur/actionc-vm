;
;	EDIT.INI
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 29, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc editio

getstr	.proc			; GetStr(prompt, str, invert)
	jsr	mainio.dspstr
??gs1	jsr	mainbnk.getkey
	tax	

	cpx	#character.backspace
	beq	??gs3		; backspace

	cpx	#character.clear
	beq	??gs3		; clear

??gs1a	ldy	#0
	clc	
	lda	(arg12),y
	adc	#1

	cpx	#character.escape ; ESC
	beq	??gs1b

	cpx	#eol
	beq	??gs2

	cpy	arg3		; first char?
	beq	??gs3		; yes, clear line

	stx	arg3
	ldx	colcrs
	cpx	rmargin
	bcs	??gs1		; don't go off screen

	sta	(arg12),y
	tay	
	lda	arg3
	sta	(arg12),y
	eor	arg2
	jsr	screen.scrch
	jmp	??gs1

??gs1b	lda	#0
	sta	vars.curch
	sta	(arg12),y
	iny	
	tya	
??gs2	tay	
	txa			; EOL
	sta	(arg12),y
	rts	

??gs3	stx	arg3
??gs4	ldy	#0
	lda	(arg12),y
	beq	??gs5
	sec	
	sbc	#1
	sta	(arg12),y

	jsr	screen.scrlft

	lda	#$20
	eor	arg2
	jsr	screen.scrch

	jsr	screen.scrlft
	ldx	arg3
	cpx	#$7e
	bne	??gs4
	beq	??gs1

??gs5	cpx	#$7d
	beq	??gs1
	bne	??gs1a		; Unconditional branch
	.endp

fread	.proc			; FRead()
	lda	#0
	sta	inbuf
	lda	#<rdmsg
	ldx	#>rdmsg
	ldy	#4
	jsr	fopen

??frd1	lda	#1
	jsr	mainio.rdbuf
	bmi	??fr3
	jsr	mem.instb
	lda	vars.allocerr
	beq	??frd1
	ldy	#compiler.errors.fileer	; file too big
	bne	??fr4

??fr3	cpy	#cio_error.eof	; EOF
	beq	??fr5
??fr4	jsr	mainio.syserr
??fr5	jsr	fwrite.fw2
	jmp	dsp.ctrln

rdmsg	m_string 'Read? '
	.endp

fwrite	.proc			; FWrite()
	lda	#<wrtmsg
	ldx	#>wrtmsg
	ldy	#8
	jsr	fopen

	jsr	mainio.chkcur.ldtop
	beq	??fw3
??fw1	jsr	mainio.ldbuf

; INC COLOR4 ; let user know we're here
	nop	;TODO Remove to free RAM
	nop	
	nop	

	lda	#1
	jsr	mainio.wrtbuf
	bmi	??fw3
	jsr	mainmsc.editor.nextdwn
	bne	??fw1

	lda	#0
	sta	dirty
fw2	lda	#1
	jsr	mainio.close
	jsr	mainio.rstcur
	jmp	mainio.dspon

??fw3	jsr	mainio.syserr
	jmp	fw2

wrtmsg	m_string 'Write? '
	.endp

fopen	.proc			; FOpen(prompt, mode)
	sta	arg10
	stx	arg11
	sty	vars.opmode

; JSR ClnLn ; in SaveWd
	jsr	dsp.savewd
	jsr	mainio.rstcsr

	ldy	#<inbuf
	lda	#>inbuf
	sta	arg3
	lda	arg10
	ldx	arg11
	jsr	window.cmdstr

	lda	#1
	jsr	mainio.close
	ldy	inbuf
	beq	??fo7
	ldx	vars.opmode
	lda	#':'
	cmp	inbuf+2
	beq	??fo2
	cmp	inbuf+3
	beq	??fo2
	iny	
	iny	
	sty	inbuf
??fo1	lda	inbuf,y
	sta	inbuf+2,y
	dey	
	bne	??fo1
	lda	#':'
	sta	inbuf+2
	bne	??fo3		; unconditional branch

??fo2	lda	inbuf+1
	cmp	#'?'		; read directory?
	bne	??fo4		; no
	ldx	#6
??fo3	lda	#'D'
	sta	inbuf+1

??fo4	stx	arg3
	jsr	mainio.dspoff
	.if fix_cio_aux2=1
	mva #0  arg4		; Set AUX2=0
	lda	#1		; Channel
	.else
	lda	#1		; Channel
	sta	arg4		; clear high bit for cassette
	.endif
	ldx	#<inbuf
	ldy	#>inbuf
	jsr	mainio.open
	bmi	??fo6
	lda	arg3		; see if directory
	eor	#6
	bne	??fo5
	sta	inbuf		; clear inbuf
??fo5	rts	

??fo6	pla	
	pla			; pop return
	jmp	mainio.syserr

??fo7	pla	
	pla	
	rts	
	.endp

initkeys	.proc		; Initialize keyboard
	lda	#cio_channel.seven
	jsr	mainio.close

	lda	#cio_mode.read
	sta	arg3		; read only
	lda	#cio_channel.seven
	ldx	#<keybd
	ldy	#>keybd
	jmp	mainio.open

keybd	m_string 'K:'
	.endp

gotkey	.proc			; Test if key in buffer
	lda	ch		; key down?
	eor	#$ff
	rts
	.endp

	.endp	; End of editio