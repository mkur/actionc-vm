;
;	EDIT.TAB
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified March 16, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc tag

settag	.proc			; SetTag()
	jsr	tagid

	lda	tempbuf
	beq	notag

	jsr	dsp.clnln
	lda	tempbuf+1
	jsr	gettag
	bne	??st1		; tag already exists

; get a new tag
	lda	#8
	jsr	allocate
	ldy	#1
	lda	vars.taglist+1
	sta	(afcur),y
	dey	
	lda	vars.taglist
	sta	(afcur),y
	lda	afcur
	sta	vars.taglist
	ldx	afcur+1
	stx	vars.taglist+1

??st1	ldy	#4
	lda	tempbuf+1
	sta	(afcur),y
	iny	
	lda	cur
	sta	(afcur),y
	iny	
	lda	cur+1
	sta	(afcur),y
	iny	
	jsr	cmd.setsp
	sta	(afcur),y
; flag line as taged
	ldy	#3
	lda	(cur),y
	ora	#screen_definition.inverse
	sta	(cur),y
	rts
	.endp	

notag	.proc			; NoTag() - private
	lda	#<??ntmsg
	ldx	#>??ntmsg
	jmp	dsp.cmdmsg

??ntmsg	m_string 'tag not set'
	.endp

tagid	.proc			; TagId() - private
	lda	#<??stmsg
	ldx	#>??stmsg
	jmp	window.gettemp

??stmsg	m_string 'tag id: '
	.endp


loctag	.proc			;LocTag()
	jsr	tagid
	lda	tempbuf
	beq	gettag.??ltret
	jsr	dsp.clnln
	lda	tempbuf+1
	jsr	gettag
	beq	notag
	ldy	#6
	lda	(afcur),y
	tax	
	dey	
	lda	(afcur),y
	jsr	findln
	beq	notag
	ldy	#3
	lda	(arg2),y
	bpl	notag
	ldy	#7
	lda	(afcur),y
	sta	sp
	lda	arg2
	sta	cur
	ldx	arg3
	stx	cur+1
	jmp	find.found
	.endp

gettag	.proc				 ; GetTag(tag) - private
	sta	arg0
	lda	vars.taglist
	ldx	vars.taglist+1
	bne	??gt2
??ltret	rts	

??gt1	ldy	#4
	lda	(afcur),y
	cmp	arg0
	beq	??gt3
	ldy	#1
	lda	(afcur),y
	tax	
	dey	
	lda	(afcur),y
??gt2	sta	afcur
	stx	afcur+1
	txa	
	bne	??gt1
??gt3	ldx	afcur+1
	rts	
	.endp

freetags	.proc		; FreeTags()
	lda	vars.taglist
	ldx	vars.taglist+1
	beq	??ft2
??ft1	sta	afbest
	stx	afbest+1
	ldy	#0
	lda	(afbest),y
	sta	arg0
	iny	
	lda	(afbest),y
	sta	arg1
	jsr	free.free1
	lda	arg0
	ldx	arg1
	bne	??ft1
	stx	vars.taglist+1
??ft2	rts	
	.endp

findln	.proc			; FindLn(line) - private
	sta	arg0
	stx	arg1
	lda	top
	ldx	top+1
	bne	??fl2
	rts	

??fl1	ldy	#5
	lda	(arg2),y
	tax	
	dey	
	lda	(arg2),y
??fl2	sta	arg2
	stx	arg3
	cmp	arg0
	bne	??fl3
	cpx	arg1
	beq	??fl4
??fl3	txa	
	bne	??fl1
??fl4	ldx	arg3
	rts
	.endp

	.endp			; End of tag