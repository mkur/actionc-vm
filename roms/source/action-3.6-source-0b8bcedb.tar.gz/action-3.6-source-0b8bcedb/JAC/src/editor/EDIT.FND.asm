;
;	EDIT.FND
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified May 4, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

find	.proc			; Find()
	jsr	cmd.setsp
	jsr	dsp.savewd
	lda	vars.lastch
	cmp	#$f8
	beq	find2
	lda	#<findmsg
	ldx	#>findmsg
find1	ldy	#>findbuf
	sty	arg3
	ldy	#<findbuf
	jsr	window.cmdstr
	lda	#$f8
	sta	vars.curch

find2	lda	findbuf
	beq	??f7

??f2	ldy	#0
	lda	(buf),y
	tay	
	iny	
	sty	arg0

??f3	ldy	sp
	iny	
	cpy	arg0
	bcs	??f5
	sty	sp
	ldx	#0

??f4	lda	(buf),y
	inx	
	cmp	findbuf,x
	bne	??f3
	iny	
	cpx	findbuf
	beq	found
	cpy	arg0
	bcc	??f4

??f5	jsr	mainmsc.editor.nextdwn
	beq	??f6
	jsr	mainio.ldbuf
	lda	#0
	sta	sp
	beq	??f2

??f6	sta	vars.curch
	jsr	mainio.rstcur
	jsr	mainio.ldbuf
	lda	#<notfnd
	ldx	#>notfnd
	jsr	dsp.cmdmsg
	lda	#0
??f7	sta	vars.curch
	rts	

found	jsr	dsp.ctrln
	ldy	sp
	dey	
	tya	
	jsr	cmd.back.back0
	lda	#$fe
	rts	

notfnd	m_string 'not found'
findmsg	m_string 'Find? '

	.endp

