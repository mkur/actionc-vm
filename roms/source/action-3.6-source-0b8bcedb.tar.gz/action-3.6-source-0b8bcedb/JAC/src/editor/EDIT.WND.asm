;
;	EDIT.WND
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 6, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc window

wind1	.proc			; Wind1()
	lda	vars.curwdw
	beq	wdret
	lda	#0
	pha	
	m_assert_next swapwd	; falls into swapwd
	.endp

swapwd	.proc			; SwapWd()
	jsr	savworld
	pla	
	jmp	rstworld
	.endp

wind2	.proc			; Wind2()
	lda	vars.curwdw
	bne	wdret
	lda	vars.numwd
	bne	??w2
	jmp	w2init

??w2	lda	#vars.w2-vars.w1
	pha	
	bne	swapwd		; Unconditional branch
	.endp

savworld	.proc		; SavWorld()
	jsr	dsp.clnln
	jsr	mainio.savecol
	jsr	mainio.rstcsr
	jsr	cmd.setsp
	jmp	dsp.savewd

	.endp

wdret	rts			; Return from differen routines nearby


clear	.proc			; Clear()
	jsr	alarm
	lda	#<clearmsg
	ldx	#>clearmsg
	jsr	yesno
	bne	wdret
clr0	jsr	dsp.clnln
	lda	dirty
	beq	clr1
; JSR Alarm
	lda	#<dirtymsg
	ldx	#>dirtymsg
	jsr	yesno
	bne	wdret
clr1	jsr	tag.freetags	; get rid of tags
	lda	bot
	ldx	bot+1
??clr2	jsr	mem.delln
	bne	??clr2
	stx	cur+1
	stx	dirty
	stx	dirtyf
	stx	inbuf
	jmp	dsp.newpage
	.endp

rstworld	.proc		; RstWorld(window)
	sta	vars.curwdw
	jsr	dsp.rstwd
	jsr	mainio.ldbuf
	jmp	mainio.rstcol
	.endp

delwd	.proc			; DelWd()
	lda	vars.numwd
	beq	wdret
	jsr	alarm
	lda	#<delmsg
	ldx	#>delmsg
	jsr	yesno
	bne	wdret
	jsr	clear.clr0
	lda	dirty
	bne	wdret
	ldy	#0
	sty	vars.numwd
	cpy	vars.curwdw
	bne	delwd2
	ldy	#vars.w2-vars.w1
delwd2	sty	vars.curwdw
	jsr	dsp.rstwd
	jmp	winit1
	.endp

clearmsg m_string'CLEAR? '
delmsg	 m_string 'Delete window? '
dirtymsg m_string'Not saved, Delete? '

gettemp	.proc			; GetTemp(msg)
	ldy	#0
gett1	sty	tempbuf
	ldy	#>tempbuf
	sty	arg3
	ldy	#<tempbuf
	m_assert_next cmdstr	; falls into cmdstr
	.endp

cmdstr	.proc			; CmdStr(msg, buf)
	sta	arg0
	sty	arg2
	jsr	mainio.cmdcol
	lda	#$80
	sta	arg4
	lda	arg0
	ldy	arg2
	jsr	editio.getstr
	jsr	mainio.rstcsr
	jmp	mainio.rstcol
	.endp

yesno	.proc			; YesNo(msg)
	jsr	gettemp
	ldy	tempbuf
	bne	??yn1
	iny	
	rts	

??yn1	lda	tempbuf+1
	ora	#$20
	cmp	#'y'
	rts
	.endp

	.endp			; End of window