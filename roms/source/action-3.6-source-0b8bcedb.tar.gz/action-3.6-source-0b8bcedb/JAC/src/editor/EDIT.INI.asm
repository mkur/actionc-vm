;
;	EDIT.INI
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified May 19, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

minit	.proc			; initialize memory
	lda	memlo
	sta	afbase
	lda	memlo+1
	sta	afbase+1
	lda	#0
	tay	
	sta	(afbase),y
	iny	
	sta	(afbase),y
	sec	
	lda	memtop
	sbc	afbase
	iny	
	sta	(afbase),y
	lda	memtop+1
	sbc	afbase+1
	iny	
	sta	(afbase),y

	lda	#0		; allocate 2 pages of
	ldx	#2		; spare memory
	jsr	allocate
	lda	afcur
	sta	vars.sparem
	ldx	afcur+1
	stx	vars.sparem+1
	rts	
	.endp

zerow	.proc			; initialize window
	lda	#0
	ldx	#15
??zw1	dex			; zero page0 window table
	sta	sp,x
	bne	??zw1
	sta	dirtyf
	sta	inbuf
	tay	
	sta	(buf),y
	rts	
	.endp

w2init	.proc			; W2Init()
	jsr	dsp.ctrln
	lda	wsize
	sta	nlines
	sta	vars.cmdln
	jsr	window.savworld
	lda	#vars.w2-vars.w1
	sta	vars.numwd
	sta	vars.curwdw
	jsr	zerow
	ldy	wsize
	iny	
	sty	ytop
	sec	
	lda	#23
	sbc	wsize
	sta	nlines
	bne	fcmsg		; Unconditional branch
	.endp

einit	jsr	minit

	lda	#0
	ldx	#1
	jsr	allocate	; get edit buffer
	lda	afcur
	sta	buf
	ldx	afcur+1
	stx	buf+1

	lda	#$40
	sta	vars.chcvt

	lda	#<vars.delbuf
	sta	vars.delbuf
	sta	vars.delbuf+4
	lda	#>vars.delbuf
	sta	vars.delbuf+1
	sta	vars.delbuf+5

winit	jsr	zerow

winit1	lda	#23
	sta	nlines
	sta	vars.cmdln
	lda	#0
	sta	vars.curwdw
	sta	ytop

fcmsg	jsr	dsp.ctrln
fcmsg1	lda	#<editc
	ldx	#>editc
	jmp	dsp.cmdmsg

editc	.if	feature_build_version = 1
	.byte	.len build
	.local	build
	.byte	'ACTION! V3.7', feature_build_type, ' build '
	ins	"ACTION-Core.build",+0,16
	.endl
	.else
	m_string 'ACTION! (c)1983 ACS'
	.endif
