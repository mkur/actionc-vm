;
;	EDIT.CMD
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 29, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc dsp		; Display handling
	
	
cmdmsg	.proc			; CmdMsg(msg)
	sta	arg0
	jsr	mainio.cmdcol
	lda	#0
	sta	arg3
	lda	arg0
	ldy	#screen_definition.inverse
	jsr	mainio.putstr
	jmp	mainio.rstcol
	.endp

clnln	.proc			; ClnLn()
	jsr	mainio.chkcur
	lda	dirtyf
	beq	??cll1
	sta	dirty
	lda	#0
	sta	dirtyf
	jsr	mem.delcur
	jsr	mem.instb
??cll1	jmp	mainio.chkcur
	.endp

savewd	.proc			; SaveWd()
	jsr	clnln
savwd1	clc	
	lda	#14
	tax	
	adc	vars.curwdw
	tay	
??sw1	lda	sp,x
	sta	vars.w1,y
	dey	
	dex	
	bpl	??sw1
	rts	
	.endp

rstwd	.proc			; RstWd() restore window
	clc	
	lda	#14
	tax	
	adc	vars.curwdw
	tay	
??rw1	lda	vars.w1,y
	sta	sp,x
	dey	
	dex	
	bpl	??rw1
rw2	rts	
	.endp

endln	.proc			; EndLn()
	jsr	clnln
	lda	bot
	sta	cur
	lda	bot+1
	sta	cur+1
	m_assert_next ctrln	; falls into CtrLn
	.endp

ctrln	.proc			; CtrLn() center line
	lda	#0
	sta	temps
	jsr	clnln
	beq	??cl0
	jsr	mainmsc.editor.nextup
	beq	??cl0
	inc	temps
	jsr	mainmsc.editor.nextup
	beq	??cl0
	inc	temps
??cl0	jsr	newpage
??cl1	lda	temps
	beq	rstwd.rw2	;Return
	jsr	cmd.scrldwn
	dec	temps
	jmp	??cl1
	.endp

topln	.proc			; TopLn()
	jsr	clnln
	jsr	mainio.chkcur.ldtop
	m_assert_next newpage	; falls into newpage
	.endp

newpage	.proc			; NewPage()
	lda	#0
	sta	lnum
npage1	sta	choff
	jsr	mainio.rstcsr	; for command line
	lda	lmargin
	sta	colcrs
; JMP Refresh ; do all the work
	m_assert_next refresh	; falls into refresh
	.endp

refresh	.proc			; Refresh()
	clc	
	lda	ytop
	adc	lnum
	sta	rowcrs
	jsr	mainio.savecol
	jsr	savewd
	inc	rowcrs
	jsr	mainmsc.editor.nextdwn
	sta	arg9
	clc	
	lda	nlines
	sbc	lnum
	sta	arg10
	beq	??cl4

??cl1	ldy	#screen_definition.normal
	lda	indent
	sta	arg3
	ldx	arg9
	beq	??cl5
	jsr	mainmsc.editor.curstr

??cl2	jsr	mainio.putstr
	lda	arg9
	bne	??cl3
	tay	
	sta	(arg0),y
??cl3	inc	rowcrs
	jsr	mainmsc.editor.nextdwn
	sta	arg9
	dec	arg10
	bne	??cl1

??cl4	jsr	mainio.rstcur
	jsr	mainio.rstcol
	jmp	chr.rfrshbuf

??cl5	lda	#<emjmps.zero
	ldx	#>emjmps.zero
	bne	??cl2		; Unconditional branch
	.endp

	.endp			; End of dsp