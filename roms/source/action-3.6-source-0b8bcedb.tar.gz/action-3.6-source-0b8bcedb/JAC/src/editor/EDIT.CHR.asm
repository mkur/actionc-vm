;
;	EDIT.CAR
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified September 8, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc chr		; Character buffer handling

insrtch	.proc			; InsrtCh() char in curCh
	jsr	cmd.setsp
;??padbuf
	ldy	#0
	lda	(buf),y
	cmp	linemax
	bcc	??pbuf0		; test line too long
	jsr	screen.scrbell
	ldy	#0
	lda	(buf),y
??pbuf0	cmp	sp
	bcs	??pbuf2
	sta	arg0
	lda	sp
	sta	(buf),y
	ldy	arg0
	lda	#' '			; pad with spaces
??pbuf1	iny	
	sta	(buf),y
	cpy	sp
	bcc	??pbuf1
??pbret	ldy	sp
	lda	vars.curch
	sta	(buf),y
	lda	#$ff
	sta	dirtyf
	jsr	mainio.dspbuf
	jmp	cmd.scrlrt

??pbuf2	ldx	insert
	beq	??pbret
; move buf right one char
;??movert
	adc	#0	; really 1, carry set
	sta	(buf),y
	tay	
??mrt1	dey	
	lda	(buf),y
	iny	
	sta	(buf),y
	dey	
	cpy	sp
	bne	??mrt1
	beq	??pbret		; unconditional branch
	.endp

insrtsp	.proc			; InsrtSp()
	lda	insert
	pha	
	lda	#$20
	sta	insert
	sta	vars.curch
	jsr	insrtch
	pla	
	sta	insert
	jmp	screen.scrlft
	.endp

insrt	.proc			; Insrt()
	jsr	dsp.clnln
	jsr	mainmsc.editor.nextup
	sta	cur+1		; tricky
	jsr	insert2
	lda	#0
	jmp	dsp.newpage.npage1

insert2	lda	#0
	tay	
insert3	sta	(buf),y
	iny	
	sty	dirty
	jmp	mem.instb
	.endp

csret	.proc			; Control-Shift-Return
; handle pad if any
	jsr	insrtsp
	jsr	delch

	ldy	#0
	lda	(buf),y
	pha	
	jsr	cmd.setsp
	sta	dirtyf		; always non-zero
	sec	
	sbc	#1
	sta	(buf),y
	jsr	dsp.clnln

	pla	
	sta	arg1
	inc	arg1
	lda	#0
	sta	arg0
	beq	??csr2
??csr1	lda	(buf),y
	inc	arg0
	ldy	arg0
	sta	(buf),y
	inc	sp
??csr2	ldy	sp
	cpy	arg1
	bcc	??csr1

	ldy	#0
	lda	arg0
	jsr	insrt.insert3
	jsr	mainmsc.editor.nextup
	jsr	dsp.refresh
	jmp	return.ret2
	.endp

return	.proc			; Return()
	ldx	insert
	bne	csret
	jsr	chkdwn
	bne	ret2

	jsr	insrt.insert2
	jsr	mainmsc.editor.nextup
	jsr	mainio.ldbuf
ret2	jsr	cmd.scrldwn
ret3	jmp	cmd.front
	.endp

delete	.proc			; Delete()
	jsr	dsp.clnln
	lda	vars.delbuf
	ldx	vars.delbuf+1
	stx	dirty
	ldy	vars.lastch
	cpy	#$9c
	beq	??del1
	jsr	delfree
??del1	sta	arg3
	stx	arg4
	jsr	mem.instbuf
	jsr	chkdwn		; last line ?
	bne	??del2		; no, delete it
	tay	
	sta	(buf),y
	iny	
	sty	dirtyf
	bne	return.ret3	; Unconditional branch

??del2	jsr	mem.delcur
	beq	??del3
	jsr	mainmsc.editor.nextdwn
??del3	jsr	mainio.chkcur
	lda	#0
	jmp	dsp.newpage.npage1
	.endp

deltop	.proc			; DelTop()
	lda	vars.delbuf+4
	ldx	vars.delbuf+5
	sta	delnxt
	stx	delnxt+1
	m_assert_next delend	; falls into delend
	.endp

delend	.proc			; DelEnd(ptr)
	cmp	#<vars.delbuf
	bne	de1
	cpx	#>vars.delbuf
de1	rts	
	.endp

delfree	.proc			; DelFree(bot)
	jsr	delend
	beq	delend.de1	; return
	jsr	mem.delln
	bne	delfree		; Unconditional branch
	.endp

delnext	.proc			; DelNext()
	ldy	#5
	lda	(delnxt),y
	tax	
	dey	
	lda	(delnxt),y
	sta	delnxt
	stx	delnxt+1
	jmp	delend
	.endp

undo	.proc			;Undo()
	jsr	mainio.ldbuf
	jmp	cmd.front
	.endp

delch	.proc			; DeleteCh()
	jsr	cmd.chkcol
	bcc	chkdwn.cdwn1
	ldy	#0
	lda	(buf),y
	sta	dirtyf
	sec	
	sbc	#1
	sta	(buf),y
	ldy	sp
??dch1	iny	
	lda	(buf),y
	dey	
	sta	(buf),y
	iny	
	cpy	dirtyf
	bcc	??dch1		; really checking for =
	m_assert_next rfrshbuf	; falls into rfrshbuf
	.endp
rfrshbuf	.proc		; RfrshBuf()
	jsr	mainio.dspbuf
	jmp	mainio.rstcol.lftrt
	.endp

chkdwn	.proc			; ChkDwn()
	jsr	dsp.clnln
	beq	cdwn1
	ldy	#5
	lda	(cur),y
cdwn1	rts	
	.endp

backsp	.proc			; BackSp()
	jsr	cmd.setsp
	cmp	#2
	bcc	chkdwn.cdwn1
bsp1	jsr	cmd.scrllft
	jsr	cmd.setsp
	tay	
	lda	#' '
	sta	(buf),y
	sta	dirtyf
	lda	insert
	bne	delch
	jmp	rfrshbuf
	.endp

csbs	.proc			; Control-Shift-Backspace
	jsr	cmd.setsp
	cmp	#2
	bcs	backsp.bsp1
	jsr	mainio.chkcur
	beq	chkdwn.cdwn1	; no lines at all!
	ldy	#1
	lda	(cur),y
	beq	chkdwn.cdwn1	; no line to merge with
; merge
	jsr	cmd.scrlup
	jsr	cmd.back
	jsr	mainmsc.editor.nextdwn
	sta	dirtyf
	jsr	mainmsc.editor.curstr
	clc	
	ldy	#0
	lda	(buf),y
	sta	arg2
	adc	(arg0),y
	sta	(buf),y
	lda	(arg0),y
	beq	??cb2
	sta	arg3
??cb1	iny	
	sty	arg4
	lda	(arg0),y
	inc	arg2
	ldy	arg2
	sta	(buf),y
	ldy	arg4
	cpy	arg3
	bne	??cb1
??cb2	jsr	mem.delcur
	jmp	dsp.refresh
	.endp

	.endp			; End of chr