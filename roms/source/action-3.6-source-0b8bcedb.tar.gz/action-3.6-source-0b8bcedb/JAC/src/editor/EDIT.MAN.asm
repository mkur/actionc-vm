;
;	EDIT.MAN
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 27, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc editmain

floop	.proc			; Main program for EDIT/FLASH
	lda	vars.allocerr
	beq	??fm1
	lda	#<outmem
	ldx	#>outmem
	jsr	dsp.cmdmsg

??fm1	lda	vars.curch
	sta	vars.lastch
	jsr	mainbnk.getkey

	jsr	fcmsg1
	lda	vars.curch

	ldy	ch1
	cpy	#$c0		; Ctrl-Shft
	bcs	??fmcs

	ldy	vars.lastch
	cpy	#character.escape ; Escape
	bne	??fmch
	cmp	#eol
	beq	floop
	jsr	chr.insrtch
	jmp	floop

??fmcs	ldx	#<fmcscmd
	ldy	#>fmcscmd
	bne	??fmlu

??fmch	ldx	#<fmcmd
	ldy	#>fmcmd

??fmlu	jsr	mainmsc.lookup
	jmp	floop
	.endp

fmcmd	.local
	.word	disptb		; default routine
	.byte	50		; table size
	.word	cmd.scrlup
	.byte	$1c
	.word	cmd.scrldwn
	.byte	$1d
	.word	cmd.scrlrt
	.byte	$1f
	.word	cmd.scrllft
	.byte	$1e
	.word	chr.delch
	.byte	$fe
	.word	chr.backsp
zap4	.byte	$7e
	.word	chr.insrtch
	.byte	$60
	.word	chr.insrtsp
	.byte	$ff
	.word	chr.return
	.byte	eol
	.word	tab
	.byte	$7f
	.word	chr.delete
	.byte	$9c
	.word	cmd.botln.escape
	.byte	character.escape
	.word	window.clear
	.byte	character.clear
	.word	chr.insrt
	.byte	$9d
	.word	tab.settab
	.byte	$9f
	.word	tab.clrtab
	.byte	$9e
	.endl


fmcscmd	.local
	.word	disptb+3	; default
	.byte	71		; table size
	.word	cmd.front
	.byte	$f6
	.word	cmd.back
	.byte	$f7
	.word	cmd.pgup
	.byte	$ce
	.word	cmd.pgdwn
	.byte	$cf
	.word	cmd.indntl
	.byte	$e0
	.word	cmd.indntr
	.byte	$e2
	.word	editio.fread
	.byte	$e8
	.word	editio.fwrite
	.byte	$ee
	.word	cmd.paste
	.byte	$ca
	.word	cmd.insrtt
	.byte	$cd
	.word	monitor
	.byte	$e5
	.word	find
	.byte	$f8
	.word	subst
	.byte	$fe
	.word	window.wind1
	.byte	$df
	.word	window.wind2
	.byte	$de
	.word	window.delwd
	.byte	$fa
	.word	chr.csbs		; Control-Shift-Backspace
	.byte	$f4
	.word	chr.csret		; Control-Shift-Return
	.byte	$cc
	.word	chr.undo
	.byte	$cb
	.word	dsp.topln
	.byte	$f9
	.word	dsp.endln
	.byte	$ea
	.word	tag.settag
	.byte	$ed
	.word	tag.loctag
	.byte	$fd
	.endl

outmem	.local
	.byte  .len text
	.local text
	.byte ' '
	.by	+$80 'Out'
	.byte	' '
	.by	+$80 'of'
	.byte	' '
	.by	+$80 'Memory'
	.endl
	.endl

	.endp
