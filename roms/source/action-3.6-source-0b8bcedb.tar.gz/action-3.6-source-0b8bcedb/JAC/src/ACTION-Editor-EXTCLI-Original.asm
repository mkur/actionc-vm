;	@com.wudsn.ide.asm.mainsourcefile=ACTION-Editor.asm

EXTCLI   LDA $0700
         CMP #'S'
         BNE NOFIL
         CLC
         LDA $0A
         ADC #3
         STA ZJMP+1
         LDA $0B
         ADC #0
         STA ZJMP+2
ZJMP     JSR $E474
         BEQ NOFIL
         LDX #0
         LDY #33
EXC010   LDA ($0A),Y
         CMP #$9B
         BEQ EXC020
         INX
         STA INBUF,X
         INY
         BNE EXC010
EXC020   STX INBUF
         CPX #4
         BCC NOFIL
         INC ISCLI
NOFIL    LDA #$60
         STA EXTCLI
         RTS
