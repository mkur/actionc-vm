;
;	ACTION.ASM - Plain XEX version
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.outputfile=../out/ACTION-XEX.xex

feature_build_version = 1
feature_build_type = 'X'
feature_error_texts = 1
fix_stsp_pages	= 1
fix_save_initad = 1
fix_cio_aux2 = 1

	opt f+

	org	$2000

	icl	"ACTION-Core.asm"

;===============================================================

	.proc	reset_handler
dosini_vector = *+1
	jsr	$ffff
start	jmp	mainbnk.cstart
	.endp

;===============================================================

	.proc	starter		; This code is discarded upon start 
	mva	#0 coldst	; Disable colstart
	sta device ; Ensure the default device for IOCB operations is 0 / E: upon start
	jsr	disable_basic	; Disable BASIC
	mwa	#starter memlo	; Set MEMLO to end of resident executable code
	mwa	dosini reset_handler.dosini_vector
	mwa	#reset_handler dosini
	lda	boot		; Activate DOSINI vector upon RESET
	ora	#1
	sta	boot
	jmp	reset_handler.start

;===============================================================

	.proc 	disable_basic
	lda	portb	; Disable BASIC bit in PORTB for MMU
	ora	#$02
	sta	portb

	lda	#$01	; Set BASICF for OS, so BASIC remains OFF after RESET
	sta	basicf

	ldx	$a000	; Check of the BASIC area is now RAM?
	inc	$a000
	cpx	$a000
	beq	fixed_cartridge



	lda	#$c0	; Check if RAMTOP is already OK
	cmp	ramtop	; This prevent flickering if BASIC is already off
	beq	ramok
	sta	ramtop	; Set RAMTOP to end of BASIC

	lda	$e401	; Open "E:" to ensure screen is not at $9C00
	pha		; This prevents garbage when loading up to $bc000
	lda	$e400
	pha
ramok
fixed_cartridge
	rts
	.endp		; End of disable_basic

;===============================================================

	.endp		; End of starter

	run	starter

