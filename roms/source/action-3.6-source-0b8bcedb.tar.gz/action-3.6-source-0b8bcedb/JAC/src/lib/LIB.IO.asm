;
;	LIB.IO
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified August 13, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libio

;
; PROC ChkErr=*(BYTE result, block, errCode)
; checks for error return from CIO
; Sets EOF(block) to true on error
; does not call Error if EOF error ($88)
; see Hardware manual for CIO details
chkerr	.proc			; PROC ChkErr=*(BYTE result, block, errCode)
	bpl	??ce2
	cpy	#cio_error.eof	; EOF
	beq	??ce1
	tya
	cpy	#cio_error.break ; BREAK key
	beq	break1
	jmp	error

??ce1	txa
	lsr
	lsr
	lsr
	lsr
	tax
	tya
	sta	eof,x
??ce2
	.if	.def ramzap
	.if	ramzap
	dec	chkerr-$10,x
	.else
	nop
	nop
	nop
	.endif
	.endif
	rts
	.endp
;
break1	.proc			; Break1(error)
	ldx	#1
	stx	brkkey
	pha
	jsr	libmisc.break
	pla
	tay
??pfe	rts
	.endp

; PROC PrintF(STRING f, CARD a1, a2, a3, a4, a5)
; outputs a1-a5 to default device
; using format f.  Any non '%' char
; in f is output directly.  '%' char
; is interpreted as follows:
;    %S - output next arg as string
;    %I - output next arg as signed number
;    %U - output next arg as unsigned number
;    %C - output next arg as CHAR
;    %H - output next arg as HEX
;    %% - output '%' char
;    %E - output EOL
; any other char after % is treated
; the same as %U.
;
prtf	.proc		; PROC PrintF(STRING f, CARD a1, a2, a3, a4, a5)
	sta	addr
	stx	addr+1
	sty	temps
	ldy	#0
	lda	(addr),y
	sta	token
	inc	token
	ldx	#13
??pf1	lda	args+2,x
	sta	temps,x
	dex
	bne	??pf1
	stx	lsttoken
	stx	op
??pf2	inc	op
	ldy	op
	cpy	token
	bcs	break1.??pfe	; return
	lda	(addr),y
	cmp	#'%'
	bne	??pf3
	inc	op
	iny
	lda	(addr),y
	cmp	#'%'
	beq	??pf3
	cmp	#'E'
	bne	??pf4
	lda	#eol
??pf3	jsr	put
	jmp	??pf2
;
??pf4	ldy	lsttoken
	inc	lsttoken
	inc	lsttoken
	sta	args
	lda	temps,y
	ldx	temps+1,y
	ldy	args
	cpy	#'C'
	beq	??pf3
	cpy	#'S'
	bne	??pf5
	jsr	prt
	jmp	??pf2
??pf5	cpy	#'I'
	bne	??pf6
	jsr	prti
	jmp	??pf2
??pf6	cpy	#'H'
	bne	??pf7
	jsr	mainbnk.prth
	jmp	??pf2
??pf7	jsr	prtc
	jmp	??pf2
	.endp

; PROC Open(BYTE dev, STRING fileSpec, BYTE mode, aux2)
; opens fileSpec and assigns it to IOCB dev
opn	.proc			; PROC Open(BYTE dev, STRING fileSpec, BYTE mode, aux2)
	pha
	stx	arg1
	sty	arg2
	tay
	lda	#0
	sta	eof,y
	tay
	lda	(arg1),y
	sta	(buf),y
	tay
	iny
	lda	#eol
	bne	??op2		; unconditional branch
??op1	lda	(arg1),y
??op2	sta	(buf),y
	dey
	bne	??op1
	pla
	ldx	buf
	ldy	buf+1
	jsr	mainio.open
	jmp	chkerr
	.endp

; PROC PrintE(STRING str)
; outputs str to default IOCB with EOL
prte	.proc			; PROC PrintE(STRING str)
	stx	arg1
	tax
	ldy	arg1
	lda	device
	m_assert_next prtde	; falls into PrintDE
	.endp


;
; PROC PrintDE(BYTE dev, STRING str)
; outputs str to IOCB dev appended with an EOL
prtde	.proc			; PROC PrintE(STRING str)
	jsr	mainio.print
	jmp	chkerr
	.endp

; PROC Close(BYTE dev)
; closes IOCB dev
clos	.proc			; PROC Close(BYTE dev)
	jsr	mainio.close
	jmp	chkerr
	.endp

; PROC Print(STRING str)
; outputs str to default IOCB
prt	.proc			; PROC Print(STRING str)
	stx	arg1
	tax
	ldy	arg1
	lda	device
	m_assert_next prtd	; falls into PrintD
	.endp

; PROC PrintD(BYTE dev, STRING str)
; outputs str to IOCB dev
prtd	.proc			; PROC PrintD(BYTE dev, STRING str)
	jsr	mainio.output
	jmp	chkerr
	.endp

; PROC InputS(STRING str)
; same as InputSD, but uses default IOCB
ins_	.proc			; PROC InputS(STRING str)
	stx	arg2
	tax
	ldy	arg2
	lda	device
	m_assert_next insd	; falls into InputSD
	.endp

; PROC InputSD(BYTE dev, STRING str)
; see Input, size set to 255
insd	.proc			; PROC InputSD(BYTE dev, STRING str)
	pha
	lda	#255
	sta	arg3
	pla
	m_assert_next inmd	; falls into InputMD
	.endp

; PROC InputMD(BYTE dev, STRING str, BYTE max)
; see Input, size set to max
inmd	.proc			; PROC InputMD(BYTE dev, STRING str, BYTE max)
	pha
	stx	arg1
	sty	arg2
	ldy	#0
	lda	arg3
	sta	(arg1),y
	pla
	ldy	arg2
	m_assert_next ind_	; falls into InputD
	.endp

; PROC InputD(BYTE dev, STRING str)
; inputs str from IOCB dev
; first byte must be set to maximum size
; on return, first byte set to size of string input
ind_	.proc			; PROC InputD(BYTE dev, STRING str)
	jsr	mainio.rdbuf.inputs
	jmp	chkerr
	.endp
;
; BYTE FUNC GetD(BYTE dev)
; inputs character from IOCB dev
getd	.proc			; BYTE FUNC GetD(BYTE dev)
	ldx	#cio_command.getchr
ccio	stx	arg4
	asl
	asl
	asl
	asl
	tax
	lda	arg4
	sta	iccom,x
	lda	#0
	sta	$0348,x
	sta	$0349,x
	tya
	jsr	ciov
	sta	args
	jmp	chkerr
	.endp

; PROC PutE()
; output EOL do default IOCB
pute	.proc			; PROC PutE()
	lda	#eol
	m_assert_next put	; falls into Put
	.endp

; PROC Put(CHAR ch)
; outputs ch to default IOCB
put	.proc			; PROC Put(CHAR ch)
	tax
	lda	device
	m_assert_next putd	; falls into PutD
	.endp

; PROC PutD(BYTE dev, CHAR ch)
; outputs ch to IOCB dev
putd	.proc			; PROC PutD(BYTE dev, CHAR ch)
	stx	arg1
	ldy	arg1
putd1	ldx	#cio_command.putchr
	jmp	getd.ccio
	.endp

; PROC PutDE(BYTE dev)
; outputs EOL to IOCD dev
putde	.proc			; PROC PutDE(BYTE dev)
	ldy	#eol
	bne	putd.putd1	; Unconditional branch
	.endp

; PROC XIOstr(BYTE dev, fill, cmd, aux1, aux2, STRING str)
; see Hardware manual for CIO details
; performs system CIO call where:
;   ICCOM = cmd
;   ICBL = str(0)
;   ICBA = str+1
;   ICAX1 = aux1
;   ICAX2 = aux2
; CIO is not called if str(0)=0
; ICAX1 and ICAX2 are not set if aux1=0
xio	.proc			; PROC XIOstr(BYTE dev, fill, cmd, aux1, aux2, STRING str)
	jsr	mainio.xiostr
	jmp	chkerr
	.endp

; PROC PrintB(BYTE num)
; outputs byte num to default IOCB
prtb	.proc			; PROC PrintB(BYTE num)
	ldx	#0
	m_assert_next prtc	; falls into PrintC
	.endp

; PROC PrintC(CARD num)
; outputs cardinal num to default IOCB
prtc	.proc			; PROC PrintC(CARD num)
	jsr	mainio.printc
	jmp	chkerr
	.endp

; PROC PrintBE(BYTE num)
; same as PrintB except EOL appended
prtbe	.proc			; PROC PrintBE(BYTE num)
	ldx	#0
	m_assert_next prtce	; falls into PrintCE
	.endp

; PROC PrintCE(CARD num)
; same as PrintC except EOL appended
prtce	.proc			; PROC PrintCE(CARD num)
	jsr	prtc
	jmp	pute
	.endp

; PROC PrintBD(BYTE dev, BYTE num)
; output byte num to IOCB dev
prtbd	.proc			; PROC PrintBD(BYTE dev, BYTE num)
	ldy	#0
	m_assert_next prtcd	; falls into PrintCD
	.endp

; PROC PrintCD(BYTE dev, CARD num)
; output cardinal num to IOCB dev
prtcd	.proc			; PROC PrintCD(BYTE dev, CARD num)
	sta	arg0
	txa
	sty	arg2
	ldx	arg2
	jsr	mainio.ctostr
	lda	arg0
	jsr	mainio.printc.pnum+2
	jmp	chkerr
	.endp

; PROC PrintBDE(BYTE dev, BYTE num)
; output num to IOCB dev with EOL
prtbde	.proc			; PROC PrintBDE(BYTE dev, BYTE num)
	ldy	#0
	m_assert_next prtcde	; falls into prtcde
	.endp

; PROC PrintCDE(BYTE dev, CARD num)
; output num to IOCB dev with EOL
prtcde	.proc			; PROC PrintCDE(BYTE dev, CARD num)
	jsr	prtcd
	lda	arg0
	jmp	putde
	.endp
;
; PROC PrintI(INT num)
; outputs integer num to default IOCB
prti	.proc			; PROC PrintI(INT num)
	stx	arg2
	tax
	ldy	arg2
	lda	device
	m_assert_next prtid	; falls into PrintID
	.endp

; PROC PrintID(BYTE dev, INT num)
; outputs integer num to IOCB dev
prtid	.proc			; PROC PrintID(BYTE dev, INT num)
	cpy	#0
	bpl	prtcd
	pha
	stx	arg1
	sty	arg2
	ldy	#'-'
	jsr	putd.putd1
	sec
	lda	#0
	sbc	arg1
	tax
	lda	#0
	sbc	arg2
	tay
	pla
	jmp	prtcd
	.endp

; PROC PrintIE(INT num)
; same as PrintI with EOL
prtie	.proc			; PROC PrintIE(INT num)
	jsr	prti
	jmp	pute
	.endp

; PROC PrintIDE(BYTE dev, INT num)
; same as PrintID with EOL
prtide	.proc			; PROC PrintIDE(BYTE dev, INT num)
	jsr	prtid
	lda	arg0
	jmp	putde
	.endp

; PROC StrB(BYTE n, STRING s)
; convert number to string
strb	.proc			; PROC StrB(BYTE n, STRING s)
	stx	arg2
	sty	arg3
	ldx	#0
	ldy	arg2
	m_assert_next strc	; falls into StrC
	.endp

; PROC StrC(CARD n, STRING s)
; convert number to string
strc	.proc			; PROC StrC(CARD n, STRING s)
	sty	arg2
	jsr	mainio.ctostr
	iny
??strc1 lda	numbuf,y
	sta	(arg2),y
	dey
	bpl	??strc1
	rts
	.endp

; PROC StrI(INT n, STRING s)
; convert number to string
stri	.proc		; PROC StrI(INT n, STRING s)
	cpx	#0
	bpl	strc
	sta	arg0
	stx	arg1
	sty	arg2
	sec
	lda	#0
	sbc	arg0
	tay
	lda	#0
	sbc	arg1
	tax
	tya
	jsr	mainio.ctostr
	inx
	txa
	tay
??s1	lda	numbuf-1,y
	sta	(arg2),y
	dey
	bne	??s1
	txa
	sta	(arg2),y
	iny
	lda	#'-'
	sta	(arg2),y
	rts
	.endp

; input number from default IOCB
; number must be terminated with EOL
inb	.proc			;BYTE FUNC InputB()
	m_assert_next inc_	; falls into inc_
	.endp

inc_	.proc			;CARD FUNC InputC()
	m_assert_next ini_	; falls into ini_
	.endp

ini_	.proc			;INT FUNC InputI()
	lda	device
	m_assert_next inbd	; falls into InputBD
	.endp

; same as InputI, but from IOCB dev
inbd	.proc			;BYTE FUNC InputBD()
	m_assert_next incd	; falls into InputCD
	.endp

incd	.proc;CARD FUNC InputCD()
	m_assert_next inid	; falls into InputID
	.endp

inid	.proc			;INT FUNC InputID(BYTE dev)
	ldx	#19
	stx	numbuf
	ldx	#<numbuf
	ldy	#>numbuf
	jsr	ind_
	lda	#<numbuf
	ldx	#>numbuf
	m_assert_next valb	; falls into ValB
	.endp

; returns numeric value of s
valb	.proc	; BYTE FUNC ValB(STRING s)
	m_assert_next vali	; flls into valc
	.endp

vali	.proc			; INT FUNC ValI(STRING s)
	m_assert_next valc 	; falls into valc
	.endp

valc	.proc			; CARD FUNC ValC(STRING s)
	sta	arg4
	stx	arg5
	ldy	#0
	sty	arg0
	sty	arg1
	sty	arg2
	lda	(arg4),y
	sta	arg3
	inc	arg3
	lda	#32
	iny
??i1	cmp	(arg4),y
	bne	??i2
	iny
	cpy	arg3
	bmi	??i1
??i2	lda	(arg4),y
	cmp	#'-'
	bne	??i3
	sta	arg2
	iny
??i3	cpy	arg3
	bpl	??i6
??i4	lda	(arg4),y
	cmp	#'0'
	bmi	??i6
	cmp	#':'             ; '9'+1
	bpl	??i6
	sec
	sbc	#'0'
	tax
; arg01*10
	lda	arg1
	pha
	lda	arg0
	asl
	rol	arg1
	asl
	rol	arg1
	clc
	adc	arg0
	sta	arg0
	pla
	adc	arg1
	sta	arg1
	asl	arg0
	rol	arg1
	clc
	txa
	adc	arg0		; add in digit
	sta	arg0
	bcc	??i5
	inc	arg1
??i5	iny
	cpy	arg3
	bmi	??i4
??i6	lda	arg2
	beq	??i7
	sec
	lda	#0
	sbc	arg0
	sta	arg0
	lda	#0
	sbc	arg1
	sta	arg1
??i7	rts
	.endp

; PROC Note(BYTE dev, CARD POINTER sector, BYTE POINTER offset)
; returns disk sector and offset in that
; sector of next byte to be read or
; written to IOCB dev
; example:  Note(1, @sect, @pos)
; see Hardware manual
note	.proc			; PROC Note(BYTE dev, CARD POINTER sector, BYTE POINTER offset)
	stx	arg1
	sty	arg2
	asl
	asl
	asl
	asl
	tax
	lda	#cio_command.note
	sta	iccom,x
	jsr	ciov
	jsr	chkerr
	ldy	#0
	lda	icax5,x 	; offset
	sta	(arg3),y
	lda	icax3,x 	; low byte of sector
	sta	(arg1),y
	lda	icax4,x 	; high byte of sector
	iny
	sta	(arg1),y
	rts
	.endp
;
; PROC Point(BYTE dev, CARD sector, BYTE offset)
; Sets next byte to be read or written
; to be byte offset of sector.	File
; must be open for update (mode=12)
; see Hardware manual
point	.proc			; PROC Point(BYTE dev, CARD sector, BYTE offset)
	stx	arg1
	asl
	asl
	asl
	asl
	tax
	tya			; sector+1
	sta	icax4,x
	lda	arg1		; sector
	sta	icax3,x
	lda	arg3		; offset
	sta	icax5,x
	lda	#cio_command.point
	sta	iccom,x
	jsr	ciov
	jmp	chkerr
	.endp

	.endp			; end of libio