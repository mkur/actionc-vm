;
;	SPL.ERR
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 30, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

lsplerr .proc			; SPLErr(,,error)
	lda	top+1
	beq	spler1

; set pointer to error
	ldx	vars.curwdw
	lda	spln
	sta	vars.w1+wsp,x
	lda	curln
	sta	vars.w1+wcur,x
	lda	curln+1
	sta	vars.w1+wcur+1,x

spler1	jsr	mainio.syserr
	jsr	mainio.puteol
	jsr	mainio.printbuf
	lda	#cio_channel.zero
	ldx	#<mainio.sermsg
	ldy	#>mainio.sermsg
	jsr	mainio.output
	lda	#0
	sta	initad+1
	ldx	#<numbuf
	ldy	#>numbuf
	jsr	mainio.print
	jmp	mainbnk.emloop
	.endp
