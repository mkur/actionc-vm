;
;	LIB.MSC
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified November 3, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libmisc
;
;
; BYTE FUNC Rand(BYTE range)
; returns random number between 0 and
; range-1.  If range=0, then a random
; number between 0 and 255 is returned
rand	.proc			; BYTE FUNC Rand(BYTE range)
	ldx	$d20a		; RANDOM
	cmp	#0
	beq	??rand1
	stx	afcur
	ldx	#0
	stx	afcur+1
	jsr	libmath.multi
??rand1 stx	args
	rts
	.endp

; PROC Sound(BYTE v, p, d, vol)
; set voice to specified pitch, distortion,
; and volume.  Assumes volume low  16.
sound	.proc			; PROC Sound(BYTE v, p, d, vol)
	asl
	sty	arg2
	tay
	cmp	#7
	bmi	??snd1
	ldy	#100
	jsr	error
??snd1	txa
	sta	$d200,y
	lda	arg2
	asl
	asl
	asl
	asl
	ora	arg3
	sta	$d201,y
	rts
	.endp

; PROC SndRst()
; reset sound channels
sndrst	.proc			; PROC SndRst()
	lda	sskctl
	and	#$ef		; turn off two tone bit
	sta	sskctl
	sta	skctl
	lda	#0
	ldx	#8
??sr1	sta	audf0,x 	; zero sound regs
	dex
	bpl	??sr1
	rts
	.endp
;
;BYTE FUNC Paddle(BYTE port)
; returns paddle value of port
; Assumes port low  8.
; see LIB.ST
;Paddle TAX
; LDA $D200,X
; STA args
; RTS
;
; BYTE FUNC PTrig(BYTE port)
; returns zero if trigger of paddle
; port is depressed.  Assumes port<8
ptrig	.proc		; BYTE FUNC PTrig(BYTE port)
	ldx	#0
	cmp	#4
	bmi	??pt1
	inx
	and	#3
??pt1	tay
	lda	porta,x
	and	??pt2,y
	sta	args
	rts
;
??pt2	.byte	$04,$08,$40,$80
	.endp
;
; BYTE FUNC Stick(BYTE port)
; returns current value of joystick
; controller port.  Assumes port<4
stick	.proc		; BYTE FUNC Stick(BYTE port)
	ldx	#0
	cmp	#2
	bmi	??stk1
	inx
	and	#1
??stk1	tay
	lda	porta,x
	dey
	bne	??stk2
	lsr
	lsr
	lsr
	lsr
??stk2	and	#$0f
	sta	args
	rts
	.endp
;
;BYTE FUNC STrig(BYTE port)
; returns zero if trigger of joystick
; port is depressed.  Assumes port<4
;
; see LIB.ST
;STrig TAX
; LDA $D010,X
; STA args
; RTS
;
; BYTE FUNC Peek(CARD address)
; returns value stored at address
peek	.proc			;BYTE FUNC Peek(CARD address)
	m_assert_next peekc	; falls into PeekC
	.endp

;CARD FUNC PeekC(CARD address)
; returns value stored at address
peekc	.proc			;CARD FUNC PeekC(CARD address)
	sta	arg2
	stx	arg3
	ldy	#0
	lda	(arg2),y
	sta	args
	iny
	lda	(arg2),y
	sta	args+1
	rts
	.endp

; PROC Poke(CARD address, BYTE value)
; store byte or char value at address
; (single byte store)
poke	.proc			; PROC Poke(CARD address, BYTE value)
	sta	arg0
	stx	arg1
	tya
	ldy	#0
	sta	(arg0),y
	rts
	.endp

; PROC PokeC(CARD address, value)
; store cardinal or integer value at
; address (2 byte store)
pokec	.proc			; PROC PokeC(CARD address, value)
	jsr	poke
	iny
	lda	arg3
	sta	(arg0),y
	rts
	.endp
;
; PROC Zero(BYTE POINTER address, CARD size)
; set memory bytes starting at address
; up to (but not including) address+size
; to zero.  Note this modifies size
; bytes of memory.
mzero	.proc			; PROC Zero(BYTE POINTER address, CARD size)
	pha
	lda	#0
	sta	arg4
	pla
	m_assert_next setblock	; falls into SetBlock
	.endp

; PROC SetBlock(BYTE POINTER address, CARD size, BYTE value)
; set memory bytes starting at address
; up to (but not including) address+size
; to value.  Note this modifies size
; bytes of memory.
setblock	.proc		; PROC SetBlock(BYTE POINTER address, CARD size, BYTE value)
	sta	arg0
	stx	arg1
	sty	arg2
	ldy	#0
	lda	arg4
	ldx	arg3
	beq	??sb3
??sb1	sta	(arg0),y
	iny
	bne	??sb1
	inc	arg1
	dec	arg3
	bne	??sb1
	beq	??sb3
??sb2	sta	(arg0),y
	iny
??sb3	cpy	arg2
	bne	??sb2
	rts
	.endp

; PROC MoveBlock(BYTE POINTER dest, src, CARD size)
; moves size bytes from src through
; src+size-1 to dest through dest+size-1.
; If dest>src and dest<=src+size-1 then
; transfer will not work properly!
moveblock	.proc		; PROC MoveBlock(BYTE POINTER dest, src, CARD size)
	sta	arg0
	stx	arg1
	sty	arg2
	ldy	#0
	lda	arg5
	beq	??mb4
??mb2	lda	(arg2),y
	sta	(arg0),y
	iny
	bne	??mb2
	inc	arg1
	inc	arg3
	dec	arg5
	bne	??mb2
	beq	??mb4
??mb3	lda	(arg2),y
	sta	(arg0),y
	iny
??mb4	cpy	arg4
	bne	??mb3
	rts
	.endp

; PROC Break()
; returns to monitor after saving
; stack pointer in procSP
break	.proc			; PROC Break()
	tsx
	stx	vars.procsp
	ldy	#errors.brker
	tya
	jmp	error
	.endp

ctrace	.proc			; Call Trace handler
; name passed following JSR
	clc
	pla
	adc	#1
	sta	arg10
	pla
	adc	#0
	sta	arg11
; address of name now in arg10-11
; ok, let's print the name
	lda	arg10
	ldx	arg11
	jsr	libio.prt
	lda	#'('
	jsr	libio.put
; now get addr of args
	sec
	lda	arg10
	ldy	#0
	sty	arg15
	adc	(arg10),y
	sta	arg10
	bcc	??ct1
	inc	arg11
??ct1	lda	(arg10),y
	sta	arg12
	iny
	lda	(arg10),y
	sta	arg13
; get number of args
	iny
	lda	(arg10),y
	sta	arg9
	sty	arg14
	beq	??ct7		; no args
??ct2	inc	arg14
	ldy	arg14
	lda	(arg10),y
	bmi	??ct4		; byte
	cmp	#types.cardt
	inc	arg15
	ldy	arg15
	lda	(arg12),y
	tax
	dey
	bcs	??ct5		; cardinal
; integer
	lda	(arg12),y
	jsr	libio.prti
	jmp	??ct6
??ct4	ldx	#0
	ldy	arg15
??ct5	lda	(arg12),y
	jsr	libio.prtc
??ct6	inc	arg15
	dec	arg9
	beq	??ct7		; all done
	lda	#character.comma
	jsr	libio.put
	jmp	??ct2
; setup return
??ct7	clc
	lda	arg10
	adc	arg14
	tax
	lda	arg11
	adc	#0
	pha
	txa
	pha
	lda	#')'
	jsr	libio.put
	jmp	libio.pute
	.endp

	.endp			; end of libmisc
