;
;	LIB.OPT
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 6, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libopt

setopts	.proc

	.proc set_display	; Display On?
	ldx	#domsg-optmsg
	ldy	tvdisp
	jsr	get_yes_or_no
	beq	??do1
	lda	#screen_definition.screen_off
	beq	??do2
??do1	lda	#screen_definition.screen_on
??do2	sta	tvdisp
	.endp

	.proc set_alarm		; Alarm?
	ldx	#amsg-optmsg
	ldy	alarm
	cpy	#opcode.rts_
	jsr	get_yes_or_no
	beq	??a1
	lda	#opcode.rts_	; RTS
	bne	??a2
??a1	lda	#opcode.jmp_abs	; JMP
??a2	sta	alarm
	.endp

	.proc set_case_sensitive ; Case sensitive?
	ldx	#cmsg-optmsg
	ldy	stmask
	cpy	#$df
	jsr	get_yes_or_no
	beq	??c1
	lda	#$df
	bne	??c2
??c1	lda	#$ff
??c2	sta	stmask
	.endp

	.proc set_trace		; Trace On?
	ldx	#tmsg-optmsg
	ldy	vars.trace
	jsr	get_yes_or_no
	beq	??t1
	lda	#0
	beq	??t2
??t1	lda	#$ff
??t2	sta	vars.trace
	.endp

	.proc set_list		; List On?
	ldx	#lstmsg-optmsg
	ldy	vars.list
	jsr	get_yes_or_no
	beq	??lst1
	lda	#0
	beq	??lst2
??lst1	lda	#$ff
??lst2	sta	vars.list
	.endp

	.proc set_window_size	; Set window size
	lda	wsize
	jsr	get_string
	ldx	#wmsg-optmsg
	jsr	get_number
	cmp	#5
	bcs	??w0		; make sure at least 5
	lda	#5
??w0	cmp	#19
	bcc	??w1		; make sure less than 19
	lda	#18
??w1	sta	wsize
	ldx	vars.numwd
	beq	??l1
	sta	vars.w1+wnlns
	tay	
	iny	
	sty	vars.w2+wytop
	sec	
	lda	#23
	sbc	wsize
	sta	vars.w2+wnlns
??l1
	.endp

	.proc set_line_size	; Set line size
	lda	linemax
	jsr	get_string
	ldx	#lmsg-optmsg
	jsr	get_number
	sta	linemax
	.endp

	.proc set_left_margin	; Set left margin
	lda	lmargin
	jsr	get_string
	ldx	#lmmsg-optmsg
	jsr	get_number
	sta	lmargin
	.endp

	.proc set_eol_char	; Set EOL char
	lda	eolch
	tay			; Save ASCII value
	rol			; Convert ASCII to screen code
	rol
	rol
	rol
	and	#3
	tax
	tya
	and	#$9f
	ora	stoa,x
	tay	
	ldx	#emsg-optmsg
	jsr	get_yes_or_no.??yn2
	lda	tempbuf+1
	tay	
	and	#$60
	tax	
	tya	
	and	#$9f
	ora	vars.chcvt,x
	sta	eolch
	.endp
	rts	

	.proc get_yes_or_no
	beq	??yn1			;Determine character for current flag value
	ldy	#'Y'
	bne	??yn2
??yn1	ldy	#'N'
??yn2	sty	tempbuf+1
	ldy	#1
	jsr	gettmpbuf
	lda	tempbuf+1
	ldy	tempbuf
	bne	??yn5
	cmp	#character.escape
	bne	??yn4
exit	pla	
	pla	
??yn4	rts

??yn5	ora	#'a'-'A'		;Convert to lower case
	cmp	#'y'
	rts	
	.end

	.proc get_string
	ldx	#0
	ldy	#>tempbuf
	sty	arg3
	ldy	#<tempbuf
	jmp	lib.libio.strc
	.endp

	.proc get_number
	ldy	tempbuf
	jsr	gettmpbuf
	ldy	tempbuf
	bne	??gn0
	lda	tempbuf+1
	cmp	#character.escape
	beq	get_yes_or_no.exit
??gn0	lda	#<tempbuf
	ldx	#>tempbuf
	jsr	lib.libio.valb
	lda	args
	rts
	.endp


	.macro m_opt_string	; TODO: Why is length 1 larger than normally?
	.byte [.len string]+1
	.local string
	.byte :1
	.endl
	.endm

domsg	m_opt_string 'Display?'

optmsg	equ	domsg-20	; see GetTemp

amsg	m_opt_string 'Bell?'
cmsg	m_opt_string 'Case sensitive?'
tmsg	m_opt_string 'Trace?'
lstmsg	m_opt_string 'List?'
wmsg	m_opt_string 'Window 1 size:'
lmsg	m_opt_string 'Line size:'
lmmsg	m_opt_string 'Left margin:'
emsg	m_opt_string 'EOL char:'

stoa	.local
	.byte	$20,$40,$00,$60
	.endl


gettmpbuf	.proc	
	sty	arg2

; copy string to tempBuf+10
	ldy	#20
??gt1	lda	optmsg+20,x
	sta	tempbuf+10,y
	dex	
	dey	
	bpl	??gt1

; put space at end
	tay	
	lda	#' '
	sta	tempbuf+10,y

	lda	#<(tempbuf+10)
	ldx	#>(tempbuf+10)
	ldy	arg2
	jmp	mainbnk.mgett1
	.endp
	
	.endp

	.endp			; end of libopt