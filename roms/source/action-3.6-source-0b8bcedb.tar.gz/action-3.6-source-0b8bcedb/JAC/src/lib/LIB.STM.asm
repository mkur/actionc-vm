;
;	LIB.STM
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified November 3, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	
	.local statement_definitions

;??en6	m_statement 'PrintF',200,  PrtF ; #117
;	.byte	6,17,12,12,12,12,12
??en7	m_statement 'Open', 200, libio.opn	; #96
	.byte	4,138,17,138,138
??en8	m_statement 'PrintE',200, libio.prte	; #116
	.byte	1,17
??en9	m_statement 'PrintDE',200, libio.prtde	; #75
	.byte	2,138,17
??en10	m_statement 'Close',200, libio.clos	; #253
	.byte	1,138
??en11	m_statement 'Print',200,  libio.prt	; #135
	.byte	1,17
??en12	m_statement 'PrintD',200, libio.prtd	; #115
	.byte	2,138,17
??en13	m_statement 'InputS',200, libio.ins_	; #249
	.byte	1,17
??en14	m_statement 'InputSD',200, libio.insd	; #87
	.byte	2,138,17
??en15	m_statement 'InputMD',200, libio.inmd	; #75
	.byte	3,138,17,138
??en16	m_statement 'GetD',202, libio.getd	; #138
	.byte	1,138
??en17	m_statement 'PutE',200,	libio.pute	; #162
	.byte	0
??en18	m_statement 'Put',200, libio.put	; #158
	.byte	1,137
??en19	m_statement 'PutD',200, libio.putd	; #161
	.byte	2,138,137
??en20	m_statement 'PutDE',200, libio.putde	; #168
	.byte	1,138
??en21	m_statement 'XIO',200, libio.xio	; #225
	.byte	6,138,138,138,138,138,17
??en22	m_statement 'PrintB',200, libio.prtb	; #113
	.byte	1,138
??en23	m_statement 'PrintBE',200, libio.prtbe	; #71
	.byte	1,138
;??en24	m_statement 'PrintBD',200, PrtBD 	; #70
;	.byte	2,138,138
??en25	m_statement 'PrintBDE',200, libio.prtbde; #241
	.byte	2,138,138
??en26	m_statement 'PrintC',200, libio.prtc	; #114
	.byte	1,12
??en27	m_statement 'PrintCE',200, libio.prtce	; #73
	.byte	1,12
??en28	m_statement 'PrintCD',200, libio.prtcd	; #72
	.byte	2,138,12
??en29	m_statement 'PrintCDE',200, libio.prtcde; #245
	.byte	2,138,12
??en30	m_statement 'PrintI',200, libio.prti	; #120
	.byte	1,11
??en31	m_statement 'PrintID',200, libio.prtid	; #84
	.byte	2,138,11
??en32	m_statement 'PrintIE',200, libio.prtie	; #85
	.byte	1,11
??en33	m_statement 'PrintIDE',200, libio.prtide; #13
	.byte	2,138,11
??en34	m_statement 'InputB',202, libio.inb	; #232
	.byte	0
??en35	m_statement 'InputBD',202, libio.inbd	; #53
	.byte	1,138
??en36	m_statement 'InputI',203, libio.ini_	; #239
	.byte	0
??en37	m_statement 'InputID',203, libio.inid	; #67
	.byte	1,138
??en38	m_statement 'InputC',204, libio.inc_	; #233
	.byte	0
??en39	m_statement 'InputCD',204, libio.incd	; #55
	.byte	1,138
??en40	m_statement 'ValB',202, libio.valb	; #207
	.byte	1,17
??en41	m_statement 'ValI',203, libio.vali	; #214
	.byte	1,17
??en42	m_statement 'ValC',204, libio.valc	; #208
	.byte	1,17
??en43	m_statement 'StrB',200, libio.strb	; #223
	.byte	2,138,17
??en44	m_statement 'StrI',200, libio.stri	; #230
	.byte	2,11,17
??en45	m_statement 'StrC',200, libio.strc	; #224
	.byte	2,12,17
??en46	m_statement 'Note',200, libio.note	; #89
	.byte	3,138,20,18
??en47	m_statement 'Point',200, libio.point	; #110
	.byte	3,138,12,138
??en48	m_statement 'Graphics',200, libgr.graphics	; #108
	.byte	1,138
??en49	m_statement 'DrawTo',200, libgr.drawto	; #231
	.byte	2,12,138
??en50	m_statement 'Position',200, libgr.position	; #94
	.byte	2,12,138
??en51	m_statement 'Locate',202, libgr.locate	; #97
	.byte	2,12,138
??en52	m_statement 'Plot',200, libgr.plot	; #131
	.byte	2,12,138
??en53	m_statement 'SetColor',200, libgr.setcolor	; #6
	.byte	3,138,138,138
??en54	m_statement 'Fill',200, libgr.fill	; #122
	.byte	2,12,138
??en55	m_statement 'Rand',202, libmisc.rand	; #117
	.byte	1,138
??en56	m_statement 'Sound',200, libmisc.sound	; #31
	.byte	4,138,138,138,138
??en57	m_statement 'SndRst',200, libmisc.sndrst	; #73
	.byte	0
??en58	m_statement 'Paddle',202, paddle		; #254
	.byte	1,138
??en59	m_statement 'PTrig',202, libmisc.ptrig	; #164
	.byte	1,138
??en60	m_statement 'Stick',202, libmisc.stick	; #8
	.byte	1,138
??en61	m_statement 'STrig',202, strig	; #52
	.byte	1,138
;??en62 m_statement 'Peek',202, Peek ; #73
;	.byte	1,12
;??en63	m_statement 'PeekC',204, PeekC ; #245
;	.byte	1,12
??en64	m_statement 'Poke',200, libmisc.poke	; #120
	.byte	2,12,138
??en65	m_statement 'PokeC',200, libmisc.pokec	; #83
	.byte	2,12,12
??en66	m_statement 'Zero',200, libmisc.mzero	; #88
	.byte	2,18,12
??en67	m_statement 'SetBlock',200, libmisc.setblock	; #203
	.byte	3,18,12,138
;??en68 m_statement 'MoveBlock',200, MoveBlock ; #85
;	.byte	3,18,18,12
??en69	m_statement 'Break',200, libmisc.break	; #183
??en70	m_statement 'SCompare',203, libstr.scompare	; #92
	.byte	2,17,17
??en71	m_statement 'SCopy',200, libstr.scopy	; #192
	.byte	2,17,17
??en72	m_statement 'SCopyS',200, libstr.scopys	; #244
	.byte	4,17,17,138,138
??en73	m_statement 'SAssign',200, libstr.sassign 	; #23
	.byte	4,17,17,138,138
;
; hash table, also uses statement definition from main bank
;
	.use	mainbnk.statement_definitions
libst
	.byte	0		; 1
	.byte	>en1		; EOF #1
	.byte	>en5		; TRACE #2
	.byte	0,0,0		; 3
	.byte	>??en53		; SetColor #6
	.byte	0		; 1
	.byte	>??en60		; Stick #8
	.byte	0,0,0,0 	; 4
	.byte	>??en33		; PrintIDE #13
	.byte	>en2		; color #14
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	>??en73		; SAssign #23
	.byte	0,0,0,0,0,0,0	; 7
	.byte	>??en56		; Sound #31
	.byte	>en3		; LIST #32
	.byte	0,0,0,0,0,0,0,0,0,0
	.byte	0,0,0,0,0,0,0,0,0 ; 19
	.byte	>??en61		; STrig #52
	.byte	>??en35		; InputBD #53
	.byte	0		; 1
	.byte	>??en39		; InputCD #55
	.byte	0,0,0,0,0,0,0,0,0,0
	.byte	0		; 11
	.byte	>??en37		; InputID #67
	.byte	0,0		; 2
	.byte	>??en24		; PrintBD #70
	.byte	>??en23		; PrintBE #71
	.byte	>??en28		; PrintCD #72
	.byte	>??en27		; PrintCE #73
	.byte	>??en57		; SndRst #74
	.byte	>??en9		; PrintDE #75
	.byte	>??en15		; InputMD #76
	.byte	>??en62		; Peek #77
	.byte	0,0,0,0,0	; 5
	.byte	>??en65		; PokeC #83
	.byte	>??en31		; PrintID #84
	.byte	>??en32		; PrintIE #85
	.byte	>??en68		; MoveBlock #86
	.byte	>??en14		; InputSD #87
	.byte	>??en66		; Zero #88
	.byte	>??en46		; Note #89
	.byte	0,0		; 2
	.byte	>en4		; device #92
	.byte	>??en70		; SCompare #93
	.byte	>??en50		; Position #94
	.byte	0		; 1
	.byte	>??en7		; Open #96
	.byte	>??en51		; Locate #97
	.byte	0,0,0,0,0,0,0,0,0,0 ; 10
	.byte	>??en48		; Graphics #108
	.byte	0		; 1
	.byte	>??en47		; Point #110
	.byte	0,0		; 2
	.byte	>??en22		; PrintB #113
	.byte	>??en26		; PrintC #114
	.byte	>??en12		; PrintD #115
	.byte	>??en8		; PrintE #116
	.byte	>??en6		; PrintF #117
	.byte	>??en55		; Rand #118
	.byte	0		; 1
	.byte	>??en30		; PrintI #120
	.byte	>??en64		; Poke #121
	.byte	>??en54		; Fill #122
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	>??en52		; Plot #131
	.byte	0,0,0		; 3
	.byte	>??en11		; Print #135
	.byte	0,0		; 2
	.byte	>??en16		; GetD #138
	.byte	0,0,0,0,0,0,0,0,0,0
	.byte	0,0,0,0,0,0,0,0 ; 18
	.byte	>en0		; Error #157
	.byte	>??en18		; Put #158
	.byte	0,0		; 2
	.byte	>??en19		; PutD #161
	.byte	>??en17		; PutE #162
	.byte	0		; 1
	.byte	>??en59		; PTrig #164
	.byte	0,0,0		; 3
	.byte	>??en20		; PutDE #168
	.byte	0,0,0,0,0,0,0,0,0,0
	.byte	0,0,0,0 	; 14
	.byte	>??en69		; Break #183
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	>??en71		; SCopy #192
	.byte	0,0,0,0,0,0,0,0,0,0 ; 10
	.byte	>??en67		; SetBlock #203
	.byte	0,0,0		; 3
	.byte	>??en40		; ValB #207
	.byte	>??en42		; ValC #208
	.byte	0,0,0,0,0	; 5
	.byte	>??en41		; ValI #214
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	>??en43		; StrB #223
	.byte	>??en45		; StrC #224
	.byte	>??en21		; XIO #225
	.byte	0,0,0,0 	; 4
	.byte	>??en44		; StrI #230
	.byte	>??en49		; DrawTo #231
	.byte	>??en34		; InputB #232
	.byte	>??en38		; InputC #233
	.byte	0,0,0,0,0	; 5
	.byte	>??en36		; InputI #239
	.byte	0		; 1
	.byte	>??en25		; PrintBDE #241
	.byte	0,0		; 2
	.byte	>??en72		; SCopyS #244
	.byte	>??en29		; PrintCDE #245
	.byte	>??en63		; PeekC #246
	.byte	0,0		; 2
	.byte	>??en13		; InputS #249
	.byte	0,0,0		; 3
	.byte	>??en10		; Close #253
	.byte	>??en58		; Paddle #254
	.byte	0		; 1
;
	.byte	0		; 1
	.byte	<en1
	.byte	<en5
	.byte	0,0,0		; 3
	.byte	<??en53
	.byte	0		; 1
	.byte	<??en60
	.byte	0,0,0,0 	; 4
	.byte	<??en33
	.byte	<en2
	.byte	0		; 1
;
; .BYTE 0,0,0,0,0,0,0,0 ; 7
strig	tax
	lda	trig0,x		;TODO FIX! Use shadow register instead
	sta	args
	rts
;
	.byte	<??en73
;
; .BYTE 0,0,0,0,0,0,0 ; 7
paddle	tax
	lda	paddl0,x
	sta	args
	rts
;
	.byte	<??en56
	.byte	<en3
	.byte	0,0		; 2
;
; .BYTE 0,0,0,0,0,0,0,0,0,0
; .BYTE 0,0,0,0,0,0,0,0,0 ; 17
??en6	m_statement 'PrintF',200, libio.prtf	; #117
	.byte	6,17,12,12,12,12,12
;
	.byte	<??en61
	.byte	<??en35
	.byte	0		; 1
	.byte	<??en39
;
; .BYTE 0,0,0,0,0,0,0,0,0,0
; .BYTE 0 ; 11
??en63	m_statement 'PeekC',204, libmisc.peekc	; #245
	.byte	1,12
;
	.byte	<??en37
	.byte	0,0		; 2
	.byte	<??en24
	.byte	<??en23
	.byte	<??en28
	.byte	<??en27
	.byte	<??en57
	.byte	<??en9
	.byte	<??en15
	.byte	<??en62
	.byte	0,0,0,0,0	; 5
	.byte	<??en65
	.byte	<??en31
	.byte	<??en32
	.byte	<??en68
	.byte	<??en14
	.byte	<??en66
	.byte	<??en46
	.byte	0,0		; 2
	.byte	<en4
	.byte	<??en70
	.byte	<??en50
	.byte	0		; 1
	.byte	<??en7
	.byte	<??en51
;
; .BYTE 0,0,0,0,0,0,0,0,0,0 ; 10
; (c)1983ACS in internal char. qcode copyright
	.byte	"(c)1983ACS"
	.byte	<??en48
	.byte	0		; 1
	.byte	<??en47
	.byte	0,0		; 2
	.byte	<??en22
	.byte	<??en26
	.byte	<??en12
	.byte	<??en8
	.byte	<??en6
	.byte	<??en55
	.byte	0		; 1
	.byte	<??en30
	.byte	<??en64
	.byte	<??en54
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	<??en52
	.byte	0,0,0		; 3
	.byte	<??en11
	.byte	0,0		; 2
	.byte	<??en16
	.byte	0		; 1
;
; .BYTE 0,0,0,0,0,0,0,0,0,0
; .BYTE 0,0,0,0,0,0,0,0 ; 17
??en68	m_statement 'MoveBlock',200, libmisc.moveblock	; #85
	.byte	3,18,18,12
;
	.byte	<en0
	.byte	<??en18
	.byte	0,0		; 2
	.byte	<??en19
	.byte	<??en17
	.byte	0		; 1
	.byte	<??en59
	.byte	0,0,0		; 3
	.byte	<??en20
;
; .BYTE 0,0,0,0,0,0,0,0,0,0
; .BYTE 0,0,0,0 ; 14
??en24	m_statement 'PrintBD',200, libio.prtbd	; #70
	.byte	2,138,138
;
	.byte	<??en69
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	<??en71
;
; .BYTE 0,0,0,0,0,0,0,0,0,0 ; 10
??en62	m_statement 'Peek',202, libmisc.peek	; #73
	.byte	1,12
;
	.byte	<??en67
	.byte	0,0,0		; 3
	.byte	<??en40
	.byte	<??en42
	.byte	0,0,0,0,0	; 5
	.byte	<??en41
	.byte	0,0,0,0,0,0,0,0 ; 8
	.byte	<??en43
	.byte	<??en45
	.byte	<??en21
	.byte	0,0,0,0 	; 4
	.byte	<??en44
	.byte	<??en49
	.byte	<??en34
	.byte	<??en38
	.byte	0,0,0,0,0	; 5
	.byte	<??en36
	.byte	0		; 1
	.byte	<??en25
	.byte	0,0		; 2
	.byte	<??en72
	.byte	<??en29
	.byte	<??en63
	.byte	0,0		; 2
	.byte	<??en13
	.byte	0,0,0		; 3
	.byte	<??en10
	.byte	<??en58
; .BYTE 0 ; 1
	.endl			; end of statement_definitions
