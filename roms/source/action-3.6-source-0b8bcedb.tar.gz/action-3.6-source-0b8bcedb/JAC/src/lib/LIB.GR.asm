;
;	LIB.GR
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified June 21, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libgr

; .proc Graphics(BYTE mode)
; same as BASIC
graphics	.proc		; Graphics(mode)
	pha
	lda	#cio_channel.zero
	jsr	libio.clos
	lda	#cio_command.close
	sta	arg3
	lda	#cio_channel.zero
	ldx	#<??e
	ldy	#>??e
	jsr	mainio.open
	jsr	libio.chkerr
	lda	#cio_channel.six
	jsr	libio.clos
	pla
	sta	arg4
	and	#$30
	eor	#$1c
	sta	arg3
	lda	#cio_channel.six
	ldx	#<??devs
	ldy	#>??devs
	jsr	mainio.open
	jmp	libio.chkerr
	.endp

??e	m_string 'E:'
	.byte character.eol
??devs	m_string 'S:'
	.byte character.eol

;
; .proc DrawTo(CARD col, BYTE row)
; same as BASIC
drawto	.proc
	jsr	??grio		; DrawTo(col, row)
	ldy	#cio_command.drawto
	jmp	libio.xio
;
??grio	jsr	position.pos1
	lda	fildat
	sta	atachr
	lda	#<??devs
	sta	arg5
	lda	#>??devs
	sta	arg6
	lda	#0
	sta	arg3
	sta	arg4
	lda	#6
	rts
	.endp
;
; .proc Position(CARD col, BYTE row)
; same as BASIC
position	.proc
	sta	oldcol	; Position(col, row)
	stx	oldcol+1
	sty	oldrow
pos1	sta	colcrs
	stx	colcrs+1
	sty	rowcrs
	rts
	.endp
;
; BYTE FUNC Locate(CARD col, BYTE row)
; same as BASIC
locate	.proc
	jsr	position	; Locate(col, row)
	lda	#cio_channel.six
	jmp	libio.getd
	.endp
;
; .proc Plot(CARD col, BYTE row)
; same as BASIC
plot	.proc
	jsr	position.pos1	; Plot(col, row)
	lda	#cio_channel.six
	ldx	fildat
	jmp	libio.putd
	.endp
;
; .proc SetColor(BYTE reg, hue, lum)
; same as BASIC
setcolor	.proc
	cmp	#5	; SetColor(reg, hue, lum)
	bpl	??sc1
	sta	arg0
	tya
	and	#$0f
	sta	arg2
	txa
	asl
	asl
	asl
	asl
	ora	arg2
	ldx	arg0
	sta	color0,x
	sta	colpf0,x
??sc1	rts
	.endp
;
; .proc Fill(CARD col, BYTE row)
; same as:
;   POSITION col, row
;   POKE 765, color
;   XIO 18,#6,0,0,'S:'
; in BASIC
fill	.proc
	jsr	drawto.??grio
	ldy	#cio_command.fill
	jmp	libio.xio
	.endp

	.endp			; end of libgr