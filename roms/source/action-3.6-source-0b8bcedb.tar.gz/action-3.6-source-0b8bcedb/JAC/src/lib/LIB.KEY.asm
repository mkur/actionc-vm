;
;	LIB.KEY
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified September 28, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libkey

lgetkey .proc			; Get next key in buffer
	clc			; Blink cursor
	lda	rtclok+2
	adc	#14
	tax
bc1	lda	ch		; Key down?
	eor	#$ff
	bne	gk0
	cpx	rtclok+2
	bpl	bc1
	ldy	#0
	lda	(oldadr),y
	eor	#$80
	sta	(oldadr),y
	jmp	lgetkey
;
gk0	ldy	#0
	lda	oldchr
	eor	#$80
	sta	(oldadr),y	; Restore cursor
	ldx	srtimr		; Faster repeat
	cpx	#$0c
	bcs	gk5
	cpx	#4
	bcc	gk2
	ldx	#3
gk1	stx	srtimr
gk2	lda	ch
	cmp	#$c0
	bcc	gk3		; Not Ctrl-Shft
;cskey
	jsr	click
	bmi	gk4		; Unconditional branch

gk3	and	#$3f
	cmp	#$3c		; Caps key
	beq	caps
	cmp	#$27		; Atari key
	beq	atari
;gkey
	ldx	#$70
	lda	#7		; GETCHR
	sta	brkkey		; Ignore BREAK key
	jsr	screen.putch.putch2
gk4	ldx	srtimr
	cpx	#10
	bcs	gkret
	ldx	#3
	stx	srtimr
gkret	sta	vars.curch
	rts
gk5	ldx	#20
	bne	gk1
caps	lda	ch
	and	#$c0
	sta	shflok
caps1	jsr	click
	bmi	lgetkey
atari	lda	invflg
	eor	#$80
	sta	invflg
	jmp	caps1
	.endp

click	.proc			; Click() click the keyboard
	ldx	#$7f
loop	stx	consol
	stx	wsync
	dex
	bpl	loop
	stx	ch		; Set $ff to indicate no key is pressed
	rts
	.endp

	.endp			; End of libkey