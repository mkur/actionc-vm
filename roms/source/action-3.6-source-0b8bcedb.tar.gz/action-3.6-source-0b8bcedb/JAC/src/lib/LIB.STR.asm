;
;	LIB.STR
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified November 3, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libstr
;
;INT FUNC SCompare(STRING a,b)
; result returned is:
;   =0 if a=b
;   low 0 if a<b
;   high 0 if a>b
scompare	.proc
	sta	arg4
	stx	arg5
	sty	arg2
	ldy	#0
	sty	args
	sty	args+1
	lda	(arg4),y
	cmp	(arg2),y
	beq	??sc1
	jsr	??sc4
??sc1	cmp	#0
	bne	??sc2
	rts
;
??sc2	sta	arg6
??sc3	iny
	lda	(arg4),y
	cmp	(arg2),y
	bne	??sc4
	cpy	arg6
	bcc	??sc3
	rts
;
??sc4	ldx	#$ff
	stx	args
	bcc	??sc5
	lda	(arg2),y
	inx
??sc5	stx	args+1
	rts
	.endp
;
; PROC SCopy(STRING dest, src)
; dest = src
scopy	.proc
	sta	arg0
	stx	arg1
	sty	arg2
	ldy	#0
	lda	(arg2),y
scopy1	sta	(arg0),y
	beq	??scp2
scopy2	tay
??scp1	lda	(arg2),y
	sta	(arg0),y
	dey
	bne	??scp1
??scp2	rts
	.endp
;
; PROC SCopyS(STRING dest, src, BYTE start, stop)
; if LEN(src)<stop then stop=LEN(src)
; dest = src(start, stop)
scopys	.proc
	sta	arg0
	stx	arg1
	sty	arg2
	ldy	#0
	lda	(arg2),y
	cmp	arg5
	bcs	??scs1
	sta	arg5
??scs1	dec	arg4
	clc
	lda	arg2
	adc	arg4
	sta	arg2
	bcc	??scs2
	inc	arg3
??scs2	sec
	lda	arg5
	sbc	arg4
	bcs	??scs3
	lda	#0
??scs3	jmp	scopy.scopy1
	.endp
;
; PROC SAssign(STRING dest, src, BYTE start, stop)
; IF stop-start+1>LEN(src) THEN
;   stop = LEN(src)+start-1
; IF LEN(dest)<stop THEN
;   LEN(dest) = stop
; dest(start, stop) = src
sassign .proc
	sta	arg0
	stx	arg1
	sty	arg2
	ldy	#0
	lda	(arg2),y
	beq	??sa1
	sta	arg6
	dec	arg4
	sec
	lda	arg5
	sbc	arg4
	beq	??sa1
	bcs	??sa2
??sa1	rts
??sa2	tax
	cmp	arg6
	bcc	??sa3
	clc
	lda	arg6
	tax
	adc	arg4
	sta	arg5
??sa3	lda	arg5
	cmp	(arg0),y
	bcc	??sa4
	sta	(arg0),y
	clc
??sa4	lda	arg0
	adc	arg4
	sta	arg0
	bcc	??sa5
	inc	arg1
??sa5	txa
	jmp	scopy.scopy2
	.endp

	.endp	; end of libstr