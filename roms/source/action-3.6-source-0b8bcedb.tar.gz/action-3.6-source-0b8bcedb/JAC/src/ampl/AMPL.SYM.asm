;
;	AMPL.SYM
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified June 29, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

stm	.proc			; STM(table)
	sta	arg2
	stx	arg3
	sta	arg4
	inx
	stx	arg5
	ldy	arg15
	sty	arg13
??stm1	lda	(arg2),y
	sta	nxtaddr+1
	beq	??stm3
	lda	(arg4),y
	sta	nxtaddr
	ldy	#0
??stm2	lda	(nxtaddr),y
	eor	(symtab),y
	and	stmask
	bne	??stm4
	cpy	arg14
	iny
	bcc	??stm2
	lda	(nxtaddr),y	; matched
??stm3	rts
??stm4	inc	arg13		; try next entry
	ldy	arg13
	cpy	arg15
	bne	??stm1
	ldy	#errors.gster
	lda	arg3
	cmp	stglobal+1
	beq	??stm5
	iny			; short form for errors.lster
??stm5	jmp	mainbnk.splerr
	.endp

stmres	jmp	(stmradr)	; this normally goes to ISTMres below

istmres .proc			; STMres() lookup reserved names
	ldy	arg14
	cpy	#8
	lda	#$ff		; if name too long!
	bcs	stmr3		; not reserved name
	iny
	sty	arg0
	ldx	reserved_words.rwstrt-2,y
??stmr1 stx	arg1
	ldy	#1
??stmr2 lda	reserved_words.resw1,x
	bmi	stmr3
	eor	(symtab),y
	and	stmask
	bne	??stmr4
	inx
	iny
	cpy	arg0
	bcc	??stmr2
; we have a match
	lda	reserved_words.resw1,x 	; get token value
stmr3	rts
;
??stmr4 clc
	lda	arg1
	adc	arg0
	tax
	bne	??stmr1 	; try next entry
	.endp

lgetname	.proc		; GetName(char)
	ldy	#0
	sta	vars.frstchar
	tax
	ora	#$20
	sta	arg15		; initial hash
	txa
??gname1 iny
	sty	arg14
	sta	(symtab),y
	ora	#$20
	asl	arg15
	adc	arg15
	sta	arg15
	jsr	lexicon.nextchar
	ldy	arg14
	cmp	#'_'
	beq	??gname1
	jsr	mainmsc.alphanum
	bne	??gname1
	tya
	ldy	#0
	sta	(symtab),y
	dec	choff		; put character back
	jsr	stmres		; check for res. name
	bpl	istmres.stmr3	; return
	lda	qglobal
	beq	gnglobal
	lda	stlocal
	ldx	stlocal+1
	jsr	stm
	bne	istmres.stmr3	; return
;
gnglobal
	lda	stglobal
	ldx	stglobal+1
	ldy	vars.frstchar
	cpy	vars.bigst
	bpl	??gng1
	lda	stg2
	ldx	stg2+1
??gng1	jsr	stm
	bne	istmres.stmr3	; return
	lda	qglobal
	beq	newentry
;
lgnlocal
	lda	stlocal
	ldx	stlocal+1
	jsr	stm
	bne	istmres.stmr3	;return

	.if	.def ramzap
	.if	ramzap
	inc	stm,x
	.else
	nop
	nop
	nop
	.endif
	.endif

	.endp

;
newentry	.proc		; Make new entry in symbol table
	lda	symtab+1
	sta	(arg2),y
	lda	symtab
	sta	(arg4),y
	lda	#<lib.statement_definitions.libst
	ldx	#>lib.statement_definitions.libst
	jsr	stm		; lookup shadow name
	lda	#undec
	ldy	arg14
	iny
	sta	(symtab),y
	lda	nxtaddr
	iny
	sta	(symtab),y	; save shadow entry
	lda	nxtaddr+1
	iny
	sta	(symtab),y
	lda	symtab
	sta	nxtaddr
	ldx	symtab+1
	stx	nxtaddr+1
	iny
	tya
	jsr	mainmsc.stincr
	lda	#undec
	rts
	.endp

	.local reserved_words
rwstrt	.byte	0
	.byte	resw2-resw1
	.byte	resw3-resw1
	.byte	resw4-resw1
	.byte	resw5-resw1
	.byte	resw6-resw1
	.byte	resw7-resw1
;
resw1	.byte	$ff
;
resw2	.byte	'DO',tokens.doid
	.byte	'FI',tokens.fi
;	.byte 'FO',esac
	.byte	'IF',tokens.ifid
	.byte	'OD',tokens.odid
;	.byte 'OF',of
	.byte	'OR',tokens.orid
	.byte	'TO',tokens.toid
	.byte	$ff
;
resw3	.byte	'AND',tokens.andid
	.byte	'FOR',tokens.forid
;	.byte 'GET',get
	.byte	'INT',tokens.intid
	.byte	'LSH',tokens.lshid
	.byte	'MOD',tokens.remid
; 	.byte 'NOT',notId
	.byte	'RSH',tokens.rshid
	.byte	'SET',tokens.setid
	.byte	'XOR',tokens.xorid
	.byte	$ff
;
resw4	.byte	'BYTE',tokens.byteid
	.byte	'CARD',tokens.cardid
; 	.byte 'CASE',caseId
	.byte	'CHAR',tokens.charid
	.byte	'ELSE',tokens.elseid
; 	.byte 'ESAC',esac
	.byte	'EXIT',tokens.exitid
	.byte	'FUNC',tokens.funcid
	.byte	'PROC',tokens.procid
; 	.byte 'REAL',real
	.byte	'STEP',tokens.stepid
	.byte	'THEN',tokens.thenid
	.byte	'TYPE',tokens.typeid
	.byte	$ff
;
resw5	.byte	'ARRAY',tokens.arrayid
	.byte	'UNTIL',tokens.untilid
	.byte	'WHILE',tokens.whileid
	.byte	$ff
;
resw6	.byte	'DEFINE',tokens.defineid
;	.byte 'DOWNTO',downto
	.byte	'ELSEIF',tokens.elseif
	.byte	'MODULE',tokens.modid
	.byte	'RETURN',tokens.retid
	.byte	$ff
;
resw7	.byte	'INCLUDE',tokens.getid
	.byte	'POINTER',tokens.pointerid
	.byte	$ff

	.endl
