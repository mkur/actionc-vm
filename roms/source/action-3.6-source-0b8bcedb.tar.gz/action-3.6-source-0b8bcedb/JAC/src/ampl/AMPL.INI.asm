;
;	AMPL.INI
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified May 4, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm


splsetup	.proc		; SPLsetup()
	lda	#0
	tay	
	sta	sp
	sta	chan
	sta	symtab
	sta	initad+1
	sta	(buf),y
	sta	vars.param
	sta	qglobal
	sta	stackptr
	sta	arrayptr+1
	sta	whaddr+1
	sta	curnxt+1
	sta	vars.procsp

; clear qglobal s.t.
	ldx	vars.bigst	; big s.t. ?
	beq	??spls0		; no
??s0	sta	(stg2),y
	iny	
	bne	??s0
??spls0	sta	(stglobal),y
	iny	
	bne	??spls0

; get last block in heap
	lda	afbase
	ldx	afbase+1
	sta	arg0
	stx	arg1
??spls1	ldy	#1
	lda	(arg0),y
	beq	??spls2
	tax	
	dey	
	lda	(arg0),y
	sta	arg0
	stx	arg1
	jmp	??spls1

??spls2	clc	
	lda	arg0
	adc	#4
	bcc	??spls3
	inc	arg1

??spls3	sta	vars.codebase
	sta	qcode

	lda	arg1
	sta	vars.codebase+1
	sta	qcode+1

	lda	memtop+1
	sta	stmax
	dec	stmax
	clc	
	sbc	vars.stsp
	sta	stbase
	sta	symtab+1
	inc	symtab+1

	cmp	qcode+1
	bcs	??spls4

; can't allocate memory
	lda	vars.sparem
	sta	symtab
	lda	vars.sparem+1
	sta	symtab+1
	ldy	#compiler.errors.alcer
	jmp	mainbnk.splerr

??spls4	lda	vars.sparem
	sta	frame
	ldx	vars.sparem+1
	inx	
	inx	
	stx	frame+1

	lda	#<stkbase
	sta	stack
	lda	#>stkbase
	sta	stack+1
	sta	vars.cury	; unknown initial Y value

	rts
	.endp
