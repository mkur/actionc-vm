;
;	AMPL.MTH
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified September 9, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

	.proc libmath

??a	equ	aflast+1
??b	equ	aflast
??c	equ	afcur+1
??d	equ	afcur
??rl	equ	afsize
??rh	equ	afsize+1
??t1	equ	addr
??t2	equ	addr+1
??sign	equ	token
;
;	    MultI(op1, op2)
; op2 is in c & d
;  r = ab * cd
;  r = (a*d + c*b)*2^8 + b*d
multi	.proc
	jsr	smops
	ldx	??b
	beq	??mc5
	stx	??t1
	ldx	??d
	beq	??mc5
	dex
	stx	??t2
	ldx	#8
??mc3	asl		; b*d, 16 bit result
	rol	??rh
	asl	??t1
	bcc	??mc4
	adc	??t2
	bcc	??mc4
	inc	??rh
??mc4	dex
	bne	??mc3
??mc5	sta	??rl
	lda	??b
	ldx	??c
	jsr	mulb		; b*c, 8 bit result
	lda	??a
	ldx	??d
	jsr	mulb		; a*d, 8 bit result
;
??setsign
	ldy	??sign
	bpl	??ss2

	.if	.def ramzap
	.if	ramzap
	sta	mulb,x
	.else
	nop
	nop
	nop
	.endif
	.endif

??ss1	sta	??rl
	stx	??rh
	sec
	lda	#0
	sbc	??rl
	tay
	lda	#0
	sbc	??rh
	tax
	tya
??ss2	rts
	.endp
;
;
mulb	.proc
	beq	??mb3
	dex
	stx	??t2
	tax
	beq	??mb3
	stx	??t1
	lda	#0
	ldx	#8
??mb1	asl
	asl	??t1
	bcc	??mb2
	adc	??t2
??mb2	dex
	bne	??mb1
	clc
	adc	??rh
	sta	??rh
??mb3	lda	??rl
	ldx	??rh
	rts
	.endp
;
smops	.proc
	stx	??sign
	cpx	#0		; check signs
	bpl	??smo1
	jsr	multi.??ss1
??smo1	sta	??b
	stx	??a
	lda	??c
	bpl	??smo2
	tax
	eor	??sign
	sta	??sign
	lda	??d
	jsr	multi.??ss1
	sta	??d
	stx	??c
??smo2	lda	#0
	sta	??rh
	rts
	.endp
;
divi	.proc
	jsr	smops		; DivC(op1, op2)
; see MultC above
	lda	??c
	beq	??dsmall
;
;??dlarge
	ldx	#8
??dl1	rol	??b
	rol	??a
	rol	??rh
	sec
	lda	??a
	sbc	??d
	tay
	lda	??rh
	sbc	??c
	bcc	??dl2		; overflow, don't subtract
	sta	??rh
	sty	??a
??dl2	dex
	bne	??dl1
	lda	??b
	rol
	ldx	#0
	ldy	??a
	sty	??rl		; save low byte of REM
	jmp	multi.??setsign
;
??dsmall	ldx	#16
??ds1	rol	??b
	rol	??a
	rol
	bcs	??ds1a		; keep track of shift output
	cmp	??d
	bcc	??ds2		; overflow, don't subtract
??ds1a	sbc	??d
	sec			; for carry out in ROL A above
??ds2	dex
	bne	??ds1
	rol	??b
	rol	??a
	sta	??rl
	lda	??b
	ldx	??a
	jmp	multi.??setsign
	.endp
;
remi	.proc
	jsr	divi
	lda	??rl
	ldx	??rh
	rts
	.endp
;
rshift	.proc
	ldy	??d		; RShift(val, cnt)
	beq	??rshret
	stx	??c
??rsh1	lsr	??c
	ror
	dey
	bne	??rsh1
	ldx	??c
??rshret	rts
	.endp
;
;	saves args for call
sargs	.proc
	sta	arg0
	stx	arg1
	sty	arg2
	clc
	pla
	sta	afcur
	adc	#3		; jump over data
	tay
	pla
	sta	afcur+1
	adc	#0
	pha
	tya
	pha
	ldy	#1
	lda	(afcur),y	; local address
	sta	aflast
	iny
	lda	(afcur),y
	sta	aflast+1
	iny
	lda	(afcur),y	; # of bytes
	tay
??sa1	lda	args,y
	sta	(aflast),y
	dey
	bpl	??sa1
; check for break key
	lda	brkkey
	bne	??sa2
	inc	brkkey
	jmp	lib.libmisc.break
??sa2	rts
	.endp
;
; IToReal(int) -> FR0
;IToReal STX ??sign
; JSR ??SetSign
; STA FR0
; STX FR0+1
; JSR IFP
;:FSign LDA ??sign
; BPL ??Rem1
; JSR FMOVE
; JSR ZFR0
; JMP FSUB
; RToInt() real in FR0
;RToInt LDA FR0
; STA ??sign
; JSR ??FSign
; JSR FPI
; LDA FR0
; LDA FR0+1
; JMP ??SetSign

	.endp	; end of libmath