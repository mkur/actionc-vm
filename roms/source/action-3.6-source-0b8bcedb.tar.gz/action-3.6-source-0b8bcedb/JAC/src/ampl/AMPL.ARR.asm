;
;         AMPL.ARR
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved
;
; Original last modified June 7, 1983
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

; This file is actually part of the compiler but it is located in the main bank.

arrref	.proc			; ArrRef()

	.use cgu		; uses code generation unit
	
	ldx	nxttoken
	cpx	#tokens.lparen
	beq	??arr0
	cpx	#tokens.uparrow
	beq	??arr0
arrvar	ldy	#tokens.vart+types.cardt	; no index!
	sty	token
	cmp	#tokens.arrayt+8
	bcc	??arr1
arrconst
	jsr	ccompile.procref.stconst
??arr1	jmp	ccompile.pushst

??arptr	ldy	#0
	lda	(stack),y
	cmp	#tokens.arrayt+8
	bcs	??arpt1		; small array
	iny	
	jsr	stkp
	cpx	#0
	bne	??arpt1
; page zero pointer
	ldy	#1
	sta	(stack),y
	dey	
	lda	(stack),y
	ora	#$b0		; temp array mode
	sta	(stack),y
	rts	

??arpt1	jsr	ccompile.zerost
	bne	??ar0		; unconditional branch

??arr0	jsr	ccompile.pushnext
	cmp	#tokens.uparrow
	beq	??arptr
	jsr	ccompile.getexp
	cmp	#tokens.rparen
	bne	arrerr
	ldx	op
	bne	arrerr
??ar0	ldy	#7
	lda	(stack),y
arra0	pha	
	lda	#tokens.vart+types.cardt
	sta	(stack),y
	lda	#tokens.plusid
	jsr	ccompile.genops
	pla	
	cmp	#tokens.arrayt+8
	bcs	??arsmall
	and	#7
	tax	
	ora	#$b0		; temp array mode
	sta	arg7
	ldy	arg1
	cpy	#tokens.constt+types.strt
	ldy	#1		; clear Z flag if we branch
	bcs	??ar1
	lda	(stack),y
	iny	
	ora	(stack),y
??ar1	sta	fr1
	beq	??arint		; pointer
	ldy	ccompile.vartype-1,x
	beq	??arbyte
; CPY #3
; BEQ ??ARReal
; integer or cardinal
??arint	jsr	gettemps
	lda	#opcode.lda_izx	; LDA (zp,x)
	ldx	fr1
	beq	??ari1
	jsr	load2l
	lda	#opcode.asl_a	; ASL A
	ldx	#opcode.php_	; PHP
	ldy	#opcode.clc_	; CLC
	jsr	push3
	lda	#opcode.adc_izx	; ADC (zp,x)

	.if	.def ramzap
	.if	ramzap
	sta	(arg8),y
	.else	
	nop	
	nop	
	.endif
	.endif

??ari1	jsr	op1l
	jsr	stempl
	lda	#opcode.lda_izx	; LDA (zp,x)
	ldx	fr1
	beq	??ari2
	jsr	load2h
	lda	#$2a		; ROL A
	ldx	#$28		; PLP, restore carry
	jsr	push2
	lda	#opcode.adc_izx ; ADC (zp,X)
??ari2	jsr	op1h
	jmp	ccompile.cgadd.cgadd2

arrerr	ldy	#errors.arrer	; bad array ref
	jmp	mainbnk.splerr

??arbyte
	jmp	ccompile.codegen.cg1

??arsmall	ldy	#7
	sta	(stack),y	; restore correct type
	lda	arg1
	bpl	arrerr		; can't index with bool.
	bit	arrmode
	bne	arrerr		; can't index with array
	ldy	#10
	sta	(stack),y
	ldy	#2
	jsr	loadi
	ldy	#11
	jsr	savecd.savstk
	jmp	ccompile.popst
	.endp
