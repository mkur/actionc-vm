;
;	AMPL.INI
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified July 29, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm


; Monitor for ACTION!



monitor	.proc

	jsr	window.savworld
	lda	vars.delbuf	; delete buffer bottom
	ldx	vars.delbuf+1
	jsr	chr.delfree	; get rid of delete buf
	lda	top+1
	sta	vars.top1
mon1	jsr	screen.scrinit
	ldx	#1
	stx	rowcrs
	stx	vars.mpc
	dex	
	stx	vars.cmdln
	stx	device
	jsr	splsetup

; LIST I

	.proc mloop		; main loop
	jsr	editio.initkeys

; LIST *

	lda	dindex		; display mode
	beq	??mon2
	jsr	screen.scrinit	; get Graphics(0)
??mon2	jsr	alarm
	jsr	mainio.rstcsr
	lda	#<mprompt
	ldx	#>mprompt
	jsr	window.gettemp
	ldy	tempbuf
	beq	mloop

	lda	#0
	sta	top+1
	sta	chan
	lda	#<tempbuf
	ldx	#>tempbuf
	ldy	sp
	iny			; make sure non-zero
	jsr	compiler.lexicon.lexexpand.lexp1
	jsr	getnext

	lda	tempbuf+1
	ora	#$20
	ldx	#<mcmd
	ldy	#>mcmd
	jsr	mainmsc.lookup
	jmp	mloop
	.endp			; end of mloop

mquit	.proc
	ldy	#0
	sty	vars.mpc
	sty	subbuf
	sty	findbuf
	sty	dirtyf
	m_assert_next rstwnd	; falls into rstwnd
	.endp

rstwnd	.proc	
	lda	#23
	sta	vars.cmdln
	lda	vars.numwd
	beq	??rw1
	lda	wsize
	sta	vars.cmdln
	lda	#vars.w2-vars.w1
	jsr	paintw
	lda	#0
??rw1	jsr	paintw
	jsr	fcmsg1
	jmp	editmain.floop
	.endp


paintw	.proc			; PaintW(window)
	sta	vars.curwdw
	jsr	dsp.rstwd
	jmp	find.found
	.endp

mdump	.proc	
	jsr	mprint
??md1	inc	arg11
	bne	??md2
	inc	arg12
??md2	lda	arg11
	ldx	arg12
	jsr	mprint.mp1
	jsr	editio.gotkey
	beq	??md1
	ldx	#$ff
	stx	ch
	cmp	#$de	; TODO Key code
	bne	??md1
	rts	
	.endp

mprint	.proc
	jsr	mpsave
mp1	jsr	mainio.printc
	ldy	#character.comma
	jsr	mainio.putchar
	lda	arg11
	ldx	arg12
	jsr	printh
	jsr	mainio.putsp
	ldy	#'='
	jsr	mainio.putchar
	jsr	mainio.putsp
	jsr	mpload
	tay	
	jsr	mainio.putchar
	jsr	mainio.putsp
	jsr	mpload
	jsr	printh
	jsr	mainio.putsp
	jsr	mpload
	ldx	#0
	jsr	mainio.printc
	jsr	mainio.putsp
	jsr	mpload
	jsr	mainio.printc
	jmp	mainio.puteol
	.endp

mpload	.proc
	ldy	#1
	lda	(arg11),y
	tax	
	dey	
	lda	(arg11),y
	rts	
	.endp

mpsave	.proc
	jsr	mainmsc.mnum
	sta	arg11
	stx	arg12
	rts	
	.endp

boot	.proc	
	lda	#<??bmsg
	ldx	#>??bmsg
	jsr	window.yesno
	bne	mrun.mwrt1	; Return
	jmp	cold

??bmsg	m_string 'Boot? '
	.endp

mrun	.proc
	lda	nxttoken
	cmp	#compiler.tokens.eofid
	beq	??mr1

	cmp	#compiler.tokens.quote	; compile and go?
	bne	??mr2		; no
	jsr	comp

??mr1	lda	initad
	ldx	initad+1
	bne	??mr3
mwrt1	rts

??mr2	jsr	mainmsc.mnum
??mr3	jsr	mainbnk.run_
	lda	#0
	sta	device
	rts	
	.endp

mwrite	.proc			; write object file
	lda	nxttoken
	cmp	#compiler.tokens.quote
	bne	mrun.mwrt1	; no output file!
	lda	initad+1
	beq	mrun.mwrt1	; no program!!
	lda	#1
	sta	chan
	lda	#8		; output
	jsr	mainio.openchan

; write header
	lda	#6
	sta	arg9
	lda	#$ff
	sta	arg10		; $FF
	sta	arg11		; $FF
	clc	
	lda	vars.codebase	; starting address
	adc	codeoff
	sta	arg12
	lda	vars.codebase+1
	adc	codeoff+1
	sta	arg13
	tax	

	clc			; ending address
	lda	arg12
	adc	vars.codesize
	sta	arg14
	bne	??mw2
	dex	
??mw2	dec	arg14
	txa	
	adc	vars.codesize+1
	sta	arg15
	jsr	mwout

; write the qcode
	ldx	#cio_channel.one*cio_channel.factor
	lda	#cio_command.putchr ; output command
	sta	iccom,x
	lda	vars.codebase
	sta	icbadr,x	; address
	lda	vars.codebase+1
	sta	icbadr+1,x
	lda	vars.codesize
	sta	icblen,x	; size
	lda	vars.codesize+1
	sta	icblen+1,x
	jsr	ciov		; CIOV
	bmi	mxerr.mwerr

; save start address
	ldx	#.len mwinit-1
??mw3	lda	mwinit,x
	sta	arg9,x
	dex	
	bpl	??mw3
	lda	initad
	sta	arg14
	lda	initad+1
	sta	arg15
	jsr	mwout

; close file
	lda	#cio_channel.one
	jmp	mainio.close

	.local mwinit
	.byte	6
	.if fix_save_initad = 1	;Use RUNAD instead of INITAD when saving the executable
		.word	runad
		.word	runad+1
	.else
		.word	initad
		.word	initad+1
	.endif
	.endl

	.endp

mwout	.proc
	lda	#1
	ldx	#arg9
	ldy	#0
	jsr	mainio.output
	bmi	mxerr.mwerr
	rts	
	.endp

mxerr	.proc
	ldy	#compiler.errors.ender
mwerr	jmp	mainbnk.splerr
	.endp

mx	.proc			; execute command line
	lda	#0
	sta	codeoff
	sta	codeoff+1
	lda	qcode
	pha	
	lda	qcode+1
	pha	
	jsr	getnext
	jsr	mainbnk.cstmtlst
	cmp	#compiler.tokens.eofid
	bne	mxerr
	lda	#opcode.rts_	; RTS
	ldy	#0
	sta	(qcode),y
	pla	
	tax	
	pla	
	jmp	mainbnk.run_
	.endp

comp	.proc			; Comp()
	jsr	splsetup
	jsr	mainio.dspoff
	jsr	mainbnk.compile
	jmp	mainio.dspon
	.endp

; see MAIN.BNK now
;Dret .proc ; Dret() go to DOS
; LDA DOSVEC
; LDX DOSVEC+1
; JMP JSRInd


proceed	.proc			; Proceed()
	ldx	vars.procsp
	beq	??p1
; LDA #< ??pmsg
; LDX #> ??pmsg
; JSR YesNo
; BNE ??p1
; LDX procSP ; break stack pointer

	lda	#0
	sta	vars.procsp
	txs	
	jmp	mainbnk.lproceed

??p1	rts	

;:Pmsg DEFMSG "Proceed? "
	.endp

printh	.proc			; PrintH(num)
	sta	arg0
	stx	arg1
	lda	#4
	sta	arg2
	ldy	#'$'
	jsr	mainio.putchar
??ph1	lda	#0
	ldx	#4
??ph2	asl	arg0
	rol	arg1
	rol
	dex	
	bne	??ph2
; CLC
	adc	#'0'
	cmp	#':'
	bmi	??ph3
	adc	#6
??ph3	tay	
	jsr	mainio.putchar
	dec	arg2
	bne	??ph1
	rts	
	.endp

mcmd	.local
	.word	disptb+9	; unknown cmd
	.byte	35		; table size
	.word	boot
	.byte	'b'
	.word	comp
	.byte	'c'
	.word	mainbnk.dret
	.byte	'd'
	.word	mquit
	.byte	'e'
; .WORD Format
; .BYTE 'f
	.word	mainbnk.options
	.byte	'o'
	.word	proceed
	.byte	'p'
	.word	mrun
	.byte	'r'
	.word	mwrite
	.byte	'w'
	.word	mx
	.byte	'x'
	.word	mprint
	.byte	'?'
	.word	mdump
	.byte	'*'
	.endl

mprompt	m_string '>'

	.endp		; end of monitor