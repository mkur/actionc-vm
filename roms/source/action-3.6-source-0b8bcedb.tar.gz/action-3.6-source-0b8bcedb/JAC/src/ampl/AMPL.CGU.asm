;
;         AMPL.CGU
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved
;
; Original last modified October 15, 1983
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

; This file is actually part of the compiler but it is located in the main bank.

	.proc cgu		; Code generation unit

	.use compiler
	.use mainmsc

loady	.proc			; LoadY() value in arg12
	lda	vars.cury
	cmp	arg12
	beq	??lyret
	jsr	push0
	cmp	#1
	bne	??ly2
	lda	#$88		; DEY
??ly1	jsr	insrt1
	jmp	??ly4

??ly2	cmp	#0
	bne	??ly3
	lda	#$c8		; INY
	bne	??ly1

??ly3	lda	#$a0
	ldx	arg12
	jsr	insrt2		; LDY #0 or #1

??ly4	lda	arg12
	sta	vars.cury
	ldy	arg13

??lyret	rts	
	.endp

trashy	.proc			; TrashY()
	lda	#$ff
	sta	vars.cury
	rts	
	.endp

loadx	.proc			; LoadX(,,offset)
; NOTE:  this .proc can only be called
; from Op below, see ??LXC
	lda	(stack),y
	iny	
	bit	tempmode
	bne	??lxt
	bit	cnstmode
	beq	??lxc
; var to load
	jsr	stkprop
	beq	??lxz
	lda	#$ae		; LDX addr16
	jmp	push3

??lxt	lda	(stack),y
	tax	
	dec	temps-args,x
??lxz	lda	#$a6		; LDX addr
	jmp	push2

??lxc	lda	(stack),y
; TAX
; LDA #$A2 ; LDX data
; BNE ??LX1
	sta	arg12
	pla	
	pla	
	pla	
	tay	
	bne	op1l.??opv	; unconditional branch
	.endp

optype	.proc
	and	#$20
	beq	op1l.??operr	; con. exp.
	jsr	stkaddr
	lda	arg12
	beq	op1l.??opv1
	inx	
	bne	op1l.??opv1
	iny	
	jmp	op1l.??opv1
	.endp

load1l	.proc			; Load1L()
	lda	#opcode.lda_izx	; LDA (op,x)
	m_assert_next op1l	; falls into op1l
	.endp

op1l	.proc			; Op1L(op)
	pha	
	lda	arg2
	ldy	#8
oplow	ldx	#0
ophigh	stx	arg12
; NOTE:  the order of following
; comparisons is important!
	tax	
	bpl	optype
	bit	procmode
	bne	??opp
	bit	arrmode
	bne	??opa		; array
	bit	tempmode
	bne	??opt		; temp
	bit	cnstmode
	beq	??opc		; constant
; var if we get here
??opv	jsr	stkprop
	beq	??opz		; page zero var
; 16 bit address
??opv1	pla	
	ora	#$0c		; addr16
	jmp	push3

??opp	inc	arg12		; skip JMP byte
	and	#8
	beq	??opv
??operr	jmp	ccompile.chkcond.conderr		; cond. exp.

??opa	bit	cnstmode
	bne	??opa2
	jsr	loady
; LDA arg7
; AND #$F7
; STA arg7 ; flag Y reg used
	lda	#0
	sta	arg12
	lda	#$10		; (addr),Y
??opa1	sta	arg10
	lda	(stack),y
	clc	
	adc	arg12
	cmp	#args
	bcc	??opc2
	cmp	#args+16
	bcs	??opc2
	tax	
	dec	temps-args,x	; free temp
	bcc	??opc3		; unconditional branch

??opa2	tya			; small array
	pha	
	iny	
	iny	
	jsr	loadx
	pla	
	tay	
	jsr	stkprop
	beq	??opa2a		; page zero
	pla	
	ora	#$1c		; addr16,X
	jmp	push3

??opa2a	pla	
	ora	#$14		; addr,X
	jmp	push2

??opc	lda	#$08		; data
	sta	arg10
	lda	arg12
	beq	??opc1
	iny	
??opc1	lda	(stack),y
??opc2	tax	
??opc3	pla	
	ora	arg10		; op mode
	jmp	push2

??opt	lda	#$04		; addr
	bne	??opa1		; unconditional branch

??opz	pla	
	ora	#$04		; addr
	jmp	push2
	.endp

load2l	.proc			; Load2L()
	lda	#opcode.lda_izx	; LDA (op,x)
	m_assert_next op2l	; falls into op2l
	.endp

op2l	.proc			; Op2L(op)
	pha	
	lda	arg1
	ldy	#1
	jmp	op1l.oplow
	.endp

load1h	.proc			; Load1H()
	lda	#opcode.lda_izx	; LDA (op,x)
	m_assert_next op1h	; falls into op1h
	.endp

op1h	.proc			; Op1H(op)
	ldx	arg4
	beq	op2h.ophz
	pha	
	lda	arg2
	ldy	#8
op1h1	ldx	#1
	jmp	op1l.ophigh
	.endp

load2h	.proc			; Load2H()
	lda	#opcode.lda_izx	; LDA (op,x)
	m_assert_next op2h	; falls into op2h
	.endp

op2h	.proc			; Op2H(op)
	ldx	arg3
	beq	ophz
	pha	
	lda	arg1
	ldy	#1
	bne	op1h.op1h1

ophz	ora	#$08
	jmp	push2
	.endp

arrmode		.byte	$10
cnstmode	.byte	$08
tempmode	.byte	$20
procmode	.byte	$40

; see CG
outtype	.local
	.byte	$82,3,$84,types.realt
	.byte	3,3,$84,types.realt
	.byte	$84,$84,$84,types.realt
	.byte	types.realt,types.realt,types.realt,types.realt
	.endl

gettemps	.proc		; GetTemps()
	ldx	#args+16
	ldy	#7
??gtl1	dex	
	dex	
	dey	
	bmi	??gtlerr	; exp. too complex
	lda	temps-args,x
	bne	??gtl1

	inc	temps-args,x
	lda	arg5		; see if byte temp
	beq	??gt2		; yes
	inc	temps-args+1,x

	.if	.def ramzap
	.if	ramzap
	inc	libmath.sargs,x
	.else	
	nop	
	nop	
	nop	
	.endif
	.endif

??gt2	stx	arg9
	rts	

??gtlerr
	jmp	ccompile.experr
	.endp

loadi	.proc			; LoadI(,,offset)
	lda	(stack),y
	sta	arg15
	tax	
	dey	
	lda	(stack),y
	sta	arg14
	rts	
	.endp

ldcdz	.proc			; LdCdZ(,,stkoff)
	lda	#0
	m_assert_next loadcd	; falls into loadcd
	.endp

loadcd	.proc			; LoadCd(cdoff,,stkoff)
	clc	
	adc	(stack),y
	sta	qcode
	iny	
	lda	#0
	adc	(stack),y
	sta	qcode+1
	rts	
	.endp

savecd	.proc			; SaveCd(,,offset)
	lda	qcode
	ldx	qcode+1
savstk	sta	(stack),y
	txa	
	iny	
	sta	(stack),y
	rts	
	.endp

relop	.proc			; RelOp()
	lda	arg6
	bpl	??ro1
	inc	arg8
??ro1	rts	
	.endp

chkzero	.proc	
	lda	arg3
	bne	??cz1
	lda	arg1
	bpl	??cz1		; not const
	cmp	#tokens.vart
	bcs	??cz1
	ldy	#1
	lda	(stack),y
??cz1	rts	
	.endp

opcd1	.proc			; OpCd1()
	ldx	arg8
	lda	ccompile.cgopscd+1,x
	rts	
	.endp

stkaddr	.proc			; StkAddr(,,offset)
	lda	(stack),y
	tax	
	iny	
	lda	(stack),y
	tay	
	rts	
	.endp

stkp	.proc			; StkP(,,offset)
	jsr	stkaddr
	lda	#1
	jmp	prop.gprop
	.endp

stkpz	.proc			; StkPZ(,,offset)
	lda	#0
	m_assert_next stkps	; falls into stkps
	.endp

stkps	.proc			; StkPS(,,offset)
	sta	arg12
	m_assert_next stkprop	; falls into stkprop
	.endp

stkprop	.proc			; StkProp(,,offset)
	jsr	stkp
	clc	
	adc	arg12
	tax	
	iny	
	lda	(props),y
	adc	#0
	tay	
	rts	
	.endp

jsrtable	.proc		; JSRTable(,index)
;.IF ramzap
;  LDY LTab+1,X
;  LDA LTab,X
;.ELSE
	ldy	lsh+1,x
	lda	lsh,x
;.ENDIF
	tax	
	lda	#opcode.jsr_abs	; JSR
	jmp	push3
	.endp

push0	.proc			; Push0()
	sty	arg13
	ldy	qcode
	sty	arg14
	ldy	qcode+1
	sty	arg15
	ldy	#0
	rts	
	.endp

pushtrue	.proc		; PushTrue(op)
	jsr	push1
	ldy	#10
	jsr	savecd
	lda	#0		; no other true branches
	sta	arg9
	m_assert_next push1	; falls into push1
	.endp

push1	.proc			; Push1(op)
	jsr	push0
	sta	(arg14),y
	beq	insrt1.i11
	m_assert_next insrt1	; falls into insrt1
	.endp

insrt1	.proc			; Insrt1(op)
	ldy	#1
	jsr	addcdsp
i11	iny	
	tya	
	jmp	codeincr
	.endp

stemph	.proc			; STempH()
	inc	arg9
	ldy	#12
	bne	stempl.stemp	; Unconditional branch
	.endp

stempl	.proc			; STempL()
	ldy	#10
stemp	jsr	savecd
	lda	arg9
	tax	
	and	#$fe		; set to low address
	sta	arg9
	lda	#opcode.sta_zp	; STA addr
	m_assert_next push2	; falls into push2
	.endp

push2	.proc			; Push2(op,,data)
	jsr	push0
	sta	(arg14),y
	beq	insrt2.i21
	m_assert_next insrt2	; falls into insrt2
	.endp

insrt2	.proc			; Insrt2(op,data)
	ldy	#2
	jsr	addcdsp
i21	txa	
	iny	
	sta	(arg14),y
	bne	insrt1.i11
	m_assert_next push3	; falls into push3
	.endp

push3	.proc			; Push3(op,data16)
	jsr	push0
	sta	(arg14),y
	beq	insrt3.i31
; flass into insrt3
	.endp

insrt3	.proc			; Insrt3(op,data16)
	sty	arg13
	ldy	#3
i30	jsr	addcdsp
i31	txa	
	ldx	arg13
	iny	
	sta	(arg14),y
	bne	insrt2.i21	; Unconditional? Hmmm.
	.endp

addcdsp	.proc	
; AddCdSp(,,size) add qcode space
; does NOT change qcode or codeOff
	pha	
	clc	
	tya	
	adc	arg14
	sta	arg10
	lda	#0
	adc	arg15
	sta	arg11
	sec	
	lda	qcode
	sbc	arg14

	tay	
	beq	??acsret
??acs1	lda	(arg14),y
	sta	(arg10),y
	dey	
	bne	??acs1

	lda	(arg14),y
	sta	(arg10),y

??acsret	pla	
	sta	(arg14),y
	rts	
	.endp

;	�arrayt+8	; small array?
	.endp	; End of cgu