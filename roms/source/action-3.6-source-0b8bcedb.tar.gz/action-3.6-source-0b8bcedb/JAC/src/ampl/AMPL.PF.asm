;
;         AMPL.PF
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved
;
; Original last modified November 3, 1983
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

; This file is actually part of the compiler but it is located in the main bank.

pf	.proc			; PF()

	.use cgu		; uses code generation unit

??ld1	ldy	#0
	lda	(stack),y
	cmp	#tokens.arrayt
	bcs	??c5a
	inc	abt-args,x
	ldy	#7
	lda	(stack),y
	cmp	#tokens.tempt+types.bytet
	beq	??c5b
	dec	abt+1-args,x
	cpx	#args+2
	bcc	??c5b
	jsr	ccompile.genops.gops
	jsr	load2h
	lda	#opcode.sta_izx; STA (zp,x)
	jsr	op1h
	jmp	??c5b


pf_	lda	#0		; load arg types flag
	jsr	mainbnk.getargs
	jsr	ccompile.pushst
	jsr	getnext
	ldx	#args
	stx	vars.argbytes
	ldx	nxttoken
	cpx	#tokens.rparen
	bne	??c4

	jsr	getnext
	bne	??c7		; unconditional branch

??c4	ldx	vars.numargs
	ldy	#tokens.tempt+types.bytet
	lda	argtypes-1,x
	ldx	vars.argbytes
	stx	abt+3
	cmp	#$7f
	bcs	??c5		; one byte arg
	sta	temps-args+1,x
	inc	vars.argbytes
	iny	
??c5	sta	temps-args,x
	inc	vars.argbytes
	txa	
	jsr	ccompile.storst
	jsr	ccompile.getexp
	dec	vars.numargs
	bmi	callerr
	ldx	abt+3
	cpx	#args+3
	bcc	??ld1
??c5a	jsr	ccompile.cgassign
??c5b	lda	token
	cmp	#tokens.comma
	beq	??c4

	cmp	#tokens.rparen
	bne	callerr
;??c6
	lda	vars.argbytes
	cmp	#args+3
	bcs	??c8
	cmp	#args+2
	bcs	??c9
	cmp	#args+1
	bcs	??c10
??c7	jsr	trashy
	ldy	#1
	jsr	stkaddr
	lda	#opcode.jsr_abs	; JSR
	jmp	push3

??c8	ldx	#args+2
	jsr	??push
??c9	ldx	#args+1
	jsr	??push
??c10	ldx	#args
	jsr	??push
	jmp	??c7


callerr	jmp	segment.argerr


??push	lda	abt-args,x
	bne	??p1
	lda	??ops-args,x
	ora	#$04
	jmp	push2

??p1	stx	arg0
	jsr	ccompile.genops.gops
	ldx	arg0
	lda	??ops-args,x
; all of this for LDX # and LDY #
; can't use OpXX for these instr.
	cpx	#args
	beq	??p4		; LDA instr.
	ldy	arg1
	bpl	??p3a		; record element
	cpy	#tokens.vart
	ldy	abt-args,x
	bcs	??p3		; not const.
	pha	
	sty	arg0
	ldy	#2
	jsr	loadi
	ldy	arg0
	bmi	??p2
	tax	
	pla	
	jsr	push2		; low byte of const
	jmp	ccompile.cgassign.cga1

??p2	pla	
??p2a	jmp	push2		; high byte

??p3a	ldy	abt-args,x
??p3	bpl	??p4
	ldx	arg3
	beq	??p2a
	jmp	op2h

??p4	jsr	op2l
	jmp	ccompile.cgassign.cga1

??ops	.byte	$a1,$a2,$a0	; LDA, LDX, LDY
	.endp
