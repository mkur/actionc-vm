;
;	AMPL.SEG
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified October 15, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

; This file is actually part of the compiler but it is located in the main bank.

	.use	compiler

getnext	= lexicon.getnext

; low segment list> ..:= low segment list> low segment> | low segment>
; low segment> ..:= low segment type> low heading> (<dcl list>) (<stmt list>)
; low segment type> ..:=  PROC | low type> FUNC

segment	.proc

	.use mainmsc
	.use cgu		; uses code generation unit

	cmp	#tokens.procid
	beq	??proc
	ldx	nxttoken
	cpx	#tokens.funcid
	beq	??func
	rts			; end of segment list

??proc	lda	#tokens.funct-tokens.vart+tokens.charid-1
	sta	vars.type
	bne	??func1		; unconditional branch

??func	clc	
	adc	#tokens.funct-tokens.vart
	sta	vars.type
	jsr	getnext

??func1	jsr	ccompile.makeentry
	jsr	segend
	lda	addr
	sta	curproc
	lda	addr+1
	sta	curproc+1
	sta	qglobal

	lda	#1
	jsr	stincr		; space for num args

	ldy	#3
	lda	#0		; no args yet
	sta	(props),y
	sta	vars.argbytes

	tay	
??funcst
	sta	(stlocal),y
	iny			; zap local st
	bne	??funcst

	lda	symtab
	sta	vars.gbase
	lda	symtab+1
	sta	vars.gbase+1

; space for arg list (8 bytes) and
; room for name of next .proc/func
; up to 20 letters (24 bytes)
; unused space will be reclaimed
; see Params
	lda	#32
	jsr	stincr		; arg list space

	jsr	trashy

	lda	nxttoken
	eor	#tokens.equalid
	sta	vars.param	; this is very tricky!!
	bne	??funchd
	jsr	ccompile.ideq	; param must = 0 here
	iny	
	jsr	ccompile.storprops
	ldy	#0
	lda	(props),y
	ora	#8
	sta	(props),y	; set Sys flag
	sta	vars.param
	jsr	getnext

??funchd
	jsr	getnext
	cmp	#tokens.lparen
	bne	argerr


; low heading> ??:= low id> (= low constant>) ( (<arg dcl list>) )
; low arg dcl list> ??:= low arg dcl list> , low dcl list> | low dcl list>


	jsr	getnext
	cmp	#tokens.rparen
	beq	??func2

??heading
	jsr	ccompile.cderr.declare
	ldx	lsttoken
	inc	lsttoken	; in case 2 of two commas
	cpx	#tokens.comma
	beq	??heading

	cmp	#tokens.rparen
	beq	??func2

argerr	ldy	#errors.arger
	jmp	mainbnk.splerr

??func2	lda	vars.param
	pha	
	lda	#0
	sta	vars.param

	jsr	getnext
	jsr	ccompile.cderr.declare	; locals

; handle procedure setup here
	pla	
	bmi	??f4		; system .proc

; get beginning of arguments and
; save actual procedure address
	lda	#1
	jsr	prop.cprop
	sta	arg0
	stx	arg1
	jsr	getcdoff
	jsr	ccompile.storprops

; get space for .proc variable
	lda	#opcode.jmp_abs	; JMP
	jsr	push1
	jsr	getcdoff	; fill in address
	adc	#2
	bcc	??fh2
	inx	
??fh2	jsr	push2

; qcode to transfer arguments to
; local frame
??fh3	lda	vars.argbytes
	beq	??func3		; no arguments
	cmp	#3
	bcs	??fh5
	cmp	#2
	lda	#opcode.sta_abs ; STA abs
	ldx	arg0
	ldy	arg1
	bcc	??fh4
	lda	#opcode.stx_abs	; STX abs
	inx	
	bne	??fh4
	iny	
??fh4	jsr	push3
	dec	vars.argbytes
	jmp	??fh3

??f4	jmp	??func4

??fh5	ldx	#10
	jsr	jsrtable
	lda	arg0
	ldx	arg1
	ldy	vars.argbytes
	dey	
	jsr	push3

??func3	lda	vars.trace	; check for trace
	beq	??func4		; no trace
	lda	#opcode.jsr_abs	; JSR CTrace
	ldx	#<lib.libmisc.ctrace
	ldy	#>lib.libmisc.ctrace
	jsr	push3

	ldy	#0
	lda	(curproc),y
	tay	
	tax	
??f3a	lda	(curproc),y
	sta	(qcode),y
	dey	
	bpl	??f3a
	inx	
	txa	
	jsr	codeincr

	lda	arg0
	ldx	arg1
	jsr	push2

	lda	#3
	jsr	prop.cprop
	tay	
	tax	
??f3b	lda	(props),y
	sta	(qcode),y
	dey	
	bpl	??f3b
	inx	
	txa	
	jsr	codeincr

??func4	jsr	ccompile.stmtlist
	jmp	segment
	.endp

