;
;	ACTION.ASM - OSS 16k ROM Version, cartridge type 15
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
; Original last modified November 4, 1983.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.outputfile=../out/ACTION-ROM-OSS-16k.rom

; Options
ramzap		= 1
feature_build_version = 0
;feature_build_type =
feature_error_texts = 0
fix_stsp_pages	= 0
fix_save_initad = 0
fix_cio_aux2 = 0

	opt h-

	icl	"ACTION.DEF.asm"
	icl	"ACTION.ROM.asm"
	icl	"EDIT.DEF.asm"

	opt	f-
	org	rom.ml		; Main bank at $b000
	opt	f+

version	.byte	$36		; Version 3.6 in BCD format
date	.byte	$01,$17,$84	; Assemble date in American date BCD format $DD,$MM,$YY


	icl	"main/MAIN.IO.asm"

propid	ldx	$a0		; $A6 $A0 marker

	icl	"main/SCREEN.MAC.asm"
	.local	compiler	; Main bank part of the compiler
	icl	"compiler/COMPILER-DEF.asm"
	icl	"compiler/LEXICON.asm"
	.endl
	icl	"main/MAIN.MSC.asm"
	icl	"main/MAIN.BNK.asm"

	m_align rom.ml+$08d8
	.local	editor		;Main bank part of the editor
	icl	"editor/EDIT.FND.asm"
	icl	"editor/EDIT.SUB.asm"
	icl	"editor/EDIT.TAB.asm"
	.endl
	m_info	editor

	m_align	rom.ml+$0a80,$00
	icl	"ampl/AMPL.SEG.asm"
	icl	"ampl/AMPL.PF.asm"
	icl	"ampl/AMPL.ARR.asm"
	icl	"ampl/AMPL.CGU.asm"

	m_align	$bffa,$00
	.word	mainbnk.cstart
	.word	$0500		; Boot disk and start cart.
	.word	mainbnk.rstbank.init

;	ACTION! 3.6 - S.T.
;	------------------
	opt	f-
	org	rom.ll
	opt	f+
	icl	"ampl/AMPL.MTH.asm"
	icl	"ampl/AMPL.SYM.asm"

	.local lib
	icl 	"lib/LIB.KEY.asm"
	icl 	"lib/SPL.ERR.asm"
	icl 	"lib/LIB.IO.asm"
	icl 	"lib/LIB.GR.asm"
	icl 	"lib/LIB.MSC.asm"
	icl 	"lib/LIB.STR.asm"
	icl	"lib/LIB.STM.asm"
	icl	"lib/LIB.OPT.asm"
	.endl

	.local cpyright
	.byte	'ACTION! (c)1983 Action Computer Services (ACS)  November 4, 1983  '
	.endl

	m_end_switched_bank ll lbank


;	"ACTION! 3.6 - Compiler
;	-----------------------
	opt	f-
	org	rom.cl
	opt	f+

	.local	compiler
	icl	"compiler/COMPILER.asm"

	.local cright
	.byte	'ACTION! (c)1983 Action Computer Services'
	.endl

	.endl

	m_end_switched_bank cl cbank


;	ACTION! 3.6 - Editor
;	--------------------
	opt	f-
	org	rom.el
	opt	f+

	.local	editor
	icl	"editor/EDIT.asm"
	icl	"ampl/AMPL.MON.asm"
	.endl

	icl	"ampl/AMPL.INI.asm"

	.byte 'ces'
	m_end_switched_bank el ebank

