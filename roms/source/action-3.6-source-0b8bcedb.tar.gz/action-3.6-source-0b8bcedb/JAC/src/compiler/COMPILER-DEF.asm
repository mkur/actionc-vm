;
;	COMPILER.DEF
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified October 18, 1982.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm

;=============================
;	Compiler tokens
;=============================

	.enum	tokens
plusid	=	1
minusid	=	2
timesid	=	3
divideid =	4
orid	=	5
andid	=	6
equalid	=	7
neid	=	8
grid	=	9
;geid	=	10
lsid	=	11
;leid	=	12
remid	=	13
xorid	=	14
lshid	=	15
rshid	=	16
uminusid =	17
atid	=	18

scolon	=	21
squote	=	22	; Single quote
period	=	23
rparen	=	24
lparen	=	25
comma	=	26
defid	=	27
digit	=	28+$80
hex	=	29
quote	=	30

charid	=	32
byteid	=	33
intid	=	34
cardid	=	35
;stringid	=	36
;realid	=	37
defineid	=	38
recordid	=	39

arrayid	=	64
funcid	=	65
procid	=	66
getid	=	67
setid	=	68
pointerid	=	69
typeid	=	70

ifid	=	80
whileid	=	81
retid	=	82
exitid	=	83
forid	=	84
;caseid	=	85
;codeid	=	86
modid	=	87
untilid	=	88

lbrack	=	91
rbrack	=	93
uparrow	=	94

thenid	=	96
elseid	=	97
doid	=	98
fi	=	99
odid	=	100
toid	=	101
stepid	=	102
;ofid	=	103
;esacid	=	104
;edocid	=	105
elseif	=	106
;downtoid	=	107

typet	=	$70		; 112

eofid	=	127

constt	=	$80		; Base value of value type, actual type is added to this
vart	=	$88
arrayt	=	$90
tempt	=	$a8
funct	=	$c0
condt	=	$48
	.ende			; End of tokens

;	types
;	-----
	.enum	types
chart	=	1
bytet	=	2
intt	=	3
cardt	=	4
strt	=	5
realt	=	6
	.ende

undec	equ	$88		; Undeclared. TODO: Is this a token or type or...


;========================
;	Error codes
;========================


	.enum	errors		; Text from reference manual
memer	=	0		; Out of system memory
strer	=	1		; Missing quote in a string
dfner	=	2		; Nested DEFINEs
gster	=	3		; Global variable symbol table full
lster	=	4		; Local variable symbol table full
seter	=	5		; SET directive syntax error
dcler	=	6		; Declaration error
arger	=	7		; Invalid argument list
varer	=	8		; Variable not declared
conster	=	9		; Not a constant
asser	=	10		; Illegal assignment
ender	=	11		; Unknown error
thener	=	12		; Missing THEN
fier	=	13		; Missing FI
cder	=	14		; Out of code space
doer	=	15		; Missing DO
toer	=	16		; Missing TO
exper	=	17		; Bad expression
parer	=	18		; Unmatched parentheses
oder	=	19		; Missing OD
alcer	=	20		; Cannot allocate memory
arrer	=	21		; Illegal array reference
fileer	=	22		; Input file too large
cnder	=	23		; Illegal conditional expression
forer	=	24		; Illegal FOR statement syntax
exiter	=	25		; Illegal EXIT
nster	=	26		; Nesting too deep
typer	=	27		; Illegal TYPE syntax
reter	=	28		; Illegal RETURN
stspcer	=	61 		; Out of symbol table space
brker	=	$80		; BREAK key pressed
	.ende

	.if feature_error_texts = 1

	.proc error_texts

	.proc get_error_text	
	x1	= arg2
	p1	= arg0

	sta	x1
	mwy	#texts p1
loop	ldy	#0
	lda	(p1),y
	cmp	x1
	beq	found
	cmp	#texts.not_found
	beq	not_found
	iny
	clc
	lda	(p1),y
	adc	#1+1		;Skip error code and length byte
	adc	p1
	sta	p1
	scc
	inc	p1+1
	bne	loop		; Unconditional branch

not_found
	mwa	#texts.unknown p1

found	inw	p1		; Skip error code
	rts
	.endp


	.local texts

	not_found = $ff

	.macro m_error_text
	.byte errors.:1
	m_string :2
	.endm

	m_error_text memer,	'Out of system memory'
	m_error_text strer,	'Missing quote in a string'
	m_error_text dfner,	'Nested DEFINEs'
	m_error_text gster,	'Global variable symbol table full'
	m_error_text lster,	'Local variable symbol table full'
	m_error_text seter,	'SET directive syntax error'
	m_error_text dcler,	'Declaration error'
	m_error_text arger,	'Invalid argument list'
	m_error_text varer,	'Variable not declared'
	m_error_text conster,	'Not a constant'
	m_error_text asser,	'Illegal assignment'
unknown	m_error_text ender,	'Unknown error'
	m_error_text thener,	'Missing THEN'
	m_error_text fier,	'Missing FI'
	m_error_text cder,	'Out of code space'
	m_error_text doer,	'Missing DO'
	m_error_text toer,	'Missing TO'
	m_error_text exper,	'Bad expression'
	m_error_text parer,	'Unmatched parentheses'
	m_error_text oder,	'Missing OD'
	m_error_text alcer,	'Cannot allocate memory'
	m_error_text arrer,	'Illegal array reference'
	m_error_text fileer,	'Input file too large'
	m_error_text cnder,	'Illegal conditional expression'
	m_error_text forer,	'Illegal FOR statement syntax'
	m_error_text exiter,	'Illegal EXIT'
	m_error_text nster,	'Nesting too deep'
	m_error_text typer,	'Illegal TYPE syntax'
	m_error_text reter,	'Illegal RETURN'
	m_error_text stspcer,	'Out of symbol table space'
	m_error_text brker,	'BREAK key pressed'
	.byte not_found		; Termination mark
	.endl			; End of texts

	.endp			; End of error_texts

	.endif