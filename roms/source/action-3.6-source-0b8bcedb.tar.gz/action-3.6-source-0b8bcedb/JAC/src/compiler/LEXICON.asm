;
;	LEXICON.ASM
;
; Copyright 1982 by Clinton W Parker.
; All Rights Reserved.
; Original last modified October 18, 1982.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=../ACTION.asm


	.proc lexicon

;============================================
;	Compiler lexicon - get tokens
;============================================

;	GetNext()
;	---------
getnext	.proc
	lda	spnxt
	ldx	curnxt
	ldy	curnxt+1
	stx	curln
	sty	curln+1
	sta	spln

	lda	token
	sta	lsttoken
	ldx	nxtaddr
	ldy	nxtaddr+1
	lda	nxttoken
	stx	addr
	sty	addr+1
	sta	token
getnloop
	jsr	nextchar
getnl0	cmp	#tokens.eofid
	beq	getnr1

	cmp	#'!'
	bcc	getnloop
			; save line index for debugging
	ldx	choff
	stx	spnxt

	cmp	#'A'
	bcs	getnl1
	tay	
	lda	lexchars-33,y
	beq	getnloop
	bpl	getnr1
	and	#$7f
	bne	getnr0		; unconditional branch

getnl1	jsr	mainmsc.alpha
	bne	getnid

	cmp	#'['
	beq	getnr1
	cmp	#'^'
	beq	getnr1
	cmp	#']'
	beq	getnr1
	bne	getnloop	; unconditional branch

getnid	jsr	mainbnk.getname
	bmi	getnr1

getnr0	sta	nxttoken
	ldx	#<lexcmd
	ldy	#>lexcmd
	jmp	mainmsc.lookup

getnr1	sta	nxttoken

;GetNr2 LDA $D0
; BEQ GetNr3
; JSR PrintTok

getnr2	ldx	addr
	ldy	addr+1
ismt	lda	token
	rts	
	.endp


;	LexCom()
;	--------
lexcom	.proc
	jsr	nextline
	bne	getnext.getnl0		; unconditional branch
	.endp


;	LexDig()
;	--------
lexdig	.proc
	lda	#tokens.constt+types.intt
	sta	nxttoken
	jsr	lexbuf		; get buf ptr
	jsr	mainio.storeal
ldig1	jsr	nextchar	; cardinal?
	jsr	mainmsc.alphanum.num
	bne	ldig1
	cmp	#'.'
	beq	ldig4
	cmp	#'E'
	beq	ldig4
	dec	choff
	jsr	mainio.rtocar
	bcc	ldig3

;cnsterr
	ldy	#errors.conster
	jmp	mainbnk.splerr

ldig2	dey	
	sty	choff
ldig3	sta	nxtaddr
	stx	nxtaddr+1
	cpx	#0
	bne	getnext.getnr2
	lda	#tokens.constt+types.bytet
	bne	getnext.getnr1

ldig4	lda	#tokens.constt+types.realt
	sta	nxttoken
	ldy	cix
	ldx	#$ff		; for SET cmd
	bne	ldig2
	.endp


;	LexChr()
;	--------
lexchr	.proc
	jsr	nextchar
	sta	nxtaddr
	lda	#tokens.constt+types.chart
	bne	getnext.getnr1
	.endp


;	LexNE()
;	-------
lexne	.proc
	jsr	nextchar
	cmp	#'>'
	bne	lexeq.leq1
	lda	#tokens.neid
	bne	getnext.getnr1		; unconditional branch
	.endp


;	LexEq()
;	-------
lexeq	.proc
	jsr	nextchar
leq1	cmp	#'='
	bne	putback
	inc	nxttoken
	bne	getnext.getnr2		; unconditional branch
	.endp


;	LexHex()
;	--------
lexhex	.proc
	lda	#tokens.constt+types.cardt
	sta	nxttoken
	inc	choff
	jsr	lexbuf
	jsr	mainio.htocar
	bne	lexdig.ldig2	; unconditional branch
	.endp


;	PutBack returns character to buf
;	--------------------------------
putback	.proc	
	dec	choff
pback	jmp	getnext.getnr2
	.endp


;	LexPF()
;	-------
lexpf	.proc
	lda	qglobal
	beq	putback.pback
	lda	#0
	sta	qglobal

	lda	vars.gbase	; restore qglobal base
	sta	symtab
	lda	vars.gbase+1
	sta	symtab+1
	bne	putback.pback	; unconditional branch
	.endp


;	LexStr()
;	--------
lexstr	.proc
	lda	token
	cmp	#tokens.quote
	beq	putback.pback	; zap local st
	lda	#0
	sta	arg9
??lstr1	jsr	nextchar
	inc	arg9
	beq	??lstr3		; string too long
	cmp	#'"'
	beq	??lstr4
??lstr2	ldy	arg9
	sta	(symtab),y
	lda	chan
	bpl	??lstr1		; if not EOF
??lstr3	ldy	#errors.strer
	jmp	mainbnk.splerr

??lstr4	jsr	nextchar
	cmp	#'"'
	beq	??lstr2		; " in string
				; end of string
	ldy	arg9
	lda	#eol
	sta	(symtab),y
	dey	
	tya	
	ldy	#0
	sta	(symtab),y	; save size
	lda	symtab
	ldx	symtab+1
	ldy	choff
	dey	
	jmp	lexdig.ldig2
	.endp


;	NextChar()
;	----------
nextchar .proc
	ldy	defflg
	bne	lexdef

nxtch0	ldy	choff
	cpy	sp
	bcc	nextline.nxtch1
	.endp


;	NextLine()
;	----------
nextline .proc
	lda	chan
	beq	??nln1
	bmi	??nln4		; eof

	jsr	mainio.rdbuf
	bpl	??nln2

	cpy	#cio_error.eof	; EOF
	beq	??nln0
	jmp	mainbnk.splerr	; I/O error

??nln0	dec	chan
	bne	nextline

??nln1	ldy	top+1
	beq	??nln0		; set eof, tricky qcode
	jsr	mainio.ldbuf
	lda	cur
	sta	curnxt
	ldx	cur+1
	stx	curnxt+1
	jsr	mainmsc.editor.nextdwn
	bne	??nln2
;	LDA #0
	sta	top+1

??nln2	lda	vars.list
	beq	??nln3		; don't list
	lda	device
	jsr	mainio.wrtbuf
??nln3	ldy	#0
	sty	choff
	lda	(buf),y
	tay	
	iny	
	sty	sp
	lda	#eol
	sta	(buf),y
	ldy	#0

nxtch1	iny	
	lda	(buf),y
	sty	choff
	rts	

??nln4	lda	#tokens.eofid
	rts	
	.endp


lexdef	.proc	
	ldy	#0
	lda	(delnxt),y
	inc	choff
	cmp	choff
	bcs	ldef1
	lda	defflg
	sta	choff
	sty	defflg
	bcc	nextchar.nxtch0	; unconditional branch

ldef1	ldy	choff
	lda	(delnxt),y
	rts	
	.endp


;	LexGet()
;	--------
lexget	.proc
	jsr	getnext.getnloop
lget	lda	#0
	sta	defflg
	inc	chan
	lda	#4
	jsr	mainio.openchan
	jsr	nextline
	jmp	getnext.getnl0
	.endp


;	LexSet()
;	--------
lexset	.proc
	jsr	getadr
	sta	arg11
	stx	arg12

	jsr	getnext.getnloop
	lda	nxttoken
	cmp	#tokens.equalid
	bne	lseterr

	jsr	getadr
	ldy	#0
	sta	(arg11),y
	txa	
	beq	lset1
	iny	
	sta	(arg11),y
lset1	jmp	getnext.getnloop

lseterr	ldy	#errors.seter
	jmp	mainbnk.splerr
	.endp

getadr	.proc
	jsr	getnext.getnloop
	jmp	mainmsc.mnum
	.endp


;	LexExpand()
;	-----------
lexexpand .proc
	lda	defflg
	beq	lexp
	ldy	#errors.dfner
	jmp	mainbnk.splerr

lexp	lda	#3
	jsr	mainmsc.prop.nxtprop
	lda	props
	ldx	props+1
	jsr	mainmsc.prop.rstp
	ldy	choff
lexp1	sta	delnxt
	stx	delnxt+1
	sty	defflg
	lda	#0
	sta	choff
	jmp	getnext.getnloop
	.endp


;	LexBuf()
;	--------
lexbuf	.proc
	ldy	choff
	lda	defflg
	beq	??lbuf
	lda	delnxt
	ldx	delnxt+1
	rts	
??lbuf	lda	buf
	ldx	buf+1
	rts	
	.endp


	.local	lexcmd
	.word	getnext.getnr2
	.byte	41
	.word	lexdig
	.byte	tokens.digit-$80
	.word	lexhex
	.byte	tokens.hex
	.word	lexeq
	.byte	tokens.grid
	.word	lexne
	.byte	tokens.lsid
	.word	lexexpand
	.byte	tokens.defid
	.word	lexcom
	.byte	tokens.scolon
	.word	lexchr
	.byte	tokens.squote
	.word	lexpf
	.byte	tokens.procid
	.word	lexpf
	.byte	tokens.funcid
	.word	lexpf
	.byte	tokens.modid
	.word	lexstr
	.byte	tokens.quote
	.word	lexget
	.byte	tokens.getid
	.word	lexset
	.byte	tokens.setid
	 .endl

	.local	lexchars
	.byte	tokens.xorid		; !
	.byte	tokens.quote+$80	; "
	.byte	tokens.neid		; #
	.byte	tokens.hex+$80		; $
	.byte	tokens.orid		; %
	.byte	tokens.andid		; &
	.byte	tokens.squote+$80	; '
	.byte	tokens.lparen		; (
	.byte	tokens.rparen		; )
	.byte	tokens.timesid
	.byte	tokens.plusid		; +
	.byte	tokens.comma		; ,
	.byte	tokens.minusid		; -
	.byte	tokens.period		; .
	.byte	tokens.divideid+$80	; /
	.byte	tokens.digit,tokens.digit,tokens.digit,tokens.digit
	.byte	tokens.digit,tokens.digit,tokens.digit,tokens.digit
	.byte	tokens.digit,tokens.digit		; 0 thru 9
	.byte	0			; :
	.byte	tokens.scolon+$80	; ;
	.byte	tokens.lsid+$80		; low
	.byte	tokens.equalid		; =
	.byte	tokens.grid+$80		; high
	.byte	126			; ?
	.byte	tokens.atid		; @
	.endl

;PrintTok LDA token
; LDX #0
; JSR PrintC
; JSR PutSp
; LDA addr
; LDX addr+1
; JSR PrintH
; JSR PutSp
; LDA nxtToken
; LDX #0
; JSR PrintC
; JSR PutSp
; LDA nxtAddr
; LDX nxtAddr+1
; JSR PrintH
; JMP PutEOL
	.endp	; end of lexicon