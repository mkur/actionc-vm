;
;	ACTION.ASM - Plain 16k ROM Version, cartridge type 2
;
; Copyright 1983 by Clinton W Parker.
; All Rights Reserved.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.outputfile=../out/ACTION-ROM-Plain-16k.rom

feature_build_version = 1
feature_build_type = 'P'
feature_error_texts = 0
fix_stsp_pages	= 1
fix_save_initad = 1
fix_cio_aux2 = 1

	opt h-f+

	org	$8000

	icl	"ACTION-Core.asm"

	m_align	$bffa,$00
	.word	mainbnk.cstart
	.word	$0500		; Boot disk and start cart.
	.word	mainbnk.rstbank.init
