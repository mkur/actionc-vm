;
;	ACTION.ROM
;
; This file is not part of the original distribution.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=ACTION.asm

	.enum rom	;Equates only used in ROM mode

; Cartridge type that determines the bank ordering and bank identifiers according to
; http://atari800.cvs.sourceforge.net/viewvc/atari800/atari800/DOC/cart.txt
;
;+---------------------------------------------------------------------------+
;| Type 15: OSS one chip 16 KB cartridge                                     |
;+---------------------------------------------------------------------------+
;
; There are two types of OSS 16KB cartridges; this is the later, simpler one.
; Used by BASIC XL 1.03, Action! 3.6, MAC/65 1.1 and BASIC XE 4.1 (and possibly
; also by later versions of the above software).
; It consists of one 16 KB ROM chip.
; The cartridge occupies 8 KB of address space between $A000 and $BFFF. Its
; memory is divided into 4 banks, 4 KB each. Bank number 0 (the first one) is
; always mapped to $B000-$BFFF. Bank in $A000-$AFFF is selected by an access to
; $D500-$D5FF. Only bits 0 and 3 of address are significant:
; - A3=0, A0=0 - selects bank 1, bank id $00
; - A3=0, A0=1 - selects bank 3, bank id $01
; - A3=1, A0=0 - disables cartridge, bank id $08, enables computer's memory in address space between $A000 and $BFFF
; - A3=1, A0=1 - selects bank 2, bank id $09 

; bank switching defs
;---------------------
ml	=	$b000
el	=	$a000
ll	=	$a000
cl	=	$a000

bank	=	$d500
bankmsk	=	%1001			; Only bit 3 and 0 are relevant

ebank	=	3			; Editor bank, was 1 in original source
lbank	=	0			; Library bank
cbank	=	9			; Compiler bank

serial	=	$0a00			; ACTION 3.6 serial number word at $A2FA
					; Normally $00 in the source and set before burning the ROM.
	.ende

	.macro m_end_switched_bank
bank_used_end
	.align	rom.:1+$0fff,$00	; Fill with empty bytes instead of $ff.
bank_end
	.byte	rom.:2 & rom.bankmsk	; Bank identifier at end of bank.
	.print "Ending switched bank :1/:2: " , bank_used_end, " - ", bank_end, "(", bank_end-bank_used_end+1, " bytes free)"
	.endm
