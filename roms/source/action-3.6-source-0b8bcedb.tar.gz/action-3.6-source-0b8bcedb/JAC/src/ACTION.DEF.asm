;
;	ACTION.DEF
;
; This file is not part of the original distribution.
;
; This file is part of Action!.
;
; Action! is free software: you can redistribute it and/or modify
; it under the terms of the GNU General Public License as published by
; the Free Software Foundation, either version 3 of the License, or
; (at your option) any later version.
;
; Action! is distributed in the hope that it will be useful,
; but WITHOUT ANY WARRANTY; without even the implied warranty of
; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
; GNU General Public License for more details.
;
; You should have received a copy of the GNU General Public License
; along with Action!.  If not, see <http://www.gnu.org/licenses/>.
;
; @com.wudsn.ide.asm.mainsourcefile=ACTION.asm

; system defs
;-------------
space	equ	$20
eol	equ	$9b

; system vars
;-------------
warmst	equ	$08
boot	equ	$09
dosvec	equ	$0a
dosini	equ	$0c
qcode	equ	$0e	; ap. high mem.
brkkey	equ	$11
rtclok	equ	$12
adress	equ	$64
lmargin equ	$52
rmargin equ	$53
rowcrs	equ	$54
colcrs	equ	$55
dindex	equ	$57
savmsc	equ	$58
oldrow	equ	$5a
oldcol	equ	$5b
oldadr	equ	$5e
oldchr	equ	$5d
csrch	equ	$5d
ramtop	equ	$6a
fr0	equ	$d4
fr1	equ	$e0
cix	equ	$f2
inbuff	equ	$f3
;flptr	equ	$fc

srtimr	equ	$022b
sdmctl	equ	$022f
sskctl	equ	$0232
coldst	equ	$0244
paddl0	equ	$0270
;txtmsc	equ	$0294
tabmap	equ	$02a3
invflg	equ	$02b6
shflok	equ	$02be
color0	equ	$02c4
color4	equ	$02c8
runad	equ	$02e0
initad	equ	$02e2
memtop	equ	$02e5
memlo	equ	$02e7
ch1	equ	$02f2	; Prior keyboard qcode
atachr	equ	$02fb
ch	equ	$02fc
fildat	equ	$02fd
dspflg	equ	$02fe

iccom	equ 	$0342	; IOCB0
icbadr	equ	$0344
icblen	equ	$0348
icax1	equ	$034a
icax2	equ	$034b
icax3	equ	$034c
icax4	equ	$034d
icax5	equ	$034e
basicf	equ	$03f8


lbuff	equ	$0580	; fp ASCII buf from $580 to $5ff
trig0	equ	$d010
colpf0	equ	$d016
consol	equ	$d01f

audf0	equ	$d200
skctl	equ	$d20f

porta	equ 	$d300
portb	equ	$d301

dmactl	equ	$d400
wsync	equ	$d40a

;	floating point routines
;	-----------------------
afp	equ	$d800
fasc	equ	$d8e6
ifp	equ	$d9aa
fpi	equ	$d9d2
;fadd	equ	$da66
;fsub	equ	$da60
;fmul	equ	$dadb
;fdiv	equ	$db28
;log	equ	$decd
;log10	equ	$ded1
;exp10	equ	$ddcc
;plyevl	equ	$dd40
;zfr0	equ	$da44
;zf1	equ	$da46
;fld0r	equ	$dd89
;fld0p	equ	$dd8d
;fld1r	equ	$dd98
;fld1p	equ	$dd9c
;fst0r	equ	$dda7
;fst0p	equ	$ddab
;fmove	equ	$ddb6
;coldsv	equ	$e477

	.enum character
	comma	  = ','
	escape	  = $1b
	up	  = $1c
	down	  = $1d
	left	  = $1e
	right	  = $1f
	backspace = $7e
	clear	  = $7d
	eol	  = $9b
	bell	  = $fd
	.ende

	.enum cio_channel
	factor	= $10		; Factor to multiply the channel number with for direct CIO calls
	zero	= 0		; Used for editor
	one	= 1		; Used for disk I/O
	six	= 6		; User for screen
	seven	= 7		; Used keyboard 
	.ende

	.enum cio_command
	open	= $03	; Open a specified device or file.
	getrec	= $05	; Read a record from a specified device or file.
	getchr	= $07	; Read character from specified device or file.
	putrec	= $09 	; Write a record to a specified device or file.
	putchr	= $0b	; Write character from specified device or file.
	close	= $0c	; Close a specified device or file.
	drawto	= $11	; Draw a line on the screen
	fill	= $12	; Fill a screen area
	point	= $25	; Point to a position within an open file
	note	= $26	; Note the position within an open file
	.ende

	.enum cio_mode
	read	= $04	; Open a device or file for read operations.
	write	= $08	; Open a device or file for write operations.
	read_write = $0c; Open a device or file for read and write operations.
	.ende

	.enum cio_error
	break	= $80
	eof	= $88
	.ende

	.enum opcode
	cmp_izx	= $c1
	lda_izx	= $a1
	sta_izx	= $81
	lda_imm	= $a9
	lda_abs	= $ad
	tax_	= $aa
	adc_izx	= $61
	sta_zp	= $85
	sta_abs = $8d	; STA abs
	stx_abs = $8e	; STX abs
	asl_a	= $0a		; ASL A
	php_	= $08		; PHP
	clc_	= $18		; CLC

	jsr_abs	= $20		; JSR abs
	jmp_abs	= $4c		; JMP abs
	rts_	= $60		; RTS
	.ende
ciov	equ	$e456

	.macro m_info		; Prints location and siize of ranges like ".PROC", ".LOCAL"
	.print ":1: " , :1, " - ", :1 + .len :1 -1, " (", .len :1,")"
	.endm

	.macro m_align		; Fills with empty bytes instead of $ff
align_used_end
	.align	:1,$00
align_end
	.print "Aligning " , align_used_end, " - ", align_end, "(", align_end-align_used_end+1, " bytes free)"
	.endm

	.macro m_assert_next	; Asserts the a fall-though ends up in the right location
	.if :0 <> 1
	.error "Wrong number of arguments"
	.endif
	.if * <> :1
	.error "Fall-though to next label broken. Next label at ", *, " must be ", ":1" 
	.endif
	.endm

	.macro m_string		; Defines ACTION! type ASCII string constant with leading length byte
	.byte [.len string]
	.local string
	.byte :1
	.endl
	.endm


	.enum screen_definition
	normal		= $00
	inverse		= $80
	line_width	= 40
	screen_on	= $22
	screen_off	= $00
	.ende

	.macro m_statement
	m_string :1
	.byte :2
	.word :3
	.endm